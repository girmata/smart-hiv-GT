# Reason(s) for substitution within third-line regimen ValueSet - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Reason(s) for substitution within third-line regimen ValueSet**

## ValueSet: Reason(s) for substitution within third-line regimen ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/ValueSet/HIV.D.DE494 | *Version*:0.4.4 |
| Active as of 2025-12-10 | *Computable Name*:HIVDDE494 |

 
Value set of reason(s) why client changed drug regimen (within the third-line) 

 **References** 

* [HIV.D Care-Treatment](StructureDefinition-HIVDCareTreatment.md)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "HIV.D.DE494",
  "meta" : {
    "profile" : [
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablevalueset",
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"
    ]
  },
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
      "valueMarkdown" : "This should be a context-specific list of reason(s) why one ore more drugs in client's third-line ARV drug regimen was changed"
    }
  ],
  "url" : "http://smart.who.int/hiv/ValueSet/HIV.D.DE494",
  "version" : "0.4.4",
  "name" : "HIVDDE494",
  "title" : "Reason(s) for substitution within third-line regimen ValueSet",
  "status" : "active",
  "experimental" : true,
  "date" : "2025-12-10T09:21:32+00:00",
  "publisher" : "WHO",
  "contact" : [
    {
      "name" : "WHO",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://who.int"
        }
      ]
    }
  ],
  "description" : "Value set of reason(s) why client changed drug regimen (within the third-line)"
}

```
