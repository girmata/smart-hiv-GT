# Community health worker - JSON Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Community health worker**

## : Community health worker - JSON Representation

| |
| :--- |
| Draft as of 2025-12-10 |

[Raw json](ActorDefinition-CommunityHealthWorker.json) | [Download](ActorDefinition-CommunityHealthWorker.json)

