# WHO SMART HIV Concepts CodeSystem - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO SMART HIV Concepts CodeSystem**

## CodeSystem: WHO SMART HIV Concepts CodeSystem (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/CodeSystem/HIVConcepts | *Version*:0.4.4 |
| Draft as of 2025-12-10 | *Computable Name*:HIVConcepts |

 
This code system defines the concepts used in the World Health Organization SMART HIV DAK 

 This Code system is referenced in the content logical definition of the following value sets: 

* [HIVADE18](ValueSet-HIV.A.DE18.md)
* [HIVADE25](ValueSet-HIV.A.DE25.md)
* [HIVADE30](ValueSet-HIV.A.DE30.md)
* [HIVADE46](ValueSet-HIV.A.DE46.md)
* [HIVADE5](ValueSet-HIV.A.DE5.md)
* [HIVBDE1](ValueSet-HIV.B.DE1.md)
* [HIVBDE102](ValueSet-HIV.B.DE102.md)
* [HIVBDE106](ValueSet-HIV.B.DE106.md)
* [HIVBDE111](ValueSet-HIV.B.DE111.md)
* [HIVBDE115](ValueSet-HIV.B.DE115.md)
* [HIVBDE121](ValueSet-HIV.B.DE121.md)
* [HIVBDE132](ValueSet-HIV.B.DE132.md)
* [HIVBDE136](ValueSet-HIV.B.DE136.md)
* [HIVBDE142](ValueSet-HIV.B.DE142.md)
* [HIVBDE149](ValueSet-HIV.B.DE149.md)
* [HIVBDE15](ValueSet-HIV.B.DE15.md)
* [HIVBDE158](ValueSet-HIV.B.DE158.md)
* [HIVBDE165](ValueSet-HIV.B.DE165.md)
* [HIVBDE172](ValueSet-HIV.B.DE172.md)
* [HIVBDE179](ValueSet-HIV.B.DE179.md)
* [HIVBDE18](ValueSet-HIV.B.DE18.md)
* [HIVBDE191](ValueSet-HIV.B.DE191.md)
* [HIVBDE201](ValueSet-HIV.B.DE201.md)
* [HIVBDE204](ValueSet-HIV.B.DE204.md)
* [HIVBDE207](ValueSet-HIV.B.DE207.md)
* [HIVBDE22](ValueSet-HIV.B.DE22.md)
* [HIVBDE226](ValueSet-HIV.B.DE226.md)
* [HIVBDE237](ValueSet-HIV.B.DE237.md)
* [HIVBDE250](ValueSet-HIV.B.DE250.md)
* [HIVBDE256](ValueSet-HIV.B.DE256.md)
* [HIVBDE261](ValueSet-HIV.B.DE261.md)
* [HIVBDE269](ValueSet-HIV.B.DE269.md)
* [HIVBDE276](ValueSet-HIV.B.DE276.md)
* [HIVBDE284](ValueSet-HIV.B.DE284.md)
* [HIVBDE293](ValueSet-HIV.B.DE293.md)
* [HIVBDE301](ValueSet-HIV.B.DE301.md)
* [HIVBDE306](ValueSet-HIV.B.DE306.md)
* [HIVBDE312](ValueSet-HIV.B.DE312.md)
* [HIVBDE317](ValueSet-HIV.B.DE317.md)
* [HIVBDE325](ValueSet-HIV.B.DE325.md)
* [HIVBDE33](ValueSet-HIV.B.DE33.md)
* [HIVBDE37](ValueSet-HIV.B.DE37.md)
* [HIVBDE44](ValueSet-HIV.B.DE44.md)
* [HIVBDE5](ValueSet-HIV.B.DE5.md)
* [HIVBDE50](ValueSet-HIV.B.DE50.md)
* [HIVBDE61](ValueSet-HIV.B.DE61.md)
* [HIVBDE68](ValueSet-HIV.B.DE68.md)
* [HIVBDE74](ValueSet-HIV.B.DE74.md)
* [HIVBDE8](ValueSet-HIV.B.DE8.md)
* [HIVBDE81](ValueSet-HIV.B.DE81.md)
* [HIVBDE88](ValueSet-HIV.B.DE88.md)
* [HIVBDE94](ValueSet-HIV.B.DE94.md)
* [HIVBDE98](ValueSet-HIV.B.DE98.md)
* [HIVCDE1](ValueSet-HIV.C.DE1.md)
* [HIVCDE101](ValueSet-HIV.C.DE101.md)
* [HIVCDE107](ValueSet-HIV.C.DE107.md)
* [HIVCDE11](ValueSet-HIV.C.DE11.md)
* [HIVCDE112](ValueSet-HIV.C.DE112.md)
* [HIVCDE125](ValueSet-HIV.C.DE125.md)
* [HIVCDE131](ValueSet-HIV.C.DE131.md)
* [HIVCDE138](ValueSet-HIV.C.DE138.md)
* [HIVCDE143](ValueSet-HIV.C.DE143.md)
* [HIVCDE149](ValueSet-HIV.C.DE149.md)
* [HIVCDE157](ValueSet-HIV.C.DE157.md)
* [HIVCDE164](ValueSet-HIV.C.DE164.md)
* [HIVCDE17](ValueSet-HIV.C.DE17.md)
* [HIVCDE24](ValueSet-HIV.C.DE24.md)
* [HIVCDE31](ValueSet-HIV.C.DE31.md)
* [HIVCDE36](ValueSet-HIV.C.DE36.md)
* [HIVCDE41](ValueSet-HIV.C.DE41.md)
* [HIVCDE46](ValueSet-HIV.C.DE46.md)
* [HIVCDE55](ValueSet-HIV.C.DE55.md)
* [HIVCDE63](ValueSet-HIV.C.DE63.md)
* [HIVCDE75](ValueSet-HIV.C.DE75.md)
* [HIVCDE80](ValueSet-HIV.C.DE80.md)
* [HIVCDE91](ValueSet-HIV.C.DE91.md)
* [HIVCDE95](ValueSet-HIV.C.DE95.md)
* [HIVCDE99](ValueSet-HIV.C.DE99.md)
* [HIVConfigDE12](ValueSet-HIV.Config.DE12.md)
* [HIVDDE1](ValueSet-HIV.D.DE1.md)
* [HIVDDE1002](ValueSet-HIV.D.DE1002.md)
* [HIVDDE1010](ValueSet-HIV.D.DE1010.md)
* [HIVDDE1019](ValueSet-HIV.D.DE1019.md)
* [HIVDDE1028](ValueSet-HIV.D.DE1028.md)
* [HIVDDE1034](ValueSet-HIV.D.DE1034.md)
* [HIVDDE128](ValueSet-HIV.D.DE128.md)
* [HIVDDE146](ValueSet-HIV.D.DE146.md)
* [HIVDDE152](ValueSet-HIV.D.DE152.md)
* [HIVDDE156](ValueSet-HIV.D.DE156.md)
* [HIVDDE162](ValueSet-HIV.D.DE162.md)
* [HIVDDE17](ValueSet-HIV.D.DE17.md)
* [HIVDDE170](ValueSet-HIV.D.DE170.md)
* [HIVDDE179](ValueSet-HIV.D.DE179.md)
* [HIVDDE182](ValueSet-HIV.D.DE182.md)
* [HIVDDE186](ValueSet-HIV.D.DE186.md)
* [HIVDDE197](ValueSet-HIV.D.DE197.md)
* [HIVDDE217](ValueSet-HIV.D.DE217.md)
* [HIVDDE225](ValueSet-HIV.D.DE225.md)
* [HIVDDE229](ValueSet-HIV.D.DE229.md)
* [HIVDDE247](ValueSet-HIV.D.DE247.md)
* [HIVDDE259](ValueSet-HIV.D.DE259.md)
* [HIVDDE289](ValueSet-HIV.D.DE289.md)
* [HIVDDE358](ValueSet-HIV.D.DE358.md)
* [HIVDDE370](ValueSet-HIV.D.DE370.md)
* [HIVDDE383](ValueSet-HIV.D.DE383.md)
* [HIVDDE391](ValueSet-HIV.D.DE391.md)
* [HIVDDE399](ValueSet-HIV.D.DE399.md)
* [HIVDDE418](ValueSet-HIV.D.DE418.md)
* [HIVDDE43](ValueSet-HIV.D.DE43.md)
* [HIVDDE430](ValueSet-HIV.D.DE430.md)
* [HIVDDE446](ValueSet-HIV.D.DE446.md)
* [HIVDDE449](ValueSet-HIV.D.DE449.md)
* [HIVDDE457](ValueSet-HIV.D.DE457.md)
* [HIVDDE461](ValueSet-HIV.D.DE461.md)
* [HIVDDE466](ValueSet-HIV.D.DE466.md)
* [HIVDDE519](ValueSet-HIV.D.DE519.md)
* [HIVDDE525](ValueSet-HIV.D.DE525.md)
* [HIVDDE532](ValueSet-HIV.D.DE532.md)
* [HIVDDE537](ValueSet-HIV.D.DE537.md)
* [HIVDDE56](ValueSet-HIV.D.DE56.md)
* [HIVDDE560](ValueSet-HIV.D.DE560.md)
* [HIVDDE569](ValueSet-HIV.D.DE569.md)
* [HIVDDE593](ValueSet-HIV.D.DE593.md)
* [HIVDDE606](ValueSet-HIV.D.DE606.md)
* [HIVDDE610](ValueSet-HIV.D.DE610.md)
* [HIVDDE636](ValueSet-HIV.D.DE636.md)
* [HIVDDE646](ValueSet-HIV.D.DE646.md)
* [HIVDDE65](ValueSet-HIV.D.DE65.md)
* [HIVDDE658](ValueSet-HIV.D.DE658.md)
* [HIVDDE664](ValueSet-HIV.D.DE664.md)
* [HIVDDE668](ValueSet-HIV.D.DE668.md)
* [HIVDDE673](ValueSet-HIV.D.DE673.md)
* [HIVDDE681](ValueSet-HIV.D.DE681.md)
* [HIVDDE688](ValueSet-HIV.D.DE688.md)
* [HIVDDE691](ValueSet-HIV.D.DE691.md)
* [HIVDDE697](ValueSet-HIV.D.DE697.md)
* [HIVDDE706](ValueSet-HIV.D.DE706.md)
* [HIVDDE709](ValueSet-HIV.D.DE709.md)
* [HIVDDE712](ValueSet-HIV.D.DE712.md)
* [HIVDDE719](ValueSet-HIV.D.DE719.md)
* [HIVDDE731](ValueSet-HIV.D.DE731.md)
* [HIVDDE746](ValueSet-HIV.D.DE746.md)
* [HIVDDE75](ValueSet-HIV.D.DE75.md)
* [HIVDDE753](ValueSet-HIV.D.DE753.md)
* [HIVDDE764](ValueSet-HIV.D.DE764.md)
* [HIVDDE778](ValueSet-HIV.D.DE778.md)
* [HIVDDE789](ValueSet-HIV.D.DE789.md)
* [HIVDDE802](ValueSet-HIV.D.DE802.md)
* [HIVDDE808](ValueSet-HIV.D.DE808.md)
* [HIVDDE813](ValueSet-HIV.D.DE813.md)
* [HIVDDE821](ValueSet-HIV.D.DE821.md)
* [HIVDDE828](ValueSet-HIV.D.DE828.md)
* [HIVDDE83](ValueSet-HIV.D.DE83.md)
* [HIVDDE836](ValueSet-HIV.D.DE836.md)
* [HIVDDE845](ValueSet-HIV.D.DE845.md)
* [HIVDDE853](ValueSet-HIV.D.DE853.md)
* [HIVDDE858](ValueSet-HIV.D.DE858.md)
* [HIVDDE864](ValueSet-HIV.D.DE864.md)
* [HIVDDE869](ValueSet-HIV.D.DE869.md)
* [HIVDDE877](ValueSet-HIV.D.DE877.md)
* [HIVDDE893](ValueSet-HIV.D.DE893.md)
* [HIVDDE897](ValueSet-HIV.D.DE897.md)
* [HIVDDE90](ValueSet-HIV.D.DE90.md)
* [HIVDDE903](ValueSet-HIV.D.DE903.md)
* [HIVDDE934](ValueSet-HIV.D.DE934.md)
* [HIVDDE939](ValueSet-HIV.D.DE939.md)
* [HIVDDE942](ValueSet-HIV.D.DE942.md)
* [HIVDDE947](ValueSet-HIV.D.DE947.md)
* [HIVDDE956](ValueSet-HIV.D.DE956.md)
* [HIVDDE973](ValueSet-HIV.D.DE973.md)
* [HIVDDE986](ValueSet-HIV.D.DE986.md)
* [HIVDDE992](ValueSet-HIV.D.DE992.md)
* [HIVEDE104](ValueSet-HIV.E.DE104.md)
* [HIVEDE108](ValueSet-HIV.E.DE108.md)
* [HIVEDE114](ValueSet-HIV.E.DE114.md)
* [HIVEDE127](ValueSet-HIV.E.DE127.md)
* [HIVEDE136](ValueSet-HIV.E.DE136.md)
* [HIVEDE141](ValueSet-HIV.E.DE141.md)
* [HIVEDE145](ValueSet-HIV.E.DE145.md)
* [HIVEDE149](ValueSet-HIV.E.DE149.md)
* [HIVEDE155](ValueSet-HIV.E.DE155.md)
* [HIVEDE168](ValueSet-HIV.E.DE168.md)
* [HIVEDE17](ValueSet-HIV.E.DE17.md)
* [HIVEDE173](ValueSet-HIV.E.DE173.md)
* [HIVEDE180](ValueSet-HIV.E.DE180.md)
* [HIVEDE183](ValueSet-HIV.E.DE183.md)
* [HIVEDE186](ValueSet-HIV.E.DE186.md)
* [HIVEDE190](ValueSet-HIV.E.DE190.md)
* [HIVEDE194](ValueSet-HIV.E.DE194.md)
* [HIVEDE200](ValueSet-HIV.E.DE200.md)
* [HIVEDE204](ValueSet-HIV.E.DE204.md)
* [HIVEDE208](ValueSet-HIV.E.DE208.md)
* [HIVEDE212](ValueSet-HIV.E.DE212.md)
* [HIVEDE216](ValueSet-HIV.E.DE216.md)
* [HIVEDE220](ValueSet-HIV.E.DE220.md)
* [HIVEDE225](ValueSet-HIV.E.DE225.md)
* [HIVEDE230](ValueSet-HIV.E.DE230.md)
* [HIVEDE234](ValueSet-HIV.E.DE234.md)
* [HIVEDE240](ValueSet-HIV.E.DE240.md)
* [HIVEDE246](ValueSet-HIV.E.DE246.md)
* [HIVEDE255](ValueSet-HIV.E.DE255.md)
* [HIVEDE259](ValueSet-HIV.E.DE259.md)
* [HIVEDE264](ValueSet-HIV.E.DE264.md)
* [HIVEDE41](ValueSet-HIV.E.DE41.md)
* [HIVEDE47](ValueSet-HIV.E.DE47.md)
* [HIVEDE52](ValueSet-HIV.E.DE52.md)
* [HIVEDE6](ValueSet-HIV.E.DE6.md)
* [HIVEDE62](ValueSet-HIV.E.DE62.md)
* [HIVEDE67](ValueSet-HIV.E.DE67.md)
* [HIVEDE75](ValueSet-HIV.E.DE75.md)
* [HIVEDE91](ValueSet-HIV.E.DE91.md)
* [HIVGDE13](ValueSet-HIV.G.DE13.md)
* [HIVGDE18](ValueSet-HIV.G.DE18.md)
* [HIVGDE22](ValueSet-HIV.G.DE22.md)
* [HIVGDE29](ValueSet-HIV.G.DE29.md)
* [HIVGDE35](ValueSet-HIV.G.DE35.md)
* [HIVGDE43](ValueSet-HIV.G.DE43.md)
* [HIVGDE48](ValueSet-HIV.G.DE48.md)
* [HIVGDE51](ValueSet-HIV.G.DE51.md)
* [HIVGDE55](ValueSet-HIV.G.DE55.md)
* [HIVGDE62](ValueSet-HIV.G.DE62.md)
* [HIVGDE70](ValueSet-HIV.G.DE70.md)
* [HIVGDE74](ValueSet-HIV.G.DE74.md)
* [HIVHDE1](ValueSet-HIV.H.DE1.md)
* [HIVHDE13](ValueSet-HIV.H.DE13.md)
* [HIVHDE17](ValueSet-HIV.H.DE17.md)
* [HIVHDE23](ValueSet-HIV.H.DE23.md)
* [HIVHDE34](ValueSet-HIV.H.DE34.md)
* [HIVHDE41](ValueSet-HIV.H.DE41.md)
* [HIVHDE50](ValueSet-HIV.H.DE50.md)
* [HIVHDE53](ValueSet-HIV.H.DE53.md)
* [HIVHDE74](ValueSet-HIV.H.DE74.md)
* [HIVIDE2](ValueSet-HIV.I.DE2.md)
* [HIVPRVDE11](ValueSet-HIV.PRV.DE11.md)
* [HIVPRVDE2](ValueSet-HIV.PRV.DE2.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "HIVConcepts",
  "meta" : {
    "profile" : [
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablecodesystem",
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablecodesystem",
      "http://smart.who.int/base/StructureDefinition/SGCodeSystem"
    ]
  },
  "url" : "http://smart.who.int/hiv/CodeSystem/HIVConcepts",
  "version" : "0.4.4",
  "name" : "HIVConcepts",
  "title" : "WHO SMART HIV Concepts CodeSystem",
  "status" : "draft",
  "experimental" : true,
  "date" : "2025-12-10T09:21:32+00:00",
  "publisher" : "WHO",
  "contact" : [
    {
      "name" : "WHO",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://who.int"
        }
      ]
    }
  ],
  "description" : "This code system defines the concepts used in the World Health Organization SMART HIV DAK",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 2093,
  "concept" : [
    {
      "code" : "HIV.A.DE1",
      "display" : "First name",
      "definition" : "Client's first or given name"
    },
    {
      "code" : "HIV.A.DE2",
      "display" : "Family name",
      "definition" : "Client's family name or last name"
    },
    {
      "code" : "HIV.A.DE3",
      "display" : "Visit date",
      "definition" : "The date and time of the client's visit"
    },
    {
      "code" : "HIV.A.DE4",
      "display" : "Referral",
      "definition" : "If client was referred for care"
    },
    {
      "code" : "HIV.A.DE5",
      "display" : "Referred by",
      "definition" : "How the client was referred"
    },
    {
      "code" : "HIV.A.DE6",
      "display" : "Community",
      "definition" : "Referred by the community level services"
    },
    {
      "code" : "HIV.A.DE7",
      "display" : "Facility",
      "definition" : "Referred by the health facility"
    },
    {
      "code" : "HIV.A.DE8",
      "display" : "Unique identifier",
      "definition" : "Unique identifier generated for new clients or a universal ID, if used in the country"
    },
    {
      "code" : "HIV.A.DE9",
      "display" : "National ID",
      "definition" : "National unique identifier assigned to the client, if used in the country"
    },
    {
      "code" : "HIV.A.DE10",
      "display" : "National health ID",
      "definition" : "National health unique identifier assigned to the client, if used in the country"
    },
    {
      "code" : "HIV.A.DE11",
      "display" : "National programme ID",
      "definition" : "National programme unique identifier assigned to the client, if used in the country"
    },
    {
      "code" : "HIV.A.DE12",
      "display" : "National health insurance ID",
      "definition" : "National health insurance unique identifier assigned to the client, if used in the country"
    },
    {
      "code" : "HIV.A.DE13",
      "display" : "Country of birth",
      "definition" : "Country where the client was born"
    },
    {
      "code" : "HIV.A.DE14",
      "display" : "Date of birth",
      "definition" : "The client's date of birth (DOB) if known"
    },
    {
      "code" : "HIV.A.DE15",
      "display" : "Date of birth unknown",
      "definition" : "Is the client's DOB is unknown?"
    },
    {
      "code" : "HIV.A.DE16",
      "display" : "Estimated age",
      "definition" : "If DOB is unknown, enter the client's estimated age. Display client's age in number of years."
    },
    {
      "code" : "HIV.A.DE17",
      "display" : "Age",
      "definition" : "Calculated age (number of years) of the client based on date of birth"
    },
    {
      "code" : "HIV.A.DE18",
      "display" : "Gender",
      "definition" : "Gender of the client"
    },
    {
      "code" : "HIV.A.DE19",
      "display" : "Female",
      "definition" : "Client identifies as female"
    },
    {
      "code" : "HIV.A.DE20",
      "display" : "Male",
      "definition" : "Client identifies as male"
    },
    {
      "code" : "HIV.A.DE21",
      "display" : "Transgender male",
      "definition" : "Client identifies as transgender male"
    },
    {
      "code" : "HIV.A.DE22",
      "display" : "Transgender female",
      "definition" : "Client identifies as transgender female"
    },
    {
      "code" : "HIV.A.DE23",
      "display" : "Other",
      "definition" : "Additional category"
    },
    {
      "code" : "HIV.A.DE24",
      "display" : "Other (specify)",
      "definition" : "Additional category (please specify)"
    },
    {
      "code" : "HIV.A.DE25",
      "display" : "Sex",
      "definition" : "Sex of the client assigned at birth"
    },
    {
      "code" : "HIV.A.DE26",
      "display" : "Female",
      "definition" : "Client identifies as female"
    },
    {
      "code" : "HIV.A.DE27",
      "display" : "Male",
      "definition" : "Client identifies as male"
    },
    {
      "code" : "HIV.A.DE28",
      "display" : "Other",
      "definition" : "Client identifies in non-binary way or as a sexual and gender minority (or minorities)"
    },
    {
      "code" : "HIV.A.DE29",
      "display" : "Address",
      "definition" : "Client's home address or address which the client is consenting to disclose"
    },
    {
      "code" : "HIV.A.DE30",
      "display" : "Marital Status",
      "definition" : "Client's current marital status"
    },
    {
      "code" : "HIV.A.DE31",
      "display" : "Unmarried",
      "definition" : "Client does not have an active marriage contract"
    },
    {
      "code" : "HIV.A.DE32",
      "display" : "Never married",
      "definition" : "Client has never entered into a marriage contract"
    },
    {
      "code" : "HIV.A.DE33",
      "display" : "Married",
      "definition" : "A current marriage contract is active"
    },
    {
      "code" : "HIV.A.DE34",
      "display" : "Polygamous",
      "definition" : "Client is in a polygamous union"
    },
    {
      "code" : "HIV.A.DE35",
      "display" : "Divorced",
      "definition" : "Client is divorced, whereby marriage contract has been declared dissolved and inactive"
    },
    {
      "code" : "HIV.A.DE36",
      "display" : "Widowed",
      "definition" : "Client's spouse has died"
    },
    {
      "code" : "HIV.A.DE37",
      "display" : "Unknown",
      "definition" : "Client does not wish to disclose marital status"
    },
    {
      "code" : "HIV.A.DE38",
      "display" : "Domestic partner",
      "definition" : "Client reports that they are in a domestic partnership"
    },
    {
      "code" : "HIV.A.DE39",
      "display" : "Annulled",
      "definition" : "Client's marriage contract has been declared null and to have not existed"
    },
    {
      "code" : "HIV.A.DE40",
      "display" : "Legally separated",
      "definition" : "Client is legally separated from their spouse"
    },
    {
      "code" : "HIV.A.DE41",
      "display" : "Interlocutory",
      "definition" : "Client is subject to an interlocutory decree"
    },
    {
      "code" : "HIV.A.DE42",
      "display" : "Telephone number",
      "definition" : "Client's telephone number (a landline or a mobile phone number)"
    },
    {
      "code" : "HIV.A.DE43",
      "display" : "Administrative Area",
      "definition" : "This should be a context-specific list of administrative areas, such as villages, districts, etc. The purpose of this data element is to allow for grouping and flagging of client data to a particular facility's catchment area. This can be input into the system by the end user OR it can be automated in the database based on the end user's attributes."
    },
    {
      "code" : "HIV.A.DE44",
      "display" : "Communication consent",
      "definition" : "Indication that client gave consent to be contacted"
    },
    {
      "code" : "HIV.A.DE45",
      "display" : "Reminder messages",
      "definition" : "Whether client wants to receive text or other messages as follow-up for HIV services"
    },
    {
      "code" : "HIV.A.DE46",
      "display" : "Communication preference(s)",
      "definition" : "How the client would like to receive family planning communications"
    },
    {
      "code" : "HIV.A.DE47",
      "display" : "Text message/SMS",
      "definition" : "The client would like to receive communications via Text message/SMS"
    },
    {
      "code" : "HIV.A.DE48",
      "display" : "Voice call",
      "definition" : "Client would like to receive communications via voice call"
    },
    {
      "code" : "HIV.A.DE49",
      "display" : "Client's email",
      "definition" : "Client's primary email account where the client can be contacted"
    },
    {
      "code" : "HIV.A.DE50",
      "display" : "Alternate contact's name",
      "definition" : "Name of an alternate contact, which could be next of kin (e.g. partner, husband, mother, sibling, etc.). The alternate contact would be used in the case of an emergency situation."
    },
    {
      "code" : "HIV.A.DE51",
      "display" : "Alternate contact's phone number",
      "definition" : "Phone number of the alternate contact"
    },
    {
      "code" : "HIV.A.DE52",
      "display" : "Alternate contact's address",
      "definition" : "Alternate contact's home address or address which the client is consenting to disclose"
    },
    {
      "code" : "HIV.A.DE53",
      "display" : "Alternate contact relationship",
      "definition" : "The alternate contact's relationship to the client (e.g. partner, husband, mother, sibling, etc.)"
    },
    {
      "code" : "HIV.B.DE1",
      "display" : "Reason for visit",
      "definition" : "Reason for HIV testing services visit"
    },
    {
      "code" : "HIV.B.DE2",
      "display" : "First-time HIV test",
      "definition" : "First encounter for screening for human immunodeficiency virus"
    },
    {
      "code" : "HIV.B.DE3",
      "display" : "Retesting for HIV",
      "definition" : "Retesting for human immunodeficiency virus"
    },
    {
      "code" : "HIV.B.DE4",
      "display" : "HIV testing services visit",
      "definition" : "Client attending facility for HIV testing services visit"
    },
    {
      "code" : "HIV.B.DE5",
      "display" : "Referred through partner services",
      "definition" : "Client reported coming to the facility after receiving a provider-assisted referral or patient referral from a contact or partner"
    },
    {
      "code" : "HIV.B.DE6",
      "display" : "Partner or contact of an index case",
      "definition" : "The client is a contact or partner of a person diagnosed with HIV (an index case)"
    },
    {
      "code" : "HIV.B.DE7",
      "display" : "Partner or contact of an HIV testing client (non-index case)",
      "definition" : "The client is a contact or partner identified through partner or social network services, but is not known to be a partner of an index-case"
    },
    {
      "code" : "HIV.B.DE8",
      "display" : "Type of contact or partner for partner services",
      "definition" : "Client's relationship to the person that referred the client for partner services or family services"
    },
    {
      "code" : "HIV.B.DE9",
      "display" : "Biological child",
      "definition" : "Client is the biological child of the person that referred the client for family services"
    },
    {
      "code" : "HIV.B.DE10",
      "display" : "Drug-injecting partner",
      "definition" : "Client is a drug-injecting partner of the person that referred the client for partner services"
    },
    {
      "code" : "HIV.B.DE11",
      "display" : "Sexual partner",
      "definition" : "Client is a sexual partner of the person that referred the client for partner services"
    },
    {
      "code" : "HIV.B.DE12",
      "display" : "Social contact",
      "definition" : "Client is a social contact of the person that referred the client for social-network services"
    },
    {
      "code" : "HIV.B.DE13",
      "display" : "Contact with and (suspected) exposure to HIV",
      "definition" : "When the client is reported to have had suspected exposure to HIV"
    },
    {
      "code" : "HIV.B.DE14",
      "display" : "Date/time of suspected exposure to HIV",
      "definition" : "Date and time when the client had suspected exposure to HIV"
    },
    {
      "code" : "HIV.B.DE15",
      "display" : "Testing entry point",
      "definition" : "Whether testing is happening in the community or at a facility"
    },
    {
      "code" : "HIV.B.DE16",
      "display" : "Community-level testing",
      "definition" : "Testing is happening in the community, which includes mobile testing"
    },
    {
      "code" : "HIV.B.DE17",
      "display" : "Facility-level testing",
      "definition" : "Testing is happening at a facility"
    },
    {
      "code" : "HIV.B.DE18",
      "display" : "Entry point for community-level testing",
      "definition" : "Specific point in the community where testing is happening"
    },
    {
      "code" : "HIV.B.DE19",
      "display" : "Mobile testing (e.g. through vans or temporary testing facilities)",
      "definition" : "The client tested through mobile testing, such as through vans or temporary testing facilities"
    },
    {
      "code" : "HIV.B.DE20",
      "display" : "Voluntary counselling and testing centres (not within a health facility setting)",
      "definition" : "The client tested at a voluntary counselling and testing centre (not in a health facility setting)"
    },
    {
      "code" : "HIV.B.DE21",
      "display" : "Other community-based testing",
      "definition" : "The client tested through another type of community-based testing"
    },
    {
      "code" : "HIV.B.DE22",
      "display" : "Entry point for facility-level testing",
      "definition" : "Specific point where testing is happening at a facility"
    },
    {
      "code" : "HIV.B.DE23",
      "display" : "Provider-initiated tested in a clinic or emergency facility",
      "definition" : "The client tested though provider-initiated HIV testing & counselling, which could be at an emergency facility"
    },
    {
      "code" : "HIV.B.DE24",
      "display" : "Antenatal care clinic",
      "definition" : "The client tested at an antenatal care clinic, including labour and delivery"
    },
    {
      "code" : "HIV.B.DE25",
      "display" : "Voluntary counselling and testing (within a health facility setting)",
      "definition" : "The client tested through voluntary counselling and testing (within a health facility setting)"
    },
    {
      "code" : "HIV.B.DE26",
      "display" : "Family planning clinic",
      "definition" : "The client tested at a family planning clinic"
    },
    {
      "code" : "HIV.B.DE27",
      "display" : "Other facility-level testing",
      "definition" : "The client tested at another type of facility"
    },
    {
      "code" : "HIV.B.DE28",
      "display" : "Tuberculosis (TB) clinic",
      "definition" : "The client tested at a TB clinic"
    },
    {
      "code" : "HIV.B.DE29",
      "display" : "Currently pregnant",
      "definition" : "Client is currently pregnant"
    },
    {
      "code" : "HIV.B.DE30",
      "display" : "Gestational age",
      "definition" : "Gestational age in weeks and/or days depending on the source of gestational age"
    },
    {
      "code" : "HIV.B.DE31",
      "display" : "Expected date of delivery (EDD)",
      "definition" : "Expected date of delivery based on gestational age"
    },
    {
      "code" : "HIV.B.DE32",
      "display" : "Breastfeeding",
      "definition" : "Infant is being breastfed by mother"
    },
    {
      "code" : "HIV.B.DE33",
      "display" : "Partner HIV status (reported)",
      "definition" : "The HIV status of the client's partner."
    },
    {
      "code" : "HIV.B.DE34",
      "display" : "HIV-positive",
      "definition" : "Client's partner is HIV-positive"
    },
    {
      "code" : "HIV.B.DE35",
      "display" : "HIV-negative",
      "definition" : "Client's partner is HIV-negative"
    },
    {
      "code" : "HIV.B.DE36",
      "display" : "Unknown",
      "definition" : "Don't know HIV status - client does not know partner's HIV status"
    },
    {
      "code" : "HIV.B.DE37",
      "display" : "Partner is from a key population",
      "definition" : "Client's partner is a member of a key population, that has an increased risk of HIV"
    },
    {
      "code" : "HIV.B.DE38",
      "display" : "Sex worker",
      "definition" : "Client's partner is a sex worker"
    },
    {
      "code" : "HIV.B.DE39",
      "display" : "Men who have sex with men",
      "definition" : "Client's partner is a man who has sex with men"
    },
    {
      "code" : "HIV.B.DE40",
      "display" : "Trans and gender-diverse people",
      "definition" : "Client's partner identifies as trans and gender-diverse"
    },
    {
      "code" : "HIV.B.DE41",
      "display" : "People who inject drugs",
      "definition" : "Client's partner is a person who injects drugs"
    },
    {
      "code" : "HIV.B.DE42",
      "display" : "People living in prisons and other closed settings",
      "definition" : "Client's partner lives in a prison or other closed setting"
    },
    {
      "code" : "HIV.B.DE43",
      "display" : "Has used an HIV self-test before (reported)",
      "definition" : "The client reported having used an HIV self-test before"
    },
    {
      "code" : "HIV.B.DE44",
      "display" : "HIV self-test result",
      "definition" : "Results from the reported HIV self-test"
    },
    {
      "code" : "HIV.B.DE45",
      "display" : "Reactive",
      "definition" : "The HIV self-test was reactive"
    },
    {
      "code" : "HIV.B.DE46",
      "display" : "Non-reactive",
      "definition" : "The HIV self-test was non-reactive"
    },
    {
      "code" : "HIV.B.DE47",
      "display" : "Invalid",
      "definition" : "The HIV self-test was invalid"
    },
    {
      "code" : "HIV.B.DE48",
      "display" : "Date of HIV self-test",
      "definition" : "Date when the HIV self-test was conducted"
    },
    {
      "code" : "HIV.B.DE49",
      "display" : "Key population member",
      "definition" : "Client is a member of a key population that has an increased risk of HIV"
    },
    {
      "code" : "HIV.B.DE50",
      "display" : "Key population member type",
      "definition" : "The type of key population that the client is included in"
    },
    {
      "code" : "HIV.B.DE51",
      "display" : "Sex worker",
      "definition" : "Client is a sex worker"
    },
    {
      "code" : "HIV.B.DE52",
      "display" : "Men who have sex with men",
      "definition" : "Client is a man who has sex with men"
    },
    {
      "code" : "HIV.B.DE53",
      "display" : "Trans and gender-diverse people",
      "definition" : "Client identifies as trans and gender-diverse"
    },
    {
      "code" : "HIV.B.DE54",
      "display" : "People who inject drugs",
      "definition" : "Client is a person who injects drugs"
    },
    {
      "code" : "HIV.B.DE55",
      "display" : "People living in prisons and other closed settings",
      "definition" : "Client lives in a prison or another closed setting"
    },
    {
      "code" : "HIV.B.DE56",
      "display" : "Adolescent girl",
      "definition" : "Calculated field based on age and gender, if client is 10 years or older and under 20 years old"
    },
    {
      "code" : "HIV.B.DE57",
      "display" : "Young woman",
      "definition" : "Calculated field based on age and gender, if client is 20 years or older and under 25 years old"
    },
    {
      "code" : "HIV.B.DE58",
      "display" : "Orphan or vulnerable child",
      "definition" : "Client considered an orphan or vulnerable child"
    },
    {
      "code" : "HIV.B.DE59",
      "display" : "Informed of HIV test result",
      "definition" : "Client has been informed of their HIV test result"
    },
    {
      "code" : "HIV.B.DE60",
      "display" : "Date HIV test results returned",
      "definition" : "Date HIV test result returned to client"
    },
    {
      "code" : "HIV.B.DE61",
      "display" : "HIV exposure type",
      "definition" : "Ways in which the client was exposed to HIV"
    },
    {
      "code" : "HIV.B.DE62",
      "display" : "Occupational",
      "definition" : "Occupational exposure to HIV"
    },
    {
      "code" : "HIV.B.DE63",
      "display" : "Non-occupational violent",
      "definition" : "Non-occupational violent exposure to HIV"
    },
    {
      "code" : "HIV.B.DE64",
      "display" : "Non-occupational consensual sex",
      "definition" : "Exposure to HIV through non-occupational consensual sex"
    },
    {
      "code" : "HIV.B.DE65",
      "display" : "Date informed of HIV-positive diagnosis",
      "definition" : "The date on which the client was diagnosed with HIV"
    },
    {
      "code" : "HIV.B.DE66",
      "display" : "HIV diagnosing facility",
      "definition" : "The facility where the client received an HIV-positive diagnosis"
    },
    {
      "code" : "HIV.B.DE67",
      "display" : "Date of first positive test indicative of HIV diagnosis",
      "definition" : "Earliest date of HIV diagnosis determined according to the national HIV testing algorithm"
    },
    {
      "code" : "HIV.B.DE68",
      "display" : "HIV serotype",
      "definition" : "The client's HIV serotype"
    },
    {
      "code" : "HIV.B.DE69",
      "display" : "HIV-1",
      "definition" : "The client has HIV-1"
    },
    {
      "code" : "HIV.B.DE70",
      "display" : "HIV-2",
      "definition" : "The client has HIV-2"
    },
    {
      "code" : "HIV.B.DE71",
      "display" : "HIV diagnosis date",
      "definition" : "Date diagnosis was returned to client"
    },
    {
      "code" : "HIV.B.DE72",
      "display" : "ART start date",
      "definition" : "The date on which the client started or restarted antiretroviral therapy (ART)"
    },
    {
      "code" : "HIV.B.DE73",
      "display" : "Age at diagnosis",
      "definition" : "The client's age (in years) when given an HIV diagnosis"
    },
    {
      "code" : "HIV.B.DE74",
      "display" : "Type of contact elicited",
      "definition" : "Client's relationship to the contact identified for voluntary partner services or family services"
    },
    {
      "code" : "HIV.B.DE75",
      "display" : "Biological child",
      "definition" : "Contact identified for family services is the biological child of the client"
    },
    {
      "code" : "HIV.B.DE76",
      "display" : "Drug-injecting partner",
      "definition" : "Contact identified for partner services is a drug-injecting partner of the client"
    },
    {
      "code" : "HIV.B.DE77",
      "display" : "Sexual partner",
      "definition" : "Contact identified for partner services is a sexual partner of the client"
    },
    {
      "code" : "HIV.B.DE78",
      "display" : "Social contact",
      "definition" : "Contact identified for social-network services is a social contact of the client"
    },
    {
      "code" : "HIV.B.DE79",
      "display" : "HIV test ordered",
      "definition" : "An HIV test of the client was ordered by the provider"
    },
    {
      "code" : "HIV.B.DE80",
      "display" : "HIV test conducted",
      "definition" : "An HIV test was performed on the client during the visit"
    },
    {
      "code" : "HIV.B.DE81",
      "display" : "HIV test type",
      "definition" : "Type of HIV test"
    },
    {
      "code" : "HIV.B.DE82",
      "display" : "Rapid diagnostic test for HIV",
      "definition" : "Antibody test for HIV performed with a rapid diagnostic"
    },
    {
      "code" : "HIV.B.DE83",
      "display" : "Enzyme immunoassay for HIV",
      "definition" : "Antibody test for HIV performed with an enzyme immunoassay"
    },
    {
      "code" : "HIV.B.DE84",
      "display" : "Nucleic acid test for HIV",
      "definition" : "Virological test, which includes testing for early infant diagnosis"
    },
    {
      "code" : "HIV.B.DE85",
      "display" : "Dual HIV/syphilis rapid diagnostic test",
      "definition" : "Antibody test for HIV and syphilis performed with a rapid diagnostic"
    },
    {
      "code" : "HIV.B.DE86",
      "display" : "HIV self-test",
      "definition" : "Antibody test for HIV performed by self-tester using a rapid diagnostic"
    },
    {
      "code" : "HIV.B.DE87",
      "display" : "Date HIV test sent",
      "definition" : "Date HIV specimen was sent to lab"
    },
    {
      "code" : "HIV.B.DE88",
      "display" : "Assay number in testing strategy",
      "definition" : "The number of the assay (test kit) in the HIV testing strategy"
    },
    {
      "code" : "HIV.B.DE89",
      "display" : "Assay 0",
      "definition" : "A community outreach test-for-triage or self-test which is not included in the HIV testing strategy"
    },
    {
      "code" : "HIV.B.DE90",
      "display" : "Assay 1",
      "definition" : "The first test in the HIV testing strategy"
    },
    {
      "code" : "HIV.B.DE91",
      "display" : "Assay 2",
      "definition" : "The second test in the HIV testing strategy"
    },
    {
      "code" : "HIV.B.DE92",
      "display" : "Assay 3",
      "definition" : "The third test in the HIV testing strategy"
    },
    {
      "code" : "HIV.B.DE93",
      "display" : "Assay 1 repeated",
      "definition" : "The first test in the HIV testing strategy"
    },
    {
      "code" : "HIV.B.DE94",
      "display" : "Test result of HIV assay 1",
      "definition" : "The result of the first HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.B.DE95",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.B.DE96",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.B.DE97",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.B.DE98",
      "display" : "Test result of HIV assay 2",
      "definition" : "The result of the second HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.B.DE99",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.B.DE100",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.B.DE101",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.B.DE102",
      "display" : "Test result of HIV assay 3",
      "definition" : "The result of the third HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.B.DE103",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.B.DE104",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.B.DE105",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.B.DE106",
      "display" : "Test result of HIV assay 1 repeated",
      "definition" : "The result of the repeated first HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.B.DE107",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.B.DE108",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.B.DE109",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.B.DE110",
      "display" : "HIV test date",
      "definition" : "Date of the HIV test"
    },
    {
      "code" : "HIV.B.DE111",
      "display" : "HIV test result",
      "definition" : "The result from HIV testing after applying the testing algorithm"
    },
    {
      "code" : "HIV.B.DE112",
      "display" : "HIV-positive",
      "definition" : "Test result is HIV-positive"
    },
    {
      "code" : "HIV.B.DE113",
      "display" : "HIV-negative",
      "definition" : "Test result is HIV-negative"
    },
    {
      "code" : "HIV.B.DE114",
      "display" : "HIV-inconclusive",
      "definition" : "Test result is HIV-inconclusive"
    },
    {
      "code" : "HIV.B.DE115",
      "display" : "HIV status",
      "definition" : "HIV status reported after applying the national HIV testing algorithm. No single HIV test can provide an HIV-positive diagnosis."
    },
    {
      "code" : "HIV.B.DE116",
      "display" : "HIV-positive",
      "definition" : "Client is HIV-positive"
    },
    {
      "code" : "HIV.B.DE117",
      "display" : "HIV-negative",
      "definition" : "Client is HIV-negative"
    },
    {
      "code" : "HIV.B.DE118",
      "display" : "Unknown",
      "definition" : "Client has unknown HIV status"
    },
    {
      "code" : "HIV.B.DE119",
      "display" : "Date positive HIV test confirmed",
      "definition" : "Date patient received positive HIV test confirmation (with written documentation)"
    },
    {
      "code" : "HIV.B.DE120",
      "display" : "Site where positive HIV test confirmed",
      "definition" : "Name or identifier of health facility where HIV test was confirmed"
    },
    {
      "code" : "HIV.B.DE121",
      "display" : "Probable route of transmission",
      "definition" : "Probable route(s) of transmission of HIV to client"
    },
    {
      "code" : "HIV.B.DE122",
      "display" : "Heterosexual sex",
      "definition" : "Probable route of HIV transmission was through heterosexual sex"
    },
    {
      "code" : "HIV.B.DE123",
      "display" : "Sex between men",
      "definition" : "Probable route of HIV transmission was through sex between men"
    },
    {
      "code" : "HIV.B.DE124",
      "display" : "Unprotected intercourse during sex work",
      "definition" : "Probable route of HIV transmission was through unprotected intercourse during sex work"
    },
    {
      "code" : "HIV.B.DE125",
      "display" : "Injecting drug use with unsterile equipment",
      "definition" : "Probable route of HIV transmission was through injecting drug use with unsterile equipment"
    },
    {
      "code" : "HIV.B.DE126",
      "display" : "Nosocomial",
      "definition" : "Probable route of HIV transmission was nosocomial"
    },
    {
      "code" : "HIV.B.DE127",
      "display" : "Vertical",
      "definition" : "Probable route of HIV transmission to an infant was during pregnancy, labour, delivery and breastfeeding (vertical transmission)"
    },
    {
      "code" : "HIV.B.DE128",
      "display" : "Other",
      "definition" : "Probable route of HIV transmission was other and may include needle accidents, blood transfusion, blood products or organ/tissue donations, tattoos, piercings, circumcision, or acupuncture."
    },
    {
      "code" : "HIV.B.DE129",
      "display" : "Partner HIV test conducted",
      "definition" : "If the client does not know the HIV status of the client's partner(s), offer to test and add results here"
    },
    {
      "code" : "HIV.B.DE130",
      "display" : "Partner HIV test ordered",
      "definition" : "An HIV test for the client's partner has been ordered"
    },
    {
      "code" : "HIV.B.DE131",
      "display" : "Partner HIV test date",
      "definition" : "Date of client's partner's HIV test"
    },
    {
      "code" : "HIV.B.DE132",
      "display" : "Partner HIV test result",
      "definition" : "The HIV test result of the client's partner"
    },
    {
      "code" : "HIV.B.DE133",
      "display" : "HIV-positive",
      "definition" : "Test result is HIV-positive"
    },
    {
      "code" : "HIV.B.DE134",
      "display" : "HIV-negative",
      "definition" : "Test result is HIV-negative"
    },
    {
      "code" : "HIV.B.DE135",
      "display" : "HIV-inconclusive",
      "definition" : "Test result is HIV-inconclusive"
    },
    {
      "code" : "HIV.B.DE136",
      "display" : "Partner HIV status (confirmed)",
      "definition" : "The HIV status of a sexual or drug-injecting partner of the client, based on a confirmed test result"
    },
    {
      "code" : "HIV.B.DE137",
      "display" : "HIV-positive",
      "definition" : "Client's partner is HIV-positive"
    },
    {
      "code" : "HIV.B.DE138",
      "display" : "HIV-negative",
      "definition" : "Client's partner is HIV-negative"
    },
    {
      "code" : "HIV.B.DE139",
      "display" : "Unknown",
      "definition" : "Client's partner HIV status is unknown"
    },
    {
      "code" : "HIV.B.DE140",
      "display" : "Partner on ART",
      "definition" : "Partner of the client is on ART"
    },
    {
      "code" : "HIV.B.DE141",
      "display" : "Partner virally suppressed on ART",
      "definition" : "ART and virally suppression status of a partner of the client"
    },
    {
      "code" : "HIV.B.DE142",
      "display" : "Counselling provided",
      "definition" : "Whether counselling was provided to a client during the visit"
    },
    {
      "code" : "HIV.B.DE143",
      "display" : "HIV-positive counselling conducted",
      "definition" : "Whether counselling was provided to a client who has been diagnosed with HIV"
    },
    {
      "code" : "HIV.B.DE144",
      "display" : "Hepatitis B positive counselling conducted",
      "definition" : "Whether counselling was provided to a client who has been diagnosed with hepatitis B"
    },
    {
      "code" : "HIV.B.DE145",
      "display" : "Hepatitis C positive counselling conducted",
      "definition" : "Whether counselling was provided to a client who has been diagnosed with hepatitis C"
    },
    {
      "code" : "HIV.B.DE146",
      "display" : "Syphilis counselling, treatment and further testing",
      "definition" : "Whether counselling and treatment was provided to a client who has been diagnosed with syphilis. Additional testing (RPR test) recommended."
    },
    {
      "code" : "HIV.B.DE147",
      "display" : "Linked to enrolment in care and ART initiation",
      "definition" : "Linkage made from HIV testing to enrolment in care following an HIV diagnosis"
    },
    {
      "code" : "HIV.B.DE148",
      "display" : "VMMC counselling provided",
      "definition" : "Whether counselling for voluntary medical male circumcision (VMMC) was provided following an HIV-negative test"
    },
    {
      "code" : "HIV.B.DE149",
      "display" : "Prevention services offered and referrals",
      "definition" : "Offer or refer to prevention services"
    },
    {
      "code" : "HIV.B.DE150",
      "display" : "Offer male and female condoms and condom-compatible lubricants",
      "definition" : "Offer male and female condoms and condom-compatible lubricants"
    },
    {
      "code" : "HIV.B.DE151",
      "display" : "Offer pre-exposure prophylaxis (PrEP) for people at elevated risk for HIV acquisition",
      "definition" : "Offer pre-exposure prophylaxis (PrEP) to people with substantial ongoing risk of HIV infection"
    },
    {
      "code" : "HIV.B.DE152",
      "display" : "Offer post-exposure prophylaxis (PEP) following suspected exposure",
      "definition" : "Offer or refer client for PEP following suspected exposure"
    },
    {
      "code" : "HIV.B.DE153",
      "display" : "Voluntary medical male circumcision (VMMC)",
      "definition" : "Offer referral for VMMC services"
    },
    {
      "code" : "HIV.B.DE154",
      "display" : "Harm reduction for people who inject drugs",
      "definition" : "Offer or refer to harm reduction services for people who inject drugs (needle and syringe programmes, opioid substitution therapy, other drug-dependence treatment and opioid overdose prevention and management)"
    },
    {
      "code" : "HIV.B.DE155",
      "display" : "Behavioural interventions to support risk reduction, particularly for people with HIV and members of key populations",
      "definition" : "Offer or refer to behavioural interventions to support risk reduction, particularly for people with HIV and members of key populations"
    },
    {
      "code" : "HIV.B.DE156",
      "display" : "HIV testing for partners and biological children",
      "definition" : "Offer voluntary testing for all partners and biological children of positive cases (includes partner services and index case testing), as welll as partners and social contacts of people from key populations, where appropriate"
    },
    {
      "code" : "HIV.B.DE157",
      "display" : "HIV testing for partners and social contacts of people from key populations, where appropriate",
      "definition" : "Offer voluntary testing for partners and social contacts of people from key populations, where appropriate"
    },
    {
      "code" : "HIV.B.DE158",
      "display" : "Sexual and reproductive health integrated services",
      "definition" : "Offer or refer to sexual and reproductive health services"
    },
    {
      "code" : "HIV.B.DE159",
      "display" : "Contraception and family planning",
      "definition" : "Offer contraception and family planning services"
    },
    {
      "code" : "HIV.B.DE160",
      "display" : "Check pregnancy status",
      "definition" : "Check women's pregnancy status"
    },
    {
      "code" : "HIV.B.DE161",
      "display" : "Prevention of mother-to-child transmission counselling",
      "definition" : "Offer services for prevention of mother-to-child transmission (counselling)"
    },
    {
      "code" : "HIV.B.DE162",
      "display" : "Cervical cancer screening and treatment counselling",
      "definition" : "Offer cervical cancer screening and treatment counselling and services"
    },
    {
      "code" : "HIV.B.DE163",
      "display" : "Anal cancer screening (for men who have sex with men)",
      "definition" : "Offer services for anal cancer screening (for men who have sex with men)"
    },
    {
      "code" : "HIV.B.DE164",
      "display" : "STI testing and treatment services",
      "definition" : "Offer sexually transmitted infection (STI) testing and treatment services"
    },
    {
      "code" : "HIV.B.DE165",
      "display" : "Offer other clinical services",
      "definition" : "Other clinical services offered or referrals given to the client"
    },
    {
      "code" : "HIV.B.DE166",
      "display" : "Assessment and provision of vaccinations",
      "definition" : "Assessment and provision of vaccinations, such as for people from key populations, pregnant women and infants; and, where appropriate, tetanus vaccination for adolescent boys and men receiving VMMC"
    },
    {
      "code" : "HIV.B.DE167",
      "display" : "Hepatitis B (HBV) and hepatitis C virus (HCV) testing and treatment provided",
      "definition" : "Offer or refer for HBV and/or HCV testing and treatment"
    },
    {
      "code" : "HIV.B.DE168",
      "display" : "Co-trimoxazole chemoprophylaxis to prevent Pneumocystis carinii pneumonia provided",
      "definition" : "Offer or refer for co-trimoxazole chemoprophylaxis to prevent pneumocystis carinii pneumonia"
    },
    {
      "code" : "HIV.B.DE169",
      "display" : "Intensified TB case finding and linkage to TB treatment provided",
      "definition" : "Offer or refer for intensified TB case finding and linkage to TB treatment"
    },
    {
      "code" : "HIV.B.DE170",
      "display" : "Provision of isoniazid preventive therapy if person does not have TB",
      "definition" : "Offer or refer for provision of isoniazid preventive therapy if person does not have TB"
    },
    {
      "code" : "HIV.B.DE171",
      "display" : "Malaria prevention (such as bed nets and prophylaxis), depending on epidemiology",
      "definition" : "Offer or refer for malaria prevention (such as bed nets and prophylaxis), depending on epidemiology"
    },
    {
      "code" : "HIV.B.DE172",
      "display" : "Other support services",
      "definition" : "Offer or refer for other support services"
    },
    {
      "code" : "HIV.B.DE173",
      "display" : "Mental health services",
      "definition" : "Offer or refer for mental health services"
    },
    {
      "code" : "HIV.B.DE174",
      "display" : "Psychosocial counselling, support and treatment adherence counselling",
      "definition" : "Offer or refer for psychosocial counselling, support and treatment adherence counselling"
    },
    {
      "code" : "HIV.B.DE175",
      "display" : "Support for disclosure and partner services",
      "definition" : "Offer or refer for support for disclosure and partner services"
    },
    {
      "code" : "HIV.B.DE176",
      "display" : "Legal and social services",
      "definition" : "Offer or refer for legal and social services"
    },
    {
      "code" : "HIV.B.DE177",
      "display" : "Services for responding to violence against women",
      "definition" : "Offer or refer for services for responding to violence against women, including first-line support and psychosocial support, post-rape care and other support services including shelters, legal services and women and child protection services"
    },
    {
      "code" : "HIV.B.DE178",
      "display" : "Clinical enquiry for intimate partner violence (IPV) done",
      "definition" : "Whether a clinical enquiry for intimate partner violence was conducted"
    },
    {
      "code" : "HIV.B.DE179",
      "display" : "Intimate partner violence enquiry results",
      "definition" : "Result of medical inquiry for intimate partner violence"
    },
    {
      "code" : "HIV.B.DE180",
      "display" : "Client received treatment and/or counselling as needed",
      "definition" : "Client received treatment and/or counselling as needed"
    },
    {
      "code" : "HIV.B.DE181",
      "display" : "Client was referred",
      "definition" : "Client was referred to another provider/facility"
    },
    {
      "code" : "HIV.B.DE182",
      "display" : "No action necessary",
      "definition" : "No additional action was deemed necessary"
    },
    {
      "code" : "HIV.B.DE183",
      "display" : "Other IPV result",
      "definition" : "Other intimate partner violence (IPV) result not described above"
    },
    {
      "code" : "HIV.B.DE184",
      "display" : "Other IPV result (specify)",
      "definition" : "Other intimate partner violence (IPV) result not described above (specify)"
    },
    {
      "code" : "HIV.B.DE185",
      "display" : "Offered voluntary partner services",
      "definition" : "Whether the client was offered voluntary partner services or family services"
    },
    {
      "code" : "HIV.B.DE186",
      "display" : "Count of contacts or partners given for social network-based/partner services",
      "definition" : "The quantity of contacts or partners given by a client that accepts social network-based/partner services for follow-up"
    },
    {
      "code" : "HIV.B.DE187",
      "display" : "Offered social network-based/partner services",
      "definition" : "Whether the client was offered social network-based partner services"
    },
    {
      "code" : "HIV.B.DE188",
      "display" : "Accepted social network-based/partner services",
      "definition" : "Whether the client accepted social network-based partner services"
    },
    {
      "code" : "HIV.B.DE189",
      "display" : "Contact first name to offer social network-based/partner services",
      "definition" : "First name of each contact given by the client to offer social network-based/partner services"
    },
    {
      "code" : "HIV.B.DE190",
      "display" : "Contact last name to offer social network-based/partner services",
      "definition" : "Last or family name of each contact given by the client to offer social network-based/partner services"
    },
    {
      "code" : "HIV.B.DE191",
      "display" : "Type of follow-up appointment",
      "definition" : "Type of follow-up appointment for testing services"
    },
    {
      "code" : "HIV.B.DE192",
      "display" : "Retesting for HIV",
      "definition" : "Retesting follow-up appointment"
    },
    {
      "code" : "HIV.B.DE193",
      "display" : "Other",
      "definition" : "Other reason for the follow-up appointment"
    },
    {
      "code" : "HIV.B.DE194",
      "display" : "Other reason for the follow-up appointment (specify)",
      "definition" : "Other reason for the follow-up appointment (specify)"
    },
    {
      "code" : "HIV.B.DE195",
      "display" : "Date/time of follow-up appointment",
      "definition" : "Date the patient is to return for monitoring, re-supply or any other reason"
    },
    {
      "code" : "HIV.B.DE196",
      "display" : "Recommended follow-up date",
      "definition" : "Date when follow-up is recommended based on follow up requirements"
    },
    {
      "code" : "HIV.B.DE197",
      "display" : "VMMC procedure",
      "definition" : "Whether a voluntary medical male circumcision procedure was performed"
    },
    {
      "code" : "HIV.B.DE198",
      "display" : "VMMC procedure date",
      "definition" : "Date on which a voluntary medical male circumcision procedure was performed"
    },
    {
      "code" : "HIV.B.DE199",
      "display" : "Adverse event reported from a VMMC",
      "definition" : "Whether an adverse event was reported associated with a voluntary medical male circumcision (VMMC) procedure"
    },
    {
      "code" : "HIV.B.DE200",
      "display" : "Serious adverse event",
      "definition" : "Complications from voluntary medical male circumcision (VMMC) procedure resulted in death or hospitalization within 30 days of the procedure or permanent disability"
    },
    {
      "code" : "HIV.B.DE201",
      "display" : "Adverse event severity",
      "definition" : "Severity of the adverse event associated with voluntary medical male circumcision (VMMC) procedure"
    },
    {
      "code" : "HIV.B.DE202",
      "display" : "Moderate",
      "definition" : "Severity of the adverse event associated with VMMC procedure was moderate"
    },
    {
      "code" : "HIV.B.DE203",
      "display" : "Severe",
      "definition" : "Severity of the adverse event associated with VMMC procedure was severe"
    },
    {
      "code" : "HIV.B.DE204",
      "display" : "Timing of adverse event",
      "definition" : "When the adverse event associated with VMMC procedure occurred"
    },
    {
      "code" : "HIV.B.DE205",
      "display" : "Intraoperative",
      "definition" : "The adverse event associated with VMMC procedure occurred during the procedure"
    },
    {
      "code" : "HIV.B.DE206",
      "display" : "Postoperative",
      "definition" : "The adverse event associated with VMMC procedure occurred within the first 30 days after the procedure"
    },
    {
      "code" : "HIV.B.DE207",
      "display" : "Type of adverse VMMC event",
      "definition" : "Type of adverse event associated with voluntary medical male circumcision (VMMC) procedure"
    },
    {
      "code" : "HIV.B.DE208",
      "display" : "Abnormal pain",
      "definition" : "Client experienced abnormal pain"
    },
    {
      "code" : "HIV.B.DE209",
      "display" : "Anaesthesia-related effects",
      "definition" : "Client had anaesthesia-related effects"
    },
    {
      "code" : "HIV.B.DE210",
      "display" : "Bleeding",
      "definition" : "Client had bleeding"
    },
    {
      "code" : "HIV.B.DE211",
      "display" : "Damage to the penis",
      "definition" : "Client had damage to the penis"
    },
    {
      "code" : "HIV.B.DE212",
      "display" : "Difficulty urinating",
      "definition" : "Client had difficulty urinating"
    },
    {
      "code" : "HIV.B.DE213",
      "display" : "Excessive bleeding",
      "definition" : "Client experienced excessive bleeding"
    },
    {
      "code" : "HIV.B.DE214",
      "display" : "Excessive skin removal",
      "definition" : "Client experienced excessive skin removal"
    },
    {
      "code" : "HIV.B.DE215",
      "display" : "Excessive swelling",
      "definition" : "Client experienced excessive swelling"
    },
    {
      "code" : "HIV.B.DE216",
      "display" : "Haematoma",
      "definition" : "Client experienced haematoma"
    },
    {
      "code" : "HIV.B.DE217",
      "display" : "Infection",
      "definition" : "Client experienced infection"
    },
    {
      "code" : "HIV.B.DE218",
      "display" : "Injury to glans",
      "definition" : "Client experienced injury to glans"
    },
    {
      "code" : "HIV.B.DE219",
      "display" : "Scar or disfigurement",
      "definition" : "Client experienced scar or disfigurement"
    },
    {
      "code" : "HIV.B.DE220",
      "display" : "Sharps injury to personnel",
      "definition" : "During VMMC procedure there was sharps injury to personnel"
    },
    {
      "code" : "HIV.B.DE221",
      "display" : "Wound disruption",
      "definition" : "Client experienced wound disruption"
    },
    {
      "code" : "HIV.B.DE222",
      "display" : "Other",
      "definition" : "Client experienced other adverse VMMC event"
    },
    {
      "code" : "HIV.B.DE223",
      "display" : "Other (specify)",
      "definition" : "Client experienced other adverse VMMC event (specify)"
    },
    {
      "code" : "HIV.B.DE224",
      "display" : "HIV retest prior to starting ART conducted",
      "definition" : "HIV retest prior to starting ART conducted"
    },
    {
      "code" : "HIV.B.DE225",
      "display" : "At elevated risk for HIV acquisition",
      "definition" : "Client is at elevated risk for HIV acquisition"
    },
    {
      "code" : "HIV.B.DE226",
      "display" : "Syndrome/STI diagnosed",
      "definition" : "Syndrome or STI for which client is diagnosed"
    },
    {
      "code" : "HIV.B.DE227",
      "display" : "Urethral discharge syndrome",
      "definition" : "Client diagnosed with urethral discharge syndrome"
    },
    {
      "code" : "HIV.B.DE228",
      "display" : "Vaginal discharge syndrome",
      "definition" : "Client diagnosed with vaginal discharge syndrome"
    },
    {
      "code" : "HIV.B.DE229",
      "display" : "Lower Abdominal pain",
      "definition" : "Client diagnosed with lower abdominal pain"
    },
    {
      "code" : "HIV.B.DE230",
      "display" : "Genital ulcer disease syndrome",
      "definition" : "Client diagnosed with genital ulcer disease syndrome"
    },
    {
      "code" : "HIV.B.DE231",
      "display" : "Anorectal discharge",
      "definition" : "Client diagnosed with anorectal discharge"
    },
    {
      "code" : "HIV.B.DE232",
      "display" : "Sent for testing",
      "definition" : "Specimen sent for testing"
    },
    {
      "code" : "HIV.B.DE233",
      "display" : "Other",
      "definition" : "Other syndrome/STI diagnosed"
    },
    {
      "code" : "HIV.B.DE234",
      "display" : "Other (specify)",
      "definition" : "Other syndrome/STI diagnosed (specify)"
    },
    {
      "code" : "HIV.B.DE235",
      "display" : "Any STI syndrome diagnosed",
      "definition" : "Was the client diagnosed with any of the five STI syndromes during this visit?"
    },
    {
      "code" : "HIV.B.DE236",
      "display" : "Date of STI test",
      "definition" : "Date on which the STI test was conducted"
    },
    {
      "code" : "HIV.B.DE237",
      "display" : "STI tested for",
      "definition" : "STI for which the client was tested"
    },
    {
      "code" : "HIV.B.DE238",
      "display" : "Neisseria gonorrhoeae",
      "definition" : "Client tested for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.B.DE239",
      "display" : "Chlamydia trachomatis",
      "definition" : "Client tested for Chlamydia trachomatis"
    },
    {
      "code" : "HIV.B.DE240",
      "display" : "Trichomonas vaginalis",
      "definition" : "Client tested for Trichomonas vaginalis"
    },
    {
      "code" : "HIV.B.DE241",
      "display" : "Syphilis (Treponema pallidum)",
      "definition" : "Client tested for Syphilis (treponema pallidum)"
    },
    {
      "code" : "HIV.B.DE242",
      "display" : "Herpes simplex virus (HSV1, HSV2)",
      "definition" : "Client tested for herpes simplex virus (HSV1, HSV2)"
    },
    {
      "code" : "HIV.B.DE243",
      "display" : "Mycoplasma genitalium",
      "definition" : "Client tested for Mycoplasma genitalium"
    },
    {
      "code" : "HIV.B.DE244",
      "display" : "Mpox",
      "definition" : "Client tested for Mpox"
    },
    {
      "code" : "HIV.B.DE245",
      "display" : "Hepatitis B",
      "definition" : "Client tested for Hepatitis B"
    },
    {
      "code" : "HIV.B.DE246",
      "display" : "Hepatitis C",
      "definition" : "Client tested for Hepatitis C"
    },
    {
      "code" : "HIV.B.DE247",
      "display" : "Other",
      "definition" : "Client tested for other STI"
    },
    {
      "code" : "HIV.B.DE248",
      "display" : "Other (specify)",
      "definition" : "Client tested for other STI (specify)"
    },
    {
      "code" : "HIV.B.DE249",
      "display" : "Syphilis test date",
      "definition" : "Date of syphilis test"
    },
    {
      "code" : "HIV.B.DE250",
      "display" : "Syphilis test result",
      "definition" : "Result from syphilis test"
    },
    {
      "code" : "HIV.B.DE251",
      "display" : "Positive",
      "definition" : "Test result is positive for syphilis"
    },
    {
      "code" : "HIV.B.DE252",
      "display" : "Negative",
      "definition" : "Test result is negative for syphilis"
    },
    {
      "code" : "HIV.B.DE253",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.B.DE254",
      "display" : "Syphilis treatment start date",
      "definition" : "Date of initiation of syphilis treatment"
    },
    {
      "code" : "HIV.B.DE255",
      "display" : "Gonorrhoea test date",
      "definition" : "Date of Gonorrhoea test"
    },
    {
      "code" : "HIV.B.DE256",
      "display" : "Gonorrhoea test result",
      "definition" : "Result from Gonorrhoea test"
    },
    {
      "code" : "HIV.B.DE257",
      "display" : "Positive",
      "definition" : "Test result is positive for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.B.DE258",
      "display" : "Negative",
      "definition" : "Test result is negative for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.B.DE259",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.B.DE260",
      "display" : "Gonorrhoea treatment start date",
      "definition" : "Date of initiation of Gonorrhoea treatment"
    },
    {
      "code" : "HIV.B.DE261",
      "display" : "Type of specimen",
      "definition" : "Type of specimen to be collected"
    },
    {
      "code" : "HIV.B.DE262",
      "display" : "Blood",
      "definition" : "Blood specimen to be collected"
    },
    {
      "code" : "HIV.B.DE263",
      "display" : "Urine",
      "definition" : "Urine specimen to be collected"
    },
    {
      "code" : "HIV.B.DE264",
      "display" : "Cervical or vaginal swab",
      "definition" : "Cervical or vaginal swab to be collected"
    },
    {
      "code" : "HIV.B.DE265",
      "display" : "Urethral or penile swab",
      "definition" : "Urethral or penile swab to be collected"
    },
    {
      "code" : "HIV.B.DE266",
      "display" : "Rectal swab",
      "definition" : "Rectal swab to be collected"
    },
    {
      "code" : "HIV.B.DE267",
      "display" : "Other",
      "definition" : "Other specimen type to be collected"
    },
    {
      "code" : "HIV.B.DE268",
      "display" : "Other type of specimen (specify)",
      "definition" : "Other specimen type to be collected (specify)"
    },
    {
      "code" : "HIV.B.DE269",
      "display" : "Syphilis test type",
      "definition" : "Type of diagnostic test used for syphilis (treponema pallidum)"
    },
    {
      "code" : "HIV.B.DE270",
      "display" : "Treponemal",
      "definition" : "Treponemal test used"
    },
    {
      "code" : "HIV.B.DE271",
      "display" : "Non-treponemal",
      "definition" : "Non-treponemal test used"
    },
    {
      "code" : "HIV.B.DE272",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.B.DE273",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.B.DE274",
      "display" : "Other",
      "definition" : "Other test used"
    },
    {
      "code" : "HIV.B.DE275",
      "display" : "Other syphilis test type (specify)",
      "definition" : "Other test used (specify)"
    },
    {
      "code" : "HIV.B.DE276",
      "display" : "Neisseria gonorrhoeae test type",
      "definition" : "Type of diagnostic test used for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.B.DE277",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.B.DE278",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.B.DE279",
      "display" : "Culture",
      "definition" : "Culture test used"
    },
    {
      "code" : "HIV.B.DE280",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.B.DE281",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.B.DE282",
      "display" : "Other (specify)",
      "definition" : "Other type of test used (specify)"
    },
    {
      "code" : "HIV.B.DE283",
      "display" : "POC Test for Neisseria gonorrhoeae (specify)",
      "definition" : "Point-of-care (POC) test used for Neisseria gonorrhoeae (specify)"
    },
    {
      "code" : "HIV.B.DE284",
      "display" : "Chlamydia trachomatis test type",
      "definition" : "Type of diagnostic test used for Chlamydia trachomatis"
    },
    {
      "code" : "HIV.B.DE285",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.B.DE286",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.B.DE287",
      "display" : "Culture",
      "definition" : "Culture test used"
    },
    {
      "code" : "HIV.B.DE288",
      "display" : "ELISA",
      "definition" : "ELISA test used"
    },
    {
      "code" : "HIV.B.DE289",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.B.DE290",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.B.DE291",
      "display" : "Other test for Chlamydia (specify)",
      "definition" : "Other type of test used for Chlaymdia (specify)"
    },
    {
      "code" : "HIV.B.DE292",
      "display" : "POC Test type for Chlamydia test (specify)",
      "definition" : "Point-of-care (POC) test used for Chlamydia (specify)"
    },
    {
      "code" : "HIV.B.DE293",
      "display" : "Trichomonas vaginalis test type",
      "definition" : "Type of diagnostic test used for Trichomonas vaginalis"
    },
    {
      "code" : "HIV.B.DE294",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.B.DE295",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.B.DE296",
      "display" : "Culture",
      "definition" : "Culture test used"
    },
    {
      "code" : "HIV.B.DE297",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.B.DE298",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.B.DE299",
      "display" : "Other (specify)",
      "definition" : "Other type of test used (specify)"
    },
    {
      "code" : "HIV.B.DE300",
      "display" : "POC Test type for Trichomonas vaginalis test (specify)",
      "definition" : "Point-of-care (POC) test used (specify)"
    },
    {
      "code" : "HIV.B.DE301",
      "display" : "Herpes simplex virus (HSV) test type",
      "definition" : "Type of diagnostic test used for herpes simplex virus (HSV)"
    },
    {
      "code" : "HIV.B.DE302",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.B.DE303",
      "display" : "Antibody test",
      "definition" : "Antibody test used"
    },
    {
      "code" : "HIV.B.DE304",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.B.DE305",
      "display" : "Other (specify)",
      "definition" : "Other type of test used for Herpes simplex virus (HSV) test (specify)"
    },
    {
      "code" : "HIV.B.DE306",
      "display" : "Mycoplasma genitalium test type",
      "definition" : "Type of diagnostic test used for Mycoplasma genitalium"
    },
    {
      "code" : "HIV.B.DE307",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.B.DE308",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.B.DE309",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.B.DE310",
      "display" : "Other (specify)",
      "definition" : "Other type of test used for Mycoplasma genitalium test (specify)"
    },
    {
      "code" : "HIV.B.DE311",
      "display" : "Test type for other STI tested for (specify)",
      "definition" : "Test type used for the other specified STI"
    },
    {
      "code" : "HIV.B.DE312",
      "display" : "STI test result",
      "definition" : "Result from STI test"
    },
    {
      "code" : "HIV.B.DE313",
      "display" : "Positive",
      "definition" : "Test result is positive"
    },
    {
      "code" : "HIV.B.DE314",
      "display" : "Negative",
      "definition" : "Test result is negative"
    },
    {
      "code" : "HIV.B.DE315",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.B.DE316",
      "display" : "Date of STI confirmatory test",
      "definition" : "Date of STI confirmatory test"
    },
    {
      "code" : "HIV.B.DE317",
      "display" : "Confirmatory syphilis test type",
      "definition" : "Type of test ued for confirmatory syphilis test"
    },
    {
      "code" : "HIV.B.DE318",
      "display" : "Treponemal",
      "definition" : "Treponemal test used"
    },
    {
      "code" : "HIV.B.DE319",
      "display" : "Non-treponemal",
      "definition" : "Non-treponemal test used"
    },
    {
      "code" : "HIV.B.DE320",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.B.DE321",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.B.DE322",
      "display" : "Other",
      "definition" : "Other test used"
    },
    {
      "code" : "HIV.B.DE323",
      "display" : "Other (specify)",
      "definition" : "Other test used for confirmatory syphilis test (specify)"
    },
    {
      "code" : "HIV.B.DE324",
      "display" : "Confirmatory test type for other STI (specify)",
      "definition" : "Confirmatory test type for other STI"
    },
    {
      "code" : "HIV.B.DE325",
      "display" : "Confirmatory STI test result",
      "definition" : "Result from confirmatory STI test"
    },
    {
      "code" : "HIV.B.DE326",
      "display" : "Positive",
      "definition" : "Test result is positive"
    },
    {
      "code" : "HIV.B.DE327",
      "display" : "Negative",
      "definition" : "Test result is negative"
    },
    {
      "code" : "HIV.B.DE328",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.B.DE329",
      "display" : "Date STI treatment prescribed",
      "definition" : "Date STI treatment was prescribed to the client"
    },
    {
      "code" : "HIV.B.DE330",
      "display" : "Date STI treatment dispensed",
      "definition" : "Date STI treatment dispensed to the client"
    },
    {
      "code" : "HIV.B.DE331",
      "display" : "STI treatment dispensed (specify)",
      "definition" : "STI treatment dispensed to the client"
    },
    {
      "code" : "HIV.C.DE1",
      "display" : "Reason for PrEP visit",
      "definition" : "Client's reason for the prevention visit"
    },
    {
      "code" : "HIV.C.DE2",
      "display" : "First time counselling on PrEP",
      "definition" : "The client is interested in discussing pre-exposure prophylaxis (PrEP) for the first time"
    },
    {
      "code" : "HIV.C.DE3",
      "display" : "Follow-up appointment for PrEP or PEP",
      "definition" : "Client is at a follow-up or refill pre-exposure prophylaxis (PrEP) appointment"
    },
    {
      "code" : "HIV.C.DE4",
      "display" : "Restarting PrEP",
      "definition" : "Client has previously taken pre-exposure prophylaxis (PrEP) and may like to restart taking it"
    },
    {
      "code" : "HIV.C.DE5",
      "display" : "Counselling on PEP",
      "definition" : "Counselling on post-exposure prophylaxis (PEP)"
    },
    {
      "code" : "HIV.C.DE6",
      "display" : "Unscheduled visit for side effects",
      "definition" : "Patient visit for management of side effects related to PrEP"
    },
    {
      "code" : "HIV.C.DE7",
      "display" : "3-month PrEP visit",
      "definition" : "Client is visiting for the recommended 3-month pre-exposure prophylaxis (PrEP) visit"
    },
    {
      "code" : "HIV.C.DE8",
      "display" : "Contact with and (suspected) exposure to HIV",
      "definition" : "The client had suspected or known exposure to HIV"
    },
    {
      "code" : "HIV.C.DE9",
      "display" : "Date/time of suspected exposure to HIV",
      "definition" : "When the suspect exposure to HIV took place"
    },
    {
      "code" : "HIV.C.DE10",
      "display" : "Currently on PrEP",
      "definition" : "The client is currently taking PrEP. Oral pre-exposure prophylaxis (PrEP) of HIV is the use of ARV drugs by people who are not infected with HIV to block the acquisition of HIV."
    },
    {
      "code" : "HIV.C.DE11",
      "display" : "PrEP dosing type",
      "definition" : "Way in which pre-exposure prophylaxis (PrEP) is taken (daily or event-driven)"
    },
    {
      "code" : "HIV.C.DE12",
      "display" : "Daily oral PrEP",
      "definition" : "Pre-exposure prophylaxis (PrEP) is taken every day"
    },
    {
      "code" : "HIV.C.DE13",
      "display" : "Event-driven PrEP (2+1+1)",
      "definition" : "Event-driven pre-exposure prophylaxis (PrEP) is taken on an even-driven basis (2+1+1)"
    },
    {
      "code" : "HIV.C.DE14",
      "display" : "Other PrEP dosing type",
      "definition" : "Other PrEP dosing type"
    },
    {
      "code" : "HIV.C.DE15",
      "display" : "Other PrEP dosing type (specify)",
      "definition" : "Other PrEP dosing type (specify)"
    },
    {
      "code" : "HIV.C.DE16",
      "display" : "Used event-driven PrEP for at risk exposures over the past 3 months",
      "definition" : "Client reports taking ED-PrEP for at risk exposures over a 3-month period"
    },
    {
      "code" : "HIV.C.DE17",
      "display" : "Current PrEP regimen",
      "definition" : "HIV pre-exposure prophylaxis (PrEP) regimen"
    },
    {
      "code" : "HIV.C.DE18",
      "display" : "TDF + FTC",
      "definition" : "Treated with tenofovir disoproxil fumarate (TDF) and emtricitabine (FTC) pre-exposure prophylaxis (PrEP) regimen (oral PrEP)"
    },
    {
      "code" : "HIV.C.DE19",
      "display" : "TDF",
      "definition" : "Treated with single-agent tenofovir disoproxil fumarate (TDF) pre-exposure prophylaxis (PrEP) regimen (oral PrEP)"
    },
    {
      "code" : "HIV.C.DE20",
      "display" : "TDF + 3TC",
      "definition" : "Treated with tenofovir disoproxil fumarate (TDF) and lamivudine (3TC) pre-exposure prophylaxis (PrEP) regimen (oral PrEP)"
    },
    {
      "code" : "HIV.C.DE21",
      "display" : "Other TDF-based regimen",
      "definition" : "Treated with other tenofovir disoproxil fumarate (TDF)-based regimen (oral PrEP)"
    },
    {
      "code" : "HIV.C.DE22",
      "display" : "Dapivirine vaginal ring (DVR)",
      "definition" : "Dapivirine vaginal ring (DVR) for HIV prevention"
    },
    {
      "code" : "HIV.C.DE23",
      "display" : "CAB-LA",
      "definition" : "Long-acting injectable cabotegravir"
    },
    {
      "code" : "HIV.C.DE24",
      "display" : "Experience with PrEP",
      "definition" : "The client's experience in taking PrEP"
    },
    {
      "code" : "HIV.C.DE25",
      "display" : "First-time user",
      "definition" : "The client has never used pre-exposure prophylaxis (PrEP) before (naive)"
    },
    {
      "code" : "HIV.C.DE26",
      "display" : "Continuing user",
      "definition" : "The client has used PrEP before and is continuing to use PrEP"
    },
    {
      "code" : "HIV.C.DE27",
      "display" : "Restarting following a period of not taking PrEP",
      "definition" : "The client is restarting PrEP following a period of not taking PrEP"
    },
    {
      "code" : "HIV.C.DE28",
      "display" : "PrEP start date",
      "definition" : "The date on which the client started or restarted pre-exposure prophylaxis (PrEP)"
    },
    {
      "code" : "HIV.C.DE29",
      "display" : "Stopped PrEP",
      "definition" : "Client stopped taking pre-exposure prophylaxis (PrEP)"
    },
    {
      "code" : "HIV.C.DE30",
      "display" : "Date PrEP stopped",
      "definition" : "Date client stopped taking pre-exposure prophylaxis (PrEP)"
    },
    {
      "code" : "HIV.C.DE31",
      "display" : "PEP history",
      "definition" : "The client's history in taking post-exposure prophylaxis (PEP) for HIV prevention"
    },
    {
      "code" : "HIV.C.DE32",
      "display" : "First-time user",
      "definition" : "The client has never used post-exposure prophylaxis (PEP) before"
    },
    {
      "code" : "HIV.C.DE33",
      "display" : "Repeat user",
      "definition" : "The client has used post-exposure prophylaxis (PEP) before"
    },
    {
      "code" : "HIV.C.DE34",
      "display" : "Date(s) of past PEP use",
      "definition" : "Dates when the client previously used post-exposure prophylaxis (PEP)"
    },
    {
      "code" : "HIV.C.DE35",
      "display" : "Date client completes PEP course",
      "definition" : "Date client completes PEP course"
    },
    {
      "code" : "HIV.C.DE36",
      "display" : "Signs of substantial risk of HIV infection",
      "definition" : "Signs the client is at a substantial risk of HIV infection"
    },
    {
      "code" : "HIV.C.DE37",
      "display" : "No condom use during sex with more than one partner in the past 6 months",
      "definition" : "Recent vaginal or anal sexual intercourse without a condom with more than one partner"
    },
    {
      "code" : "HIV.C.DE38",
      "display" : "STI in the past 6 months",
      "definition" : "A recent history (in the last 6 months) of a sexually transmitted infection (STI ) by laboratory testing, self-report or syndromic STI treatment"
    },
    {
      "code" : "HIV.C.DE39",
      "display" : "A sexual partner in the past 6 months had one or more HIV risk factors",
      "definition" : "A recent sex partner of the client had HIV risk factors"
    },
    {
      "code" : "HIV.C.DE40",
      "display" : "PrEP requested by client",
      "definition" : "Client is requesting PrEP, reflecting a decision-making process has already taken place and suggesting of substantial risk of HIV"
    },
    {
      "code" : "HIV.C.DE41",
      "display" : "Pregnancy intention in serodiscordant partnerships",
      "definition" : "Client's intention or desire in the next year to either become pregnant or prevent a future pregnancy (in serodiscordant partnerships)"
    },
    {
      "code" : "HIV.C.DE42",
      "display" : "Yes, I want to become pregnant",
      "definition" : "Client intends to become pregnant"
    },
    {
      "code" : "HIV.C.DE43",
      "display" : "I'm OK either way",
      "definition" : "Client is not intending to become pregnant, but would not be adverse to becoming pregnant"
    },
    {
      "code" : "HIV.C.DE44",
      "display" : "No, I don't want to become pregnant",
      "definition" : "Client does not intend to become pregnant"
    },
    {
      "code" : "HIV.C.DE45",
      "display" : "Unsure",
      "definition" : "Client is unsure or undecided about her pregnancy intentions"
    },
    {
      "code" : "HIV.C.DE46",
      "display" : "Acute HIV infection symptoms",
      "definition" : "Symptoms that could suggest an acute HIV infection"
    },
    {
      "code" : "HIV.C.DE47",
      "display" : "Fever",
      "definition" : "Client's symptoms include a fever"
    },
    {
      "code" : "HIV.C.DE48",
      "display" : "Sore throat",
      "definition" : "Client's symptoms include a sore throat"
    },
    {
      "code" : "HIV.C.DE49",
      "display" : "Aches",
      "definition" : "Client's symptoms include aches"
    },
    {
      "code" : "HIV.C.DE50",
      "display" : "Pains",
      "definition" : "Client's symptoms include pains"
    },
    {
      "code" : "HIV.C.DE51",
      "display" : "Swollen glands",
      "definition" : "Client's symptoms include swollen glands"
    },
    {
      "code" : "HIV.C.DE52",
      "display" : "Mouth sores",
      "definition" : "Client's symptoms include a mouth sores"
    },
    {
      "code" : "HIV.C.DE53",
      "display" : "Headaches",
      "definition" : "Client's symptoms include a headaches"
    },
    {
      "code" : "HIV.C.DE54",
      "display" : "Rash",
      "definition" : "Client's symptoms include a rash"
    },
    {
      "code" : "HIV.C.DE55",
      "display" : "Sex partner's HIV treatment status",
      "definition" : "Treatment adherence of client's sex partner for partners that are HIV-positive"
    },
    {
      "code" : "HIV.C.DE56",
      "display" : "Not on ART",
      "definition" : "Sex partner is HIV-positive and not on ART"
    },
    {
      "code" : "HIV.C.DE57",
      "display" : "On ART less than 6 months",
      "definition" : "Sex partner is HIV-positive and is on ART less than 6 months. ART may take up to 6 months to suppress viral load. In studies of serodiscordant couples, pre-exposure prophylaxis (PrEP) has provided a useful bridge to full viral suppression by the partner during that time."
    },
    {
      "code" : "HIV.C.DE58",
      "display" : "Partner has suspected low adherence to ART",
      "definition" : "Sex partner is HIV-positive and is suspected to have low adherence to ART. There have been gaps in the partner's treatment adherence or the couple is not communicating openly about treatment adherence and viral load test results."
    },
    {
      "code" : "HIV.C.DE59",
      "display" : "Partner is not virally suppressed",
      "definition" : "Sex partner is HIV-positive and not virally suppressed"
    },
    {
      "code" : "HIV.C.DE60",
      "display" : "Partner is virally suppressed and has been on ART for 6 months or more",
      "definition" : "Sex partner is HIV-positive and virally suppressed with 6 months or more on ART"
    },
    {
      "code" : "HIV.C.DE61",
      "display" : "Suitable for PrEP",
      "definition" : "The client is suitable for PrEP"
    },
    {
      "code" : "HIV.C.DE62",
      "display" : "Offered PrEP",
      "definition" : "After being evaluated as suitable for PrEP, the client was offered PrEP"
    },
    {
      "code" : "HIV.C.DE63",
      "display" : "Screenings and diagnostics for PrEP users",
      "definition" : "Listing of tests for clients on or starting pre-exposure prophylaxis (PrEP) that may be recommended or should be considered"
    },
    {
      "code" : "HIV.C.DE64",
      "display" : "Serum creatinine test",
      "definition" : "Test serum creatinine to identify pre-existing renal disease (estimated creatinine clearance less than 60 ml/min)"
    },
    {
      "code" : "HIV.C.DE65",
      "display" : "Hepatitis B test",
      "definition" : "Hepatitis B test recommended for client"
    },
    {
      "code" : "HIV.C.DE66",
      "display" : "Hepatitis C test",
      "definition" : "Hepatitis C test recommended for client"
    },
    {
      "code" : "HIV.C.DE67",
      "display" : "Syphilis test",
      "definition" : "Syphilis test recommended for client"
    },
    {
      "code" : "HIV.C.DE68",
      "display" : "Other screening for STIs",
      "definition" : "Other STI screening recommended for client"
    },
    {
      "code" : "HIV.C.DE69",
      "display" : "Pregnancy testing",
      "definition" : "Pregnancy testing for client"
    },
    {
      "code" : "HIV.C.DE70",
      "display" : "Review vaccination history",
      "definition" : "Review vaccination history recommended for client"
    },
    {
      "code" : "HIV.C.DE71",
      "display" : "Serum creatinine test date",
      "definition" : "Test serum creatinine to identify pre-existing renal disease (estimated creatinine clearance less than 60 ml/min)"
    },
    {
      "code" : "HIV.C.DE72",
      "display" : "Serum creatinine test result",
      "definition" : "Test serum creatinine to identify pre-existing renal disease (estimated creatinine clearance less than 60 ml/min)."
    },
    {
      "code" : "HIV.C.DE73",
      "display" : "Date medications dispensed",
      "definition" : "Date the client was dispensed medications"
    },
    {
      "code" : "HIV.C.DE74",
      "display" : "Date medications prescribed",
      "definition" : "Date the client was prescribed medications"
    },
    {
      "code" : "HIV.C.DE75",
      "display" : "Medications prescribed",
      "definition" : "Medications the client was prescribed"
    },
    {
      "code" : "HIV.C.DE76",
      "display" : "PrEP for HIV prevention",
      "definition" : "Client was prescribed pre-exposure prophylaxis (PrEP) for HIV prevention"
    },
    {
      "code" : "HIV.C.DE77",
      "display" : "PEP for HIV prevention",
      "definition" : "Client was prescribed post-exposure prophylaxis (PEP) for HIV prevention"
    },
    {
      "code" : "HIV.C.DE78",
      "display" : "Other",
      "definition" : "Client was prescribed other medications"
    },
    {
      "code" : "HIV.C.DE79",
      "display" : "Other (specify)",
      "definition" : "Client was prescribed other medications (specify)"
    },
    {
      "code" : "HIV.C.DE80",
      "display" : "PrEP product prescribed",
      "definition" : "PrEP product that the client was prescribed"
    },
    {
      "code" : "HIV.C.DE81",
      "display" : "Oral PrEP",
      "definition" : "Client was prescribed oral PrEP"
    },
    {
      "code" : "HIV.C.DE82",
      "display" : "Dapivirine vaginal ring (DVR)",
      "definition" : "Client was prescribed dapivirine vaginal ring (DVR)"
    },
    {
      "code" : "HIV.C.DE83",
      "display" : "CAB-LA",
      "definition" : "Client was prescribed long-acting cabotegravir (CAB-LA)"
    },
    {
      "code" : "HIV.C.DE84",
      "display" : "Other",
      "definition" : "Client was prescribed other PrEP product"
    },
    {
      "code" : "HIV.C.DE85",
      "display" : "Other (specify)",
      "definition" : "Client was prescribed other PrEP product (specify)"
    },
    {
      "code" : "HIV.C.DE86",
      "display" : "Date PrEP prescribed",
      "definition" : "Date client was prescribed PrEP, including initial prescription and repeats"
    },
    {
      "code" : "HIV.C.DE87",
      "display" : "Date PrEP dispensed",
      "definition" : "Date client was dispensed PrEP"
    },
    {
      "code" : "HIV.C.DE88",
      "display" : "Volume of PrEP product prescribed/dispensed",
      "definition" : "Volume of PrEP product the client was prescribed or dispensed (for example, number of pills, number of devices)"
    },
    {
      "code" : "HIV.C.DE89",
      "display" : "Date PEP prescribed",
      "definition" : "Date the client was prescribed PEP"
    },
    {
      "code" : "HIV.C.DE90",
      "display" : "Date PEP course completion",
      "definition" : "Date client completes PEP course"
    },
    {
      "code" : "HIV.C.DE91",
      "display" : "Preferred PEP backbone regimen",
      "definition" : "Preferred backbone regimen for PEP"
    },
    {
      "code" : "HIV.C.DE92",
      "display" : "TDF + 3TC",
      "definition" : "Preferred backbone containing tenofovir disoproxil fumarate and lamivudine"
    },
    {
      "code" : "HIV.C.DE93",
      "display" : "TDF + FTC",
      "definition" : "Preferred backbone containing tenofovir disoproxil fumarate and emtricitabine"
    },
    {
      "code" : "HIV.C.DE94",
      "display" : "AZT + 3TC",
      "definition" : "Preferred backbone containing zidovudine and lamivudine"
    },
    {
      "code" : "HIV.C.DE95",
      "display" : "Alternative PEP backbone regimen",
      "definition" : "Alternative backbone regimen for PEP"
    },
    {
      "code" : "HIV.C.DE96",
      "display" : "ABC + 3TC",
      "definition" : "Alternative backbone containing abacavir and lamivudine"
    },
    {
      "code" : "HIV.C.DE97",
      "display" : "TDF + 3TC",
      "definition" : "Alternative backbone containing tenofovir disoproxil fumarate and lamivudine"
    },
    {
      "code" : "HIV.C.DE98",
      "display" : "TDF + FTC",
      "definition" : "Alternative backbone containing tenofovir disoproxil fumarate and emtricitabine"
    },
    {
      "code" : "HIV.C.DE99",
      "display" : "Preferred third PEP drug",
      "definition" : "Preferred third drug for PEP"
    },
    {
      "code" : "HIV.C.DE100",
      "display" : "DTG",
      "definition" : "Preferred third drug of dolutegravir"
    },
    {
      "code" : "HIV.C.DE101",
      "display" : "Alternative third PEP drug",
      "definition" : "Alternative third drug for PEP"
    },
    {
      "code" : "HIV.C.DE102",
      "display" : "ATV/r",
      "definition" : "Alternative third drug of atazanavir/ritonavir (ATV/r)"
    },
    {
      "code" : "HIV.C.DE103",
      "display" : "DRV/r",
      "definition" : "Alternative third drug of darunavir/ritonavir (DRV/r)"
    },
    {
      "code" : "HIV.C.DE104",
      "display" : "LPV/r",
      "definition" : "Alternative third drug of lopinavir/ritonavir (LPV/r)"
    },
    {
      "code" : "HIV.C.DE105",
      "display" : "RAL",
      "definition" : "Alternative third drug of raltegravir (RAL)"
    },
    {
      "code" : "HIV.C.DE106",
      "display" : "Estimated creatinine clearance",
      "definition" : "Estimated creatinine clearance of the client returned from lab in mL/min"
    },
    {
      "code" : "HIV.C.DE107",
      "display" : "Sex factor for estimating creatinine clearance",
      "definition" : "Value used for gender for calculating creatinine clearance if required. For transgender populations, the sex at birth is used in the Cockcroft-Gault equation if the person is not using hormone therapy; among transgender populations using hormone therapy for more than three months, the current gender can be used."
    },
    {
      "code" : "HIV.C.DE108",
      "display" : "Male",
      "definition" : "Male client"
    },
    {
      "code" : "HIV.C.DE109",
      "display" : "Female",
      "definition" : "Female client"
    },
    {
      "code" : "HIV.C.DE110",
      "display" : "Estimated creatinine clearance (Cockcroft–Gault equation)",
      "definition" : "If the laboratory does not have the capacity to estimate creatinine clearance, the provider can use the Cockcroft–Gault equation to calculate estimated creatinine clearance based on measured serum creatinine, the client’s sex at birth, age and estimated lean body weight."
    },
    {
      "code" : "HIV.C.DE111",
      "display" : "Date of sample collection",
      "definition" : "Date when the specimen was collected"
    },
    {
      "code" : "HIV.C.DE112",
      "display" : "Contraindications to PrEP usage",
      "definition" : "Listing of contraindications to pre-exposure prophylaxis (PrEP)"
    },
    {
      "code" : "HIV.C.DE113",
      "display" : "Tenofovir disoproxil fumarate (TDF) allergy or contraindication",
      "definition" : "Allergy to pre-exposure prophylaxis (PrEP) tenofovir disoproxil fumarate (TDF)"
    },
    {
      "code" : "HIV.C.DE114",
      "display" : "HIV-positive",
      "definition" : "Client is HIV-positive"
    },
    {
      "code" : "HIV.C.DE115",
      "display" : "Low estimated creatinine clearance",
      "definition" : "Estimated creatinine clearance of less than 60 ml/min (if known)"
    },
    {
      "code" : "HIV.C.DE116",
      "display" : "Acute HIV infection symptoms",
      "definition" : "Symptoms that could suggest an acute HIV infection"
    },
    {
      "code" : "HIV.C.DE117",
      "display" : "Probable recent exposure to HIV",
      "definition" : "When the client is reported to have had probable recent exposure to HIV"
    },
    {
      "code" : "HIV.C.DE118",
      "display" : "Other allergy or contraindication to a medicine in the PrEP regimen",
      "definition" : "Client has another allergy or contraindication to a medicine in the pre-exposure prophylaxis (PrEP) regimen"
    },
    {
      "code" : "HIV.C.DE119",
      "display" : "Other allergy or contraindication to a medicine in the PrEP regimen (specify)",
      "definition" : "Client has another allergy or contraindication to a medicine in the pre-exposure prophylaxis (PrEP) regimen (specify)"
    },
    {
      "code" : "HIV.C.DE120",
      "display" : "Prescribed PrEP at initial visit",
      "definition" : "Client was prescribed pre-exposure prophylaxis (PrEP) on a first visit"
    },
    {
      "code" : "HIV.C.DE121",
      "display" : "Number of days prescribed",
      "definition" : "Days of medication client has been prescribed"
    },
    {
      "code" : "HIV.C.DE122",
      "display" : "PrEP regimen prescribed",
      "definition" : "HIV pre-exposure prophylaxis (PrEP) regimen prescribed"
    },
    {
      "code" : "HIV.C.DE123",
      "display" : "Adherence counselling provided",
      "definition" : "Whether adherence counselling was provided"
    },
    {
      "code" : "HIV.C.DE124",
      "display" : "Date/time of follow-up appointment",
      "definition" : "Date the client is to return for monitoring, re-supply, or any other reason"
    },
    {
      "code" : "HIV.C.DE125",
      "display" : "Type of follow-up appointment",
      "definition" : "Type of follow-up appointment for testing services"
    },
    {
      "code" : "HIV.C.DE126",
      "display" : "Retesting for HIV",
      "definition" : "Retesting follow-up appointment"
    },
    {
      "code" : "HIV.C.DE127",
      "display" : "Follow-up appointment for PrEP",
      "definition" : "Retesting follow-up appointment"
    },
    {
      "code" : "HIV.C.DE128",
      "display" : "Other",
      "definition" : "Other reason for the follow-up appointment"
    },
    {
      "code" : "HIV.C.DE129",
      "display" : "Other (specify)",
      "definition" : "Other reason for the follow-up appointment (specify)"
    },
    {
      "code" : "HIV.C.DE130",
      "display" : "Linked to enrolment in care and ART initiation",
      "definition" : "Linkage made from HIV testing to enrolment in care following an HIV diagnosis"
    },
    {
      "code" : "HIV.C.DE131",
      "display" : "Prevention services offered and referrals",
      "definition" : "Offer or refer to prevention services"
    },
    {
      "code" : "HIV.C.DE132",
      "display" : "Male and female condoms and condom-compatible lubricants offered",
      "definition" : "Offer male and female condoms and condom-compatible lubricants"
    },
    {
      "code" : "HIV.C.DE133",
      "display" : "Voluntary medical male circumcision (VMMC) referral",
      "definition" : "Offer referral for VMMC services"
    },
    {
      "code" : "HIV.C.DE134",
      "display" : "Harm reduction for people who inject drugs",
      "definition" : "Offer or refer to harm reduction for people who inject drugs (needle and syringe programmes, opioid substitution therapy, other drug-dependence treatment and opioid overdose prevention and management) services"
    },
    {
      "code" : "HIV.C.DE135",
      "display" : "Behavioural interventions to support risk reduction",
      "definition" : "Offer or refer to services for behavioural interventions to support risk reduction, particularly for people with HIV and members of key populations"
    },
    {
      "code" : "HIV.C.DE136",
      "display" : "Date provided condoms",
      "definition" : "Date client was provided with condoms"
    },
    {
      "code" : "HIV.C.DE137",
      "display" : "Condoms distributed",
      "definition" : "Number of condoms given to the client, if any were distributed"
    },
    {
      "code" : "HIV.C.DE138",
      "display" : "Condom type",
      "definition" : "Type of condom provided to client"
    },
    {
      "code" : "HIV.C.DE139",
      "display" : "Male condom",
      "definition" : "Male condoms were provided to the client"
    },
    {
      "code" : "HIV.C.DE140",
      "display" : "Female condom",
      "definition" : "Female condoms were provided to the client"
    },
    {
      "code" : "HIV.C.DE141",
      "display" : "HIV self-test kits accepted",
      "definition" : "Whether any HIV self-test kits were given to the client"
    },
    {
      "code" : "HIV.C.DE142",
      "display" : "Number of HIV self-test kits distributed",
      "definition" : "Number of HIV self-test kits distributed to the client"
    },
    {
      "code" : "HIV.C.DE143",
      "display" : "HIV self-test distributed for use by",
      "definition" : "Whom the client plans to give the HIV self-test kit (self, sexual partner, social contact, etc.)"
    },
    {
      "code" : "HIV.C.DE144",
      "display" : "Self",
      "definition" : "Client plans to use the self-test kit"
    },
    {
      "code" : "HIV.C.DE145",
      "display" : "Family member",
      "definition" : "Client plans to give the self-test kit to a family member to use"
    },
    {
      "code" : "HIV.C.DE146",
      "display" : "Drug-injecting partner",
      "definition" : "Client plans to give the self-test kit to a drug-injecting partner"
    },
    {
      "code" : "HIV.C.DE147",
      "display" : "Sexual partner",
      "definition" : "Client plans to give the self-test kit to a sexual partner"
    },
    {
      "code" : "HIV.C.DE148",
      "display" : "Social contact",
      "definition" : "Client plans to give the self-test kit to a social contact"
    },
    {
      "code" : "HIV.C.DE149",
      "display" : "Sexual and reproductive health integrated services",
      "definition" : "Offer or refer to sexual and reproductive health services"
    },
    {
      "code" : "HIV.C.DE150",
      "display" : "Contraception and family planning",
      "definition" : "Offer contraception and family planning services"
    },
    {
      "code" : "HIV.C.DE151",
      "display" : "Check pregnancy status",
      "definition" : "Check woman's pregnancy status"
    },
    {
      "code" : "HIV.C.DE152",
      "display" : "Prevent mother-to-child transmission",
      "definition" : "Offer services (counselling) to help prevent of mother-to-child transmission"
    },
    {
      "code" : "HIV.C.DE153",
      "display" : "Cervical cancer screening and treatment",
      "definition" : "Offer cervical cancer screening and treatment services"
    },
    {
      "code" : "HIV.C.DE154",
      "display" : "Anal cancer screening (for men who have sex with men)",
      "definition" : "Offer anal cancer screening (for men who have sex with men) services"
    },
    {
      "code" : "HIV.C.DE155",
      "display" : "STI testing and treatment",
      "definition" : "Offer STI testing and treatment services"
    },
    {
      "code" : "HIV.C.DE156",
      "display" : "HIV testing for partners and biological children",
      "definition" : "Offer testing for all partners and biological children of positive cases (includes partner services and index case testing), as well as partners and social contacts of people from key populations, where appropriate"
    },
    {
      "code" : "HIV.C.DE157",
      "display" : "Offer other clinical services",
      "definition" : "Other clinical services offered or referrals given to the client"
    },
    {
      "code" : "HIV.C.DE158",
      "display" : "Assessment and provision of vaccinations",
      "definition" : "Assessment and provision of vaccinations, such as for people from key populations, pregnant women and infants; and, where appropriate, tetanus vaccination for adolescent boys and men receiving VMMC"
    },
    {
      "code" : "HIV.C.DE159",
      "display" : "Hepatitis B virus (HBV) and hepatitis C virus (HCV) testing and treatment",
      "definition" : "Offer or refer for HBV testing and vaccination and HCV testing and treatment"
    },
    {
      "code" : "HIV.C.DE160",
      "display" : "Co-trimoxazole chemoprophylaxis to prevent pneumocystis carinii pneumonia",
      "definition" : "Offer or refer for co-trimoxazole chemoprophylaxis to prevent pneumocystis carinii pneumonia"
    },
    {
      "code" : "HIV.C.DE161",
      "display" : "Intensified TB case finding and linkage to TB treatment",
      "definition" : "Offer or refer for TB case finding and linkage to TB treatment"
    },
    {
      "code" : "HIV.C.DE162",
      "display" : "Provision of isoniazid preventive therapy if person does not have TB",
      "definition" : "Offer or refer for provision of isoniazid preventive therapy if person does not have TB"
    },
    {
      "code" : "HIV.C.DE163",
      "display" : "Malaria prevention (such as bed nets and prophylaxis), depending on epidemiology",
      "definition" : "Offer or refer for malaria prevention (such as bed nets and prophylaxis), depending on epidemiology"
    },
    {
      "code" : "HIV.C.DE164",
      "display" : "Other support services",
      "definition" : "Offer or refer for other support services"
    },
    {
      "code" : "HIV.C.DE165",
      "display" : "Mental health services",
      "definition" : "Offer or refer for mental health services"
    },
    {
      "code" : "HIV.C.DE166",
      "display" : "Psychosocial counselling, support and treatment adherence counselling",
      "definition" : "Offer or refer for psychosocial counselling, support and treatment adherence counselling"
    },
    {
      "code" : "HIV.C.DE167",
      "display" : "Support for disclosure and partner services",
      "definition" : "Offer or refer for support for disclosure and partner services"
    },
    {
      "code" : "HIV.C.DE168",
      "display" : "Legal and social services",
      "definition" : "Offer or refer for legal and social services"
    },
    {
      "code" : "HIV.C.DE169",
      "display" : "Services for responding to violence against women",
      "definition" : "Offer or refer for services for responding to violence against women, including first-line support and psychosocial support, post-rape care and other support services including shelters, legal services and women and child protection services"
    },
    {
      "code" : "HIV.D.DE1",
      "display" : "Reason for visit",
      "definition" : "Whether visit was scheduled or unscheduled, clinical only, or for ARV drug pick-up"
    },
    {
      "code" : "HIV.D.DE2",
      "display" : "First clinical visit",
      "definition" : "The client's first appointment for clinical care by a provider at the facility"
    },
    {
      "code" : "HIV.D.DE3",
      "display" : "Clinical visit",
      "definition" : "Appointment for clinical care by a provider"
    },
    {
      "code" : "HIV.D.DE4",
      "display" : "ART initiation",
      "definition" : "Appointment for initiation of ART"
    },
    {
      "code" : "HIV.D.DE5",
      "display" : "ART drug pick up",
      "definition" : "Appointment for an antiretroviral drug pick up"
    },
    {
      "code" : "HIV.D.DE6",
      "display" : "Issues and concerns",
      "definition" : "Visit to address issues and concerns"
    },
    {
      "code" : "HIV.D.DE7",
      "display" : "Post-treatment follow-up visit for cervical precancer lesions or invasive cervical cancer",
      "definition" : "Appointment for a post-treatment follow-up visit for cervical precancer lesions or invasive cervical cancer"
    },
    {
      "code" : "HIV.D.DE8",
      "display" : "Scheduled visit",
      "definition" : "Is this is a scheduled visit?"
    },
    {
      "code" : "HIV.D.DE9",
      "display" : "Body temperature",
      "definition" : "Temperature of the client in Celsius"
    },
    {
      "code" : "HIV.D.DE10",
      "display" : "Respiratory rate",
      "definition" : "The number of breaths per minute"
    },
    {
      "code" : "HIV.D.DE11",
      "display" : "Heart rate",
      "definition" : "The number of heartbeats per minute"
    },
    {
      "code" : "HIV.D.DE12",
      "display" : "Body height",
      "definition" : "The client's height in centimetres"
    },
    {
      "code" : "HIV.D.DE13",
      "display" : "Body weight",
      "definition" : "The client's current weight in kilograms"
    },
    {
      "code" : "HIV.D.DE14",
      "display" : "Systolic blood pressure",
      "definition" : "Systolic blood pressure (SBP) in mmHg"
    },
    {
      "code" : "HIV.D.DE15",
      "display" : "Diastolic blood pressure",
      "definition" : "Diastolic blood pressure (DBP) in mmHg"
    },
    {
      "code" : "HIV.D.DE16",
      "display" : "Blood pressure cannot be taken",
      "definition" : "If the client's blood pressure cannot be taken, this should be indicated here. Otherwise, blood pressure should be measured."
    },
    {
      "code" : "HIV.D.DE17",
      "display" : "Signs of serious illness",
      "definition" : "Signs that may indicate the client has a serious illness and needs triage or an emergency referral"
    },
    {
      "code" : "HIV.D.DE18",
      "display" : "Fever of 39 C or greater",
      "definition" : "Client has a fever with a measured temperature of 102.2 F/39 C or greater"
    },
    {
      "code" : "HIV.D.DE19",
      "display" : "Tachycardia",
      "definition" : "Heart rate above a rate per minute based on age"
    },
    {
      "code" : "HIV.D.DE20",
      "display" : "Tachypnea",
      "definition" : "Respiratory rate above a number of breaths per minute based on age"
    },
    {
      "code" : "HIV.D.DE21",
      "display" : "Unable to walk unaided",
      "definition" : "Client is not able to walk without help"
    },
    {
      "code" : "HIV.D.DE22",
      "display" : "Lethargy",
      "definition" : "Client is exhibiting lethargy as a sign of serious illness"
    },
    {
      "code" : "HIV.D.DE23",
      "display" : "Unconsciousness",
      "definition" : "Client is currently unconscious"
    },
    {
      "code" : "HIV.D.DE24",
      "display" : "Convulsions",
      "definition" : "Client is convulsing"
    },
    {
      "code" : "HIV.D.DE25",
      "display" : "Unable to drink",
      "definition" : "Child is not able to drink"
    },
    {
      "code" : "HIV.D.DE26",
      "display" : "Unable to breastfeed",
      "definition" : "Infant or child is not able to breastfeed"
    },
    {
      "code" : "HIV.D.DE27",
      "display" : "Repeated vomiting",
      "definition" : "Client is repeatedly vomiting"
    },
    {
      "code" : "HIV.D.DE28",
      "display" : "Headache",
      "definition" : "Client is exhibiting a headache"
    },
    {
      "code" : "HIV.D.DE29",
      "display" : "Other sign of serious illness",
      "definition" : "Client is exhibiting another sign of a serious illness"
    },
    {
      "code" : "HIV.D.DE30",
      "display" : "Other sign of serious illness (specify)",
      "definition" : "Client is exhibiting another sign of a serious illness (specify)"
    },
    {
      "code" : "HIV.D.DE31",
      "display" : "Currently pregnant",
      "definition" : "Client is currently pregnant"
    },
    {
      "code" : "HIV.D.DE32",
      "display" : "Breastfeeding",
      "definition" : "Client is giving infant breast milk"
    },
    {
      "code" : "HIV.D.DE33",
      "display" : "Number of pregnancies (gravida)",
      "definition" : "Total number of times the woman has been pregnant (gravida)"
    },
    {
      "code" : "HIV.D.DE34",
      "display" : "Number of miscarriages and/or abortions",
      "definition" : "Total number of pregnancies lost/ended due to miscarriages and/or abortions before 22 weeks/5 months"
    },
    {
      "code" : "HIV.D.DE35",
      "display" : "Number of live births",
      "definition" : "Total number of live births after 22 weeks"
    },
    {
      "code" : "HIV.D.DE36",
      "display" : "Parity",
      "definition" : "Calculated parity is the total number of live and stillbirths"
    },
    {
      "code" : "HIV.D.DE37",
      "display" : "Serodiscordant partner",
      "definition" : "Client's HIV status is different from a current partner's HIV status"
    },
    {
      "code" : "HIV.D.DE38",
      "display" : "On ART",
      "definition" : "Client is currently taking ART"
    },
    {
      "code" : "HIV.D.DE39",
      "display" : "ART start date",
      "definition" : "The date on which the client started or restarted ART"
    },
    {
      "code" : "HIV.D.DE40",
      "display" : "Stopped ART",
      "definition" : "Client stopped taking ART"
    },
    {
      "code" : "HIV.D.DE41",
      "display" : "Date ART stopped",
      "definition" : "Date on which client stopped ART"
    },
    {
      "code" : "HIV.D.DE42",
      "display" : "Established on ART",
      "definition" : "Is the client successfully established on ART?"
    },
    {
      "code" : "HIV.D.DE43",
      "display" : "ART start type",
      "definition" : "Whether the client is ART naive or is restarting ART"
    },
    {
      "code" : "HIV.D.DE44",
      "display" : "First-time user of ART",
      "definition" : "Client is ART naive, having never taken ART to treat HIV before"
    },
    {
      "code" : "HIV.D.DE45",
      "display" : "Restarting ART",
      "definition" : "Client is restarting ART after stopping treatment for any reason"
    },
    {
      "code" : "HIV.D.DE46",
      "display" : "Date of initiation on ART",
      "definition" : "The date on which the client was first initiated on ART"
    },
    {
      "code" : "HIV.D.DE47",
      "display" : "Time on ART",
      "definition" : "Time the client has been on ART since starting or restarting it in years and months"
    },
    {
      "code" : "HIV.D.DE48",
      "display" : "Date(s) ART restarted",
      "definition" : "Date(s) client restarted ART after stopping (intentionally interrupting) for any number of reasons (see 'Reason ART stopped')"
    },
    {
      "code" : "HIV.D.DE49",
      "display" : "ART cohort",
      "definition" : "Month and year client originally started ART (documented) at a health facility in the system. The cohort is a group of patients who started ART in the same month (or quarter) and year, whose status is followed over time, using the ART register."
    },
    {
      "code" : "HIV.D.DE50",
      "display" : "Transfer in for HIV care",
      "definition" : "Client is transferring in with records or known ART drugs and ART start date"
    },
    {
      "code" : "HIV.D.DE51",
      "display" : "Date of transfer in",
      "definition" : "Date client presented at facility (with transfer/referral slip) from another facility (and on ART) within the system"
    },
    {
      "code" : "HIV.D.DE52",
      "display" : "Facility transferred from",
      "definition" : "Name of health facility client was transferred from"
    },
    {
      "code" : "HIV.D.DE53",
      "display" : "Date enrolled in HIV care",
      "definition" : "Date client first enrols in HIV care at the facility. Begins when a person with a confirmed HIV diagnosis presents to a facility where HIV care is provided and a medical record, patient card, file or chart is opened for the first time. This could be at an HIV care/ART, MNCH or TB clinic."
    },
    {
      "code" : "HIV.D.DE54",
      "display" : "Age at enrolment",
      "definition" : "Client's age when the client was enrolled in ART care"
    },
    {
      "code" : "HIV.D.DE55",
      "display" : "Facility where client first enrolled in HIV care",
      "definition" : "Facility where the client first enrolled in HIV care"
    },
    {
      "code" : "HIV.D.DE56",
      "display" : "Antiretroviral (ARV) drugs received prior to enrolment",
      "definition" : "Whether or not the client received ARV drugs prior to enrolling into HIV care"
    },
    {
      "code" : "HIV.D.DE57",
      "display" : "No prior ARVs",
      "definition" : "Client received no prior ARVs"
    },
    {
      "code" : "HIV.D.DE58",
      "display" : "Received ARVs prior without records/documentation",
      "definition" : "Client received ARVs prior without records/documentation"
    },
    {
      "code" : "HIV.D.DE59",
      "display" : "Received ARVs during pregnancy or breastfeeding",
      "definition" : "Client received ARVs during pregnancy or breastfeeding"
    },
    {
      "code" : "HIV.D.DE60",
      "display" : "Received ARVs for PEP or PrEP",
      "definition" : "Client received ARVs for post-exposure prophylaxis (PEP) or PrEP"
    },
    {
      "code" : "HIV.D.DE61",
      "display" : "ARV prophylaxis for an HIV-exposed infant",
      "definition" : "Client received ARV prophylaxis for an HIV-exposed infant"
    },
    {
      "code" : "HIV.D.DE62",
      "display" : "Date ARV drugs received prior to enrolment",
      "definition" : "Date ARV drugs were started prior to enrolment into HIV care/ART"
    },
    {
      "code" : "HIV.D.DE63",
      "display" : "Location ARV drugs received prior to enrolment",
      "definition" : "Health facility (or other location) where ARV drugs were received prior to enrolment into HIV care/ART"
    },
    {
      "code" : "HIV.D.DE64",
      "display" : "ARV drug regimen received prior to enrolment",
      "definition" : "ARV drug regimen received prior to enrolment into HIV care/ART"
    },
    {
      "code" : "HIV.D.DE65",
      "display" : "Existing chronic health conditions",
      "definition" : "Does the client have any current chronic health conditions or problems?"
    },
    {
      "code" : "HIV.D.DE66",
      "display" : "No chronic or past health conditions",
      "definition" : "Client does not have chronic diseases or any past health conditions"
    },
    {
      "code" : "HIV.D.DE67",
      "display" : "Don't know",
      "definition" : "Client does not know whether she has any chronic diseases or past health conditions"
    },
    {
      "code" : "HIV.D.DE68",
      "display" : "Diabetes other or unspecified",
      "definition" : "Client has diabetes of other or unspecified type"
    },
    {
      "code" : "HIV.D.DE69",
      "display" : "Diabetes pre-existing type 1",
      "definition" : "Client has pre-existing type 1 diabetes mellitus"
    },
    {
      "code" : "HIV.D.DE70",
      "display" : "Diabetes pre-existing type 2",
      "definition" : "Client has pre-existing type 2 diabetes mellitus"
    },
    {
      "code" : "HIV.D.DE71",
      "display" : "Hypertension",
      "definition" : "High blood pressure"
    },
    {
      "code" : "HIV.D.DE72",
      "display" : "Other",
      "definition" : "Other health conditions not included in the list"
    },
    {
      "code" : "HIV.D.DE73",
      "display" : "Other (specify)",
      "definition" : "Other health conditions not included in the list (specify)"
    },
    {
      "code" : "HIV.D.DE74",
      "display" : "Original first-line ART regimen",
      "definition" : "Original full, first-line ARV drug regimen patient started on at this facility"
    },
    {
      "code" : "HIV.D.DE75",
      "display" : "Current ART regimen",
      "definition" : "The current ART regimen the client is taking"
    },
    {
      "code" : "HIV.D.DE76",
      "display" : "Current ART regimen start date",
      "definition" : "The date on which the client started taking the current ART regimen"
    },
    {
      "code" : "HIV.D.DE77",
      "display" : "Preferred first-line ART regimen",
      "definition" : "The preferred first-line ART regimen for the client according to WHO (or national) guidelines"
    },
    {
      "code" : "HIV.D.DE78",
      "display" : "Alternative first-line ART regimen",
      "definition" : "The alternative first-line ART regimen for the client according to WHO (or national) guidelines"
    },
    {
      "code" : "HIV.D.DE79",
      "display" : "First-line ART regimen under special circumstances",
      "definition" : "The first-line ART regimen for the client under special circumstances according to WHO (or national) guidelines"
    },
    {
      "code" : "HIV.D.DE80",
      "display" : "Preferred second-line ART regimen",
      "definition" : "The preferred second-line ART regimen for the client according to WHO (or national) guidelines"
    },
    {
      "code" : "HIV.D.DE81",
      "display" : "Alternative second-line ART regimen",
      "definition" : "The alternative second-line ART regimen for the client according to WHO (or national) guidelines"
    },
    {
      "code" : "HIV.D.DE82",
      "display" : "Optimal regimen for transition",
      "definition" : "The optimal regimen for transition to DTG-based regimens for children established on ART"
    },
    {
      "code" : "HIV.D.DE83",
      "display" : "Current ART regimen (first-, second-, or third-line)",
      "definition" : "ART regimen for treating clients living with HIV, based on national guidance"
    },
    {
      "code" : "HIV.D.DE84",
      "display" : "First-line ART regimen for adults and adolescents",
      "definition" : "First-line ART regimen for adults and adolescents living with HIV"
    },
    {
      "code" : "HIV.D.DE85",
      "display" : "First-line ART regimen for children",
      "definition" : "First-line ART regimen for children living with HIV"
    },
    {
      "code" : "HIV.D.DE86",
      "display" : "First-line ART regimen for neonates",
      "definition" : "First-line ART regimen for neonates living with HIV"
    },
    {
      "code" : "HIV.D.DE87",
      "display" : "Second-line ART regimen for adults and adolescents",
      "definition" : "Second-line ART regimen for adults and adolescents living with HIV"
    },
    {
      "code" : "HIV.D.DE88",
      "display" : "Second-line ART regimen for children",
      "definition" : "Second-line ART regimen for children living with HIV"
    },
    {
      "code" : "HIV.D.DE89",
      "display" : "Third-line ART regimen",
      "definition" : "Third-line ART regimen for people living with HIV (Not defined by WHO. National programmes should develop policies for third-line ART)"
    },
    {
      "code" : "HIV.D.DE90",
      "display" : "ART regimen",
      "definition" : "List of ART regimens"
    },
    {
      "code" : "HIV.D.DE91",
      "display" : "ABC + 3TC + ATV/r",
      "definition" : "Regimen containing abacavir, lamivudine, and atazanavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE92",
      "display" : "ABC + 3TC + DTG",
      "definition" : "Regimen containing abacavir, lamivudine, and dolutegravir"
    },
    {
      "code" : "HIV.D.DE93",
      "display" : "ABC + 3TC + EFV",
      "definition" : "Regimen containing abacavir, lamivudine, and efavarinez"
    },
    {
      "code" : "HIV.D.DE94",
      "display" : "ABC + 3TC + LPV/r",
      "definition" : "Regimen containing abacavir, lamivudine, and lopinavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE95",
      "display" : "ABC + 3TC + NVP",
      "definition" : "Regimen containing abacavir, lamivudine, and nevirapine"
    },
    {
      "code" : "HIV.D.DE96",
      "display" : "ABC + 3TC + RAL",
      "definition" : "Regimen containing abacavir, lamivudine, and raltegravir"
    },
    {
      "code" : "HIV.D.DE97",
      "display" : "AZT + 3TC + ATV/r",
      "definition" : "Regimen containing zidovudine, lamivudine, and atazanavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE98",
      "display" : "AZT + 3TC + DRV/r",
      "definition" : "Regimen containing zidovudine, lamivudine, and darunavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE99",
      "display" : "AZT + 3TC + DTG",
      "definition" : "Regimen containing zidovudine, lamivudine, and dolutegravir"
    },
    {
      "code" : "HIV.D.DE100",
      "display" : "AZT + 3TC + EFV",
      "definition" : "Regimen containing zidovudine, lamivudine, and efavirenz"
    },
    {
      "code" : "HIV.D.DE101",
      "display" : "AZT + 3TC + EFV 600 mg",
      "definition" : "Regimen containing zidovudine, lamivudine, and efavirenz 600 mg"
    },
    {
      "code" : "HIV.D.DE102",
      "display" : "AZT + 3TC + LPV/r",
      "definition" : "Regimen containing zidovudine, lamivudine, and lopinavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE103",
      "display" : "AZT + 3TC + NVP",
      "definition" : "Regimen containing zidovudine, lamivudine, and nevirapine"
    },
    {
      "code" : "HIV.D.DE104",
      "display" : "AZT + 3TC + RAL",
      "definition" : "Regimen containing zidovudine, lamivudine, and raltegravir"
    },
    {
      "code" : "HIV.D.DE105",
      "display" : "TAF + 3TC + DTG",
      "definition" : "Regimen containing tenofovir alafenamide, lamivudine, and dolutegravir"
    },
    {
      "code" : "HIV.D.DE106",
      "display" : "TAF + FTC + DTG",
      "definition" : "Regimen containing tenofovir alafenamide, emtricitabine, and dolutegravir"
    },
    {
      "code" : "HIV.D.DE107",
      "display" : "TDF + 3TC + ATV/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and atazanavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE108",
      "display" : "TDF + 3TC + DRV/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and darunavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE109",
      "display" : "TDF + 3TC + DTG",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and dolutegravir"
    },
    {
      "code" : "HIV.D.DE110",
      "display" : "TDF + 3TC + EFV",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and efavirenz"
    },
    {
      "code" : "HIV.D.DE111",
      "display" : "TDF + 3TC + EFV 400 mg",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and efavirenz (400 mg)"
    },
    {
      "code" : "HIV.D.DE112",
      "display" : "TDF + 3TC + EFV 600 mg",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and efavirenz (600 mg)"
    },
    {
      "code" : "HIV.D.DE113",
      "display" : "TDF + 3TC + LPV/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and lopinavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE114",
      "display" : "TDF + 3TC + NVP",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and nevirapine"
    },
    {
      "code" : "HIV.D.DE115",
      "display" : "TDF + 3TC + PI/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and a boosted protease inhibitor"
    },
    {
      "code" : "HIV.D.DE116",
      "display" : "TDF + 3TC + RAL",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, lamivudine, and raltegravir"
    },
    {
      "code" : "HIV.D.DE117",
      "display" : "TDF + FTC + ATV/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and atazanavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE118",
      "display" : "TDF + FTC + DRV/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and darunavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE119",
      "display" : "TDF + FTC + DTG",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and dolutegravir"
    },
    {
      "code" : "HIV.D.DE120",
      "display" : "TDF + FTC + EFV",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and efavirenz"
    },
    {
      "code" : "HIV.D.DE121",
      "display" : "TDF + FTC + EFV 600 mg",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and efavirenz (600 mg)"
    },
    {
      "code" : "HIV.D.DE122",
      "display" : "TDF + FTC + LPV/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and lopinavir/ritonavir"
    },
    {
      "code" : "HIV.D.DE123",
      "display" : "TDF + FTC + NVP",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and nevirapine"
    },
    {
      "code" : "HIV.D.DE124",
      "display" : "TDF + FTC + PI/r",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and a boosted protease inhibitor"
    },
    {
      "code" : "HIV.D.DE125",
      "display" : "TDF + FTC + RAL",
      "definition" : "Regimen containing tenofovir disoproxil fumarate, emtricitabine, and raltegravir"
    },
    {
      "code" : "HIV.D.DE126",
      "display" : "Other",
      "definition" : "Other regimen based upon WHO recommendations"
    },
    {
      "code" : "HIV.D.DE127",
      "display" : "Other (specify)",
      "definition" : "Other regimen based upon WHO recommendations (specify)"
    },
    {
      "code" : "HIV.D.DE128",
      "display" : "ART regimen composition",
      "definition" : "Drug composition of client's current ART regimen"
    },
    {
      "code" : "HIV.D.DE129",
      "display" : "ABC",
      "definition" : "Treated with abacavir (ABC)"
    },
    {
      "code" : "HIV.D.DE130",
      "display" : "FTC",
      "definition" : "Treated with emtricitabine (FTC)"
    },
    {
      "code" : "HIV.D.DE131",
      "display" : "3TC",
      "definition" : "Treated with lamivudine (3TC)"
    },
    {
      "code" : "HIV.D.DE132",
      "display" : "AZT",
      "definition" : "Treated with zidovudine (AZT)"
    },
    {
      "code" : "HIV.D.DE133",
      "display" : "DDI",
      "definition" : "Treated with didanosine (DDI)"
    },
    {
      "code" : "HIV.D.DE134",
      "display" : "D4T",
      "definition" : "Treated with stavudine (D4T)"
    },
    {
      "code" : "HIV.D.DE135",
      "display" : "TDF",
      "definition" : "Treated with tenofovir (TDF)"
    },
    {
      "code" : "HIV.D.DE136",
      "display" : "EFV",
      "definition" : "Treated with efavirenz (EFV)"
    },
    {
      "code" : "HIV.D.DE137",
      "display" : "ETV",
      "definition" : "Treated with etravirine (ETV)"
    },
    {
      "code" : "HIV.D.DE138",
      "display" : "NVP",
      "definition" : "Treated with nevirapine (NVP)"
    },
    {
      "code" : "HIV.D.DE139",
      "display" : "RIL",
      "definition" : "Treated with rilpivirine (RIL)"
    },
    {
      "code" : "HIV.D.DE140",
      "display" : "ATV/r",
      "definition" : "Treated with atazanavir/ritonavir (ATV/r)"
    },
    {
      "code" : "HIV.D.DE141",
      "display" : "LPV/r",
      "definition" : "Treated with lopinavir/ritonavir (LPV/r)"
    },
    {
      "code" : "HIV.D.DE142",
      "display" : "DRV/r",
      "definition" : "Treated with darunavir/ritonavir (DRV/r)"
    },
    {
      "code" : "HIV.D.DE143",
      "display" : "RTV",
      "definition" : "Treated with ritonavir (RTV)"
    },
    {
      "code" : "HIV.D.DE144",
      "display" : "DTG",
      "definition" : "Treated with dolutegravir (DTG)"
    },
    {
      "code" : "HIV.D.DE145",
      "display" : "RAL",
      "definition" : "Treated with raltegravir (RAL)"
    },
    {
      "code" : "HIV.D.DE146",
      "display" : "ART regimen drug class",
      "definition" : "Drug class of current ART regimen"
    },
    {
      "code" : "HIV.D.DE147",
      "display" : "NRTI",
      "definition" : "Treated with nucleoside reverse transcriptase inhibitors (NRTIs)"
    },
    {
      "code" : "HIV.D.DE148",
      "display" : "NtRTI",
      "definition" : "Treated with nucleotide reverse-transcriptase inhibitors (NtRTIs)"
    },
    {
      "code" : "HIV.D.DE149",
      "display" : "NNRTI",
      "definition" : "Treated with non-nucleoside reverse transcriptase inhibitors (NNRTIs)"
    },
    {
      "code" : "HIV.D.DE150",
      "display" : "PI",
      "definition" : "Treated with protease inhibitors (PIs)"
    },
    {
      "code" : "HIV.D.DE151",
      "display" : "INSTI",
      "definition" : "Treated with integrase strand transfer inhibitors (INSTIs)"
    },
    {
      "code" : "HIV.D.DE152",
      "display" : "Prevention services offered and referrals",
      "definition" : "Offer or refer for prevention services"
    },
    {
      "code" : "HIV.D.DE153",
      "display" : "Offer male and female condoms and condom-compatible lubricants",
      "definition" : "Offer male and female condoms and condom-compatible lubricants"
    },
    {
      "code" : "HIV.D.DE154",
      "display" : "Harm reduction for people who inject drugs",
      "definition" : "Offer or refer people who inject drugs to harm reduction services (needle and syringe programmes, opioid substitution therapy, other drug-dependence treatment and opioid overdose prevention and management)"
    },
    {
      "code" : "HIV.D.DE155",
      "display" : "Behavioural interventions to support risk reduction",
      "definition" : "Offer or refer to services for behavioural interventions to support risk reduction, particularly for people with HIV and members of key populations"
    },
    {
      "code" : "HIV.D.DE156",
      "display" : "Sexual and reproductive health integrated services",
      "definition" : "Offer or refer to sexual and reproductive health services"
    },
    {
      "code" : "HIV.D.DE157",
      "display" : "Contraception and family planning",
      "definition" : "Offer contraception and family planning services"
    },
    {
      "code" : "HIV.D.DE158",
      "display" : "Check pregnancy status",
      "definition" : "Check woman's pregnancy status"
    },
    {
      "code" : "HIV.D.DE159",
      "display" : "Prevention of mother-to-child transmission",
      "definition" : "Offer prevention of mother-to-child transmission services (counselling)"
    },
    {
      "code" : "HIV.D.DE160",
      "display" : "STI testing and treatment",
      "definition" : "Offer STI testing and treatment services"
    },
    {
      "code" : "HIV.D.DE161",
      "display" : "HBsAg test date",
      "definition" : "Date client was tested for hepatitis B virus (HBV)"
    },
    {
      "code" : "HIV.D.DE162",
      "display" : "HBsAg test result",
      "definition" : "Hepatitis B virus test result (HBsAg)"
    },
    {
      "code" : "HIV.D.DE163",
      "display" : "Positive",
      "definition" : "HBsAg test result was positive"
    },
    {
      "code" : "HIV.D.DE164",
      "display" : "Negative",
      "definition" : "HBsAg test result was negative"
    },
    {
      "code" : "HIV.D.DE165",
      "display" : "Indeterminate",
      "definition" : "HBsAg test result was indeterminate"
    },
    {
      "code" : "HIV.D.DE166",
      "display" : "Date HBV test result returned to client",
      "definition" : "Date HBV test result (HBsAG) was returned to client"
    },
    {
      "code" : "HIV.D.DE167",
      "display" : "HBV treatment (TDF) start date",
      "definition" : "Date when client started treatment (TDF) for hepatitis B virus (HBV)"
    },
    {
      "code" : "HIV.D.DE168",
      "display" : "HBV treatment regimen prescribed",
      "definition" : "Hepatitis B virus treatment regimen prescribed"
    },
    {
      "code" : "HIV.D.DE169",
      "display" : "HCV test date",
      "definition" : "Date client was tested for hepatitis C virus (HCV antibody, HCV RNA or HCV core antigen)"
    },
    {
      "code" : "HIV.D.DE170",
      "display" : "HCV test result",
      "definition" : "Hepatitis C virus test result (HCV antibody, HCV RNA or HCV core antigen)"
    },
    {
      "code" : "HIV.D.DE171",
      "display" : "Positive",
      "definition" : "HCV test result was positive"
    },
    {
      "code" : "HIV.D.DE172",
      "display" : "Negative",
      "definition" : "HCV test result was negative"
    },
    {
      "code" : "HIV.D.DE173",
      "display" : "Indeterminate",
      "definition" : "HCV test result was indeterminate"
    },
    {
      "code" : "HIV.D.DE174",
      "display" : "Date HCV test result returned to client",
      "definition" : "Date HCV test result was returned to client"
    },
    {
      "code" : "HIV.D.DE175",
      "display" : "HCV treatment start date",
      "definition" : "Date when client started treatment for hepatitis C virus (HCV)"
    },
    {
      "code" : "HIV.D.DE176",
      "display" : "HCV treatment completion date",
      "definition" : "Date when client completed treatment for hepatitis C virus (HCV)"
    },
    {
      "code" : "HIV.D.DE177",
      "display" : "HCV treatment regimen prescribed",
      "definition" : "Hepatitis C virus treatment regimen prescribed"
    },
    {
      "code" : "HIV.D.DE178",
      "display" : "HCV viral load test date",
      "definition" : "Hepatitis C viral load test date"
    },
    {
      "code" : "HIV.D.DE179",
      "display" : "HCV viral load test result",
      "definition" : "Hepatitis C viral load test result (qualitative)"
    },
    {
      "code" : "HIV.D.DE180",
      "display" : "Detected",
      "definition" : "HCV was detected"
    },
    {
      "code" : "HIV.D.DE181",
      "display" : "Not detected",
      "definition" : "HCV was not detected"
    },
    {
      "code" : "HIV.D.DE182",
      "display" : "HCV medicine type",
      "definition" : "Type of medicine client is prescribed"
    },
    {
      "code" : "HIV.D.DE183",
      "display" : "Interferon",
      "definition" : "Client is prescribed interferon"
    },
    {
      "code" : "HIV.D.DE184",
      "display" : "Direct acting antivirals",
      "definition" : "Client is prescribed direct acting antivirals"
    },
    {
      "code" : "HIV.D.DE185",
      "display" : "Currently on TDF-based ART",
      "definition" : "Client is currently on TDF-based ART regimen"
    },
    {
      "code" : "HIV.D.DE186",
      "display" : "HIV clinical stage",
      "definition" : "WHO clinical stage of client based on signs and symptoms. WHO clinical staging is a way to categorize HIV disease severity based on new or recurrent clinical events. There are 4 WHO clinical stages that range from mild symptoms (WHO clinical stage 1) to severe symptoms (WHO clinical stage 4)."
    },
    {
      "code" : "HIV.D.DE187",
      "display" : "WHO HIV clinical stage 1",
      "definition" : "Client is currently assessed to be at a clinical stage 1, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE188",
      "display" : "WHO HIV clinical stage 2",
      "definition" : "Client is currently assessed to be at a clinical stage 2, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE189",
      "display" : "WHO HIV clinical stage 3",
      "definition" : "Client is currently assessed to be at a clinical stage 3, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE190",
      "display" : "WHO HIV clinical stage 4",
      "definition" : "Client is currently assessed to be at a clinical stage 4, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE191",
      "display" : "Number of missed doses",
      "definition" : "Number of doses of antiretroviral therapy (ART) the client missed since the last visit, used for monitoring adherence"
    },
    {
      "code" : "HIV.D.DE192",
      "display" : "Received viral load test result",
      "definition" : "Client received results from viral load test"
    },
    {
      "code" : "HIV.D.DE193",
      "display" : "Date viral load test results received by client",
      "definition" : "The date on which the client received results from viral load test"
    },
    {
      "code" : "HIV.D.DE194",
      "display" : "Date of viral load sample collection",
      "definition" : "Date and time when the sample was collected to test the client's HIV viral load"
    },
    {
      "code" : "HIV.D.DE195",
      "display" : "Date of scheduled review of viral load test results",
      "definition" : "Expected date when client's viral load test results will be returned and reviewed"
    },
    {
      "code" : "HIV.D.DE196",
      "display" : "Date of ART interruption",
      "definition" : "Date of client's ART interruption (ART stop or missed drug pick-up)"
    },
    {
      "code" : "HIV.D.DE197",
      "display" : "Reason(s) for adherence problem",
      "definition" : "Reason why client was not adherent"
    },
    {
      "code" : "HIV.D.DE198",
      "display" : "Forgot",
      "definition" : "Client reported not being adherent because they forgot"
    },
    {
      "code" : "HIV.D.DE199",
      "display" : "Toxicity/side effects",
      "definition" : "Client reported not being adherent because of toxicity/side effects"
    },
    {
      "code" : "HIV.D.DE200",
      "display" : "Busy",
      "definition" : "Client reported not being adherent because they were busy"
    },
    {
      "code" : "HIV.D.DE201",
      "display" : "Change of routine",
      "definition" : "Client reported not being adherent because of a change of routine"
    },
    {
      "code" : "HIV.D.DE202",
      "display" : "Travel cost",
      "definition" : "Client reported not being adherent because of travel cost"
    },
    {
      "code" : "HIV.D.DE203",
      "display" : "Distance to clinic",
      "definition" : "Client reported not being adherent because of distance to clinic"
    },
    {
      "code" : "HIV.D.DE204",
      "display" : "Client lost/ran out of pills",
      "definition" : "Client reported not being adherent because client lost/ran out of pills"
    },
    {
      "code" : "HIV.D.DE205",
      "display" : "Stock-out",
      "definition" : "Client reported not being adherent because of a stock-out"
    },
    {
      "code" : "HIV.D.DE206",
      "display" : "Too ill",
      "definition" : "Client reported not being adherent because of being too ill"
    },
    {
      "code" : "HIV.D.DE207",
      "display" : "Pill burden",
      "definition" : "Client reported not being adherent because of the pill burden"
    },
    {
      "code" : "HIV.D.DE208",
      "display" : "Felt well",
      "definition" : "Client reported not being adherent because they felt well"
    },
    {
      "code" : "HIV.D.DE209",
      "display" : "Depression",
      "definition" : "Client reported not being adherent because of depression"
    },
    {
      "code" : "HIV.D.DE210",
      "display" : "Alcohol use",
      "definition" : "Client reported not being adherent because of alcohol use"
    },
    {
      "code" : "HIV.D.DE211",
      "display" : "Substance use",
      "definition" : "Client reported not being adherent because of substance use (i.e. drugs)"
    },
    {
      "code" : "HIV.D.DE212",
      "display" : "Stigma/disclosure concerns",
      "definition" : "Client reported not being adherent because of stigma/disclosure concerns"
    },
    {
      "code" : "HIV.D.DE213",
      "display" : "Lack of food",
      "definition" : "Client reported not being adherent because of a lack of food"
    },
    {
      "code" : "HIV.D.DE214",
      "display" : "Poor palatability",
      "definition" : "Client reported not being adherent because of poor palatability"
    },
    {
      "code" : "HIV.D.DE215",
      "display" : "Other reason for nonadherence",
      "definition" : "Client reported not being adherent because of other reason for nonadherence"
    },
    {
      "code" : "HIV.D.DE216",
      "display" : "Other reason for nonadherence (specify)",
      "definition" : "Client reported not being adherent because of other reason for nonadherence (specify)"
    },
    {
      "code" : "HIV.D.DE217",
      "display" : "Reason ART stopped",
      "definition" : "Reason client intentionally stopped ART"
    },
    {
      "code" : "HIV.D.DE218",
      "display" : "Toxicity/side effects",
      "definition" : "Client stopped ART because of toxicity/side effects"
    },
    {
      "code" : "HIV.D.DE219",
      "display" : "Severe illness, hospitalization",
      "definition" : "Client stopped ART because of severe illness, hospitalization"
    },
    {
      "code" : "HIV.D.DE220",
      "display" : "Drugs out of stock",
      "definition" : "Client stopped ART because drugs were out of stock"
    },
    {
      "code" : "HIV.D.DE221",
      "display" : "Client lacks finances",
      "definition" : "Client stopped ART because of lack of finances"
    },
    {
      "code" : "HIV.D.DE222",
      "display" : "Excluded HIV infection in infant",
      "definition" : "Client stopped ART because HIV infection in infant was excluded"
    },
    {
      "code" : "HIV.D.DE223",
      "display" : "Other reason for stopping ART",
      "definition" : "Client stopped ART because of other reason"
    },
    {
      "code" : "HIV.D.DE224",
      "display" : "Other reason for stopping ART (specify)",
      "definition" : "Client stopped ART because of other reason (specify)"
    },
    {
      "code" : "HIV.D.DE225",
      "display" : "Treatment failure",
      "definition" : "ART treatment failure"
    },
    {
      "code" : "HIV.D.DE226",
      "display" : "Clinical failure",
      "definition" : "New or recurrent clinical event indicating severe immunodeficiency in adults or advanced or severe immunodeficiency in children"
    },
    {
      "code" : "HIV.D.DE227",
      "display" : "Immunological failure",
      "definition" : "CD4 count at or below 250 cells/mm3 following clinical failure"
    },
    {
      "code" : "HIV.D.DE228",
      "display" : "Virological failure",
      "definition" : "The inability to achieve or maintain viral suppression below a certain threshold indicated by viral load above 1000 copies/mL based on two consecutive viral load measurements in 3 months, with adherence support following the first viral load test"
    },
    {
      "code" : "HIV.D.DE229",
      "display" : "General care activities recommended",
      "definition" : "General care activities to be performed during the care visit"
    },
    {
      "code" : "HIV.D.DE230",
      "display" : "Determine WHO clinical stage",
      "definition" : "Determine WHO clinical stage based on past and current HIV-related conditions"
    },
    {
      "code" : "HIV.D.DE231",
      "display" : "Determine if advanced disease",
      "definition" : "Determine if client is in an advanced stage of HIV, as a special package of services may be provided"
    },
    {
      "code" : "HIV.D.DE232",
      "display" : "Prepare for ART",
      "definition" : "Prepare client new to ART"
    },
    {
      "code" : "HIV.D.DE233",
      "display" : "Prepare, assess and support adherence",
      "definition" : "Prepare, assess and support adherence"
    },
    {
      "code" : "HIV.D.DE234",
      "display" : "Manage current medications",
      "definition" : "Manage current medications being taken by the client"
    },
    {
      "code" : "HIV.D.DE235",
      "display" : "Check pregnancy status",
      "definition" : "Check woman's pregnancy status"
    },
    {
      "code" : "HIV.D.DE236",
      "display" : "Provide family planning and contraception",
      "definition" : "Provide family planning and contraception counselling"
    },
    {
      "code" : "HIV.D.DE237",
      "display" : "Support disclosure and partner notification",
      "definition" : "Support disclosure and partner notification"
    },
    {
      "code" : "HIV.D.DE238",
      "display" : "Counsel on risk reduction and prevention",
      "definition" : "Counsel on risk reduction and combination HIV prevention approaches"
    },
    {
      "code" : "HIV.D.DE239",
      "display" : "Assess, prevent and manage noncommunicable diseases",
      "definition" : "Assess, prevent and manage noncommunicable diseases"
    },
    {
      "code" : "HIV.D.DE240",
      "display" : "Screen for and manage mental health problems",
      "definition" : "Screen for and manage mental health problems"
    },
    {
      "code" : "HIV.D.DE241",
      "display" : "Screen for and manage and substance use issues",
      "definition" : "Screen for and manage and substance use issues"
    },
    {
      "code" : "HIV.D.DE242",
      "display" : "Provide psychosocial counselling and support",
      "definition" : "Provide psychosocial counselling and support"
    },
    {
      "code" : "HIV.D.DE243",
      "display" : "Manage pain and symptoms",
      "definition" : "Manage pain and symptoms client is experiencing"
    },
    {
      "code" : "HIV.D.DE244",
      "display" : "Conduct a nutritional assessment and counsel on nutrition",
      "definition" : "Conduct a nutritional assessment and counsel on nutrition"
    },
    {
      "code" : "HIV.D.DE245",
      "display" : "Conduct a growth and development assessment",
      "definition" : "Conduct a growth and development assessment"
    },
    {
      "code" : "HIV.D.DE246",
      "display" : "Provide support on infant and child feeding",
      "definition" : "Provide support on infant and child feeding to mother or care giver"
    },
    {
      "code" : "HIV.D.DE247",
      "display" : "Preventing and treating coinfections",
      "definition" : "Coinfection prevention and treatment activities performed during the care visit"
    },
    {
      "code" : "HIV.D.DE248",
      "display" : "Provide co-trimoxazole preventive therapy (CPT)",
      "definition" : "Provide co-trimoxazole prophylaxis for clients new to ART or identified as taking it"
    },
    {
      "code" : "HIV.D.DE249",
      "display" : "Intensified TB case finding and linkage to TB treatment",
      "definition" : "Offer or refer for intensified TB case finding and linkage to TB treatment"
    },
    {
      "code" : "HIV.D.DE250",
      "display" : "Provide isoniazid preventive therapy",
      "definition" : "Provide isoniazid preventive therapy"
    },
    {
      "code" : "HIV.D.DE251",
      "display" : "Screen for cryptococcal infection and fungal prophylaxis",
      "definition" : "Screen for cryptococcal infection and fungal prophylaxis"
    },
    {
      "code" : "HIV.D.DE252",
      "display" : "Screen for hepatitis B",
      "definition" : "Screen for hepatitis B virus"
    },
    {
      "code" : "HIV.D.DE253",
      "display" : "Screen for hepatitis C",
      "definition" : "Screen for hepatitis C virus"
    },
    {
      "code" : "HIV.D.DE254",
      "display" : "Prevent malaria",
      "definition" : "Prevent malaria including with insecticide-treated bed-nets and prophylaxis"
    },
    {
      "code" : "HIV.D.DE255",
      "display" : "Screen for STIs",
      "definition" : "Screen for STIs"
    },
    {
      "code" : "HIV.D.DE256",
      "display" : "Prevent and screen for cervical cancer",
      "definition" : "Prevent and screen for cervical cancer"
    },
    {
      "code" : "HIV.D.DE257",
      "display" : "Anal cancer screening (for men who have sex with men)",
      "definition" : "Offer anal cancer screening (for men who have sex with men)"
    },
    {
      "code" : "HIV.D.DE258",
      "display" : "Assessment and provision of vaccinations",
      "definition" : "Assessment and provision of vaccinations, such as for people from key populations, pregnant women and infants; and, where appropriate, tetanus vaccination for adolescent boys and men receiving VMMC"
    },
    {
      "code" : "HIV.D.DE259",
      "display" : "Risk factors, comorbidities and coinfections signs and symptoms",
      "definition" : "Signs and symptoms of opportunistic infections or other comorbidities experienced by client"
    },
    {
      "code" : "HIV.D.DE260",
      "display" : "Oral candidiasis",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include oral candidiasis (after the first 6-8 weeks of life)"
    },
    {
      "code" : "HIV.D.DE261",
      "display" : "Vaginal candidiasis",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include vaginal candidiasis"
    },
    {
      "code" : "HIV.D.DE262",
      "display" : "Cough",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include cough"
    },
    {
      "code" : "HIV.D.DE263",
      "display" : "Prolonged fever",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include prolonged fever"
    },
    {
      "code" : "HIV.D.DE264",
      "display" : "Night sweats",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include night sweats"
    },
    {
      "code" : "HIV.D.DE265",
      "display" : "Weight loss",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include weight loss"
    },
    {
      "code" : "HIV.D.DE266",
      "display" : "Difficulty breathing",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include difficulty breathing"
    },
    {
      "code" : "HIV.D.DE267",
      "display" : "Pneumonia",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include pneumonia"
    },
    {
      "code" : "HIV.D.DE268",
      "display" : "Urethral discharge",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include urethral discharge"
    },
    {
      "code" : "HIV.D.DE269",
      "display" : "Syphilis",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include syphilis"
    },
    {
      "code" : "HIV.D.DE270",
      "display" : "Pelvic inflammatory disease",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include pelvic inflammatory disease"
    },
    {
      "code" : "HIV.D.DE271",
      "display" : "Ulcers - skin",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include ulcers - skin"
    },
    {
      "code" : "HIV.D.DE272",
      "display" : "Ulcers - mouth or other",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include ulcers - mouth or other"
    },
    {
      "code" : "HIV.D.DE273",
      "display" : "Ulcers - male genital",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include ulcers - male genital"
    },
    {
      "code" : "HIV.D.DE274",
      "display" : "Vaginal discharge",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include vaginal discharge"
    },
    {
      "code" : "HIV.D.DE275",
      "display" : "Malaria",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include malaria"
    },
    {
      "code" : "HIV.D.DE276",
      "display" : "Chronic obstructive pulmonary disease",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include chronic obstructive pulmonary disease"
    },
    {
      "code" : "HIV.D.DE277",
      "display" : "Hypertension",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include hypertension"
    },
    {
      "code" : "HIV.D.DE278",
      "display" : "Diabetes",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include diabetes"
    },
    {
      "code" : "HIV.D.DE279",
      "display" : "Gestational diabetes",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include gestational diabetes"
    },
    {
      "code" : "HIV.D.DE280",
      "display" : "Mental health disorders",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include mental health disorders (including depression, dementia, encephalitis, seizures)"
    },
    {
      "code" : "HIV.D.DE281",
      "display" : "Diarrhoea or abdominal pain",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include diarrhoea or abdominal pain"
    },
    {
      "code" : "HIV.D.DE282",
      "display" : "Presumptive TB",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include presumptive TB"
    },
    {
      "code" : "HIV.D.DE283",
      "display" : "Severe or complicated malnutrition",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include severe or complicated malnutrition"
    },
    {
      "code" : "HIV.D.DE284",
      "display" : "Poor growth or development",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include poor growth or development"
    },
    {
      "code" : "HIV.D.DE285",
      "display" : "Oedema",
      "definition" : "Client's comorbidities or coinfections or symptoms of these include oedema"
    },
    {
      "code" : "HIV.D.DE286",
      "display" : "Previously treated for TB",
      "definition" : "Client has previously been treated for tuberculosis (TB)"
    },
    {
      "code" : "HIV.D.DE287",
      "display" : "Other",
      "definition" : "Other comorbidities or coinfection signs or symptoms"
    },
    {
      "code" : "HIV.D.DE288",
      "display" : "Other (specify)",
      "definition" : "Other comorbidities or coinfection signs or symptoms (specify)"
    },
    {
      "code" : "HIV.D.DE289",
      "display" : "WHO HIV clinical stage condition or symptom",
      "definition" : "New or recurrent clinical events used to categorize HIV disease severity based at baseline and follow up"
    },
    {
      "code" : "HIV.D.DE290",
      "display" : "Asymptomatic",
      "definition" : "No HIV-related symptoms reported and no clinical signs on examination"
    },
    {
      "code" : "HIV.D.DE291",
      "display" : "Persistent generalized lymphadenopathy",
      "definition" : "Persistent enlarged lymph nodes >1 cm at two or more non-contiguous sites (excluding inguinal) without known cause"
    },
    {
      "code" : "HIV.D.DE292",
      "display" : "Moderate unexplained weight loss",
      "definition" : "Moderate unexplained weight loss (<10% of presumed or measured body weight)"
    },
    {
      "code" : "HIV.D.DE293",
      "display" : "Recurrent respiratory tract infections",
      "definition" : "Client's symptoms include recurrent respiratory tract infections including sinusitis, tonsillitis, otitis media or pharyngitis"
    },
    {
      "code" : "HIV.D.DE294",
      "display" : "Unexplained persistent hepatosplenomegaly",
      "definition" : "Client's symptoms include unexplained persistent hepatosplenomegaly"
    },
    {
      "code" : "HIV.D.DE295",
      "display" : "Herpes zoster",
      "definition" : "Client's symptoms include herpes zoster"
    },
    {
      "code" : "HIV.D.DE296",
      "display" : "Angular cheilitis",
      "definition" : "Client's symptoms include angular cheilitis"
    },
    {
      "code" : "HIV.D.DE297",
      "display" : "Linear gingival erythema",
      "definition" : "Client's symptoms include linear gingival erythema"
    },
    {
      "code" : "HIV.D.DE298",
      "display" : "Recurrent oral ulceration",
      "definition" : "Client's symptoms include recurrent oral ulceration"
    },
    {
      "code" : "HIV.D.DE299",
      "display" : "Papular pruritic eruption",
      "definition" : "Client's symptoms include papular pruritic eruption"
    },
    {
      "code" : "HIV.D.DE300",
      "display" : "Fungal nail infections",
      "definition" : "Client's symptoms include fungal nail infections"
    },
    {
      "code" : "HIV.D.DE301",
      "display" : "Seborrhoeic dermatitis",
      "definition" : "Client's symptoms include seborrhoeic dermatitis"
    },
    {
      "code" : "HIV.D.DE302",
      "display" : "Extensive wart virus infection",
      "definition" : "Client's symptoms include extensive wart virus infection"
    },
    {
      "code" : "HIV.D.DE303",
      "display" : "Extensive molluscum contagiosum",
      "definition" : "Client's symptoms include extensive molluscum contagiosum"
    },
    {
      "code" : "HIV.D.DE304",
      "display" : "Unexplained persistent parotid enlargement",
      "definition" : "Client's symptoms include unexplained persistent parotid enlargement"
    },
    {
      "code" : "HIV.D.DE305",
      "display" : "Unexplained severe weight loss in adults",
      "definition" : "Unexplained severe weight loss (>10% of presumed or measured body weight)"
    },
    {
      "code" : "HIV.D.DE306",
      "display" : "Unexplained moderate malnutrition not adequately responding to standard therapy",
      "definition" : "Defined as weight-for-height < - 2 z-score or mid-upper arm circumference 115 mm to <125 mm. For children younger than five years of age: stunting is defined as severe acute malnutrition - either weight for height < -3 z-score or mid-upper arm circumference <115 mm or the presence of oedema."
    },
    {
      "code" : "HIV.D.DE307",
      "display" : "Unexplained chronic diarrhoea for longer than 1 month",
      "definition" : "Client's symptoms include unexplained chronic diarrhoea for longer than 1 month"
    },
    {
      "code" : "HIV.D.DE308",
      "display" : "Unexplained persistent diarrhoea (14 days or more)",
      "definition" : "Client's symptoms include unexplained persistent diarrhoea (14 days or more)"
    },
    {
      "code" : "HIV.D.DE309",
      "display" : "Unexplained persistent fever (above 37.5 C, intermittent or constant, for longer than one 1 month)",
      "definition" : "Client's symptoms include unexplained persistent fever (above 37.5 C, intermittent or constant, for longer than one 1 month)"
    },
    {
      "code" : "HIV.D.DE310",
      "display" : "Persistent oral candidiasis",
      "definition" : "Client's symptoms include persistent oral candidiasis"
    },
    {
      "code" : "HIV.D.DE311",
      "display" : "Oral hairy leukoplakia",
      "definition" : "Client has fine white small linear or corrugated lesions on lateral borders of the tongue that do not scrape off"
    },
    {
      "code" : "HIV.D.DE312",
      "display" : "Pulmonary TB",
      "definition" : "Client's symptoms include pulmonary TB"
    },
    {
      "code" : "HIV.D.DE313",
      "display" : "Lymph node TB",
      "definition" : "Client's symptoms include lymph node TB"
    },
    {
      "code" : "HIV.D.DE314",
      "display" : "Severe bacterial infections (such as pneumonia, empyema, pyomyositis, bone or joint infection, meningitis, bacteraemia)",
      "definition" : "Client's symptoms include severe bacterial infections (such as pneumonia, empyema, pyomyositis, bone or joint infection, meningitis, bacteraemia)"
    },
    {
      "code" : "HIV.D.DE315",
      "display" : "Severe recurrent bacterial pneumonia",
      "definition" : "Client's symptoms include severe recurrent bacterial pneumonia"
    },
    {
      "code" : "HIV.D.DE316",
      "display" : "Acute necrotizing ulcerative stomatitis",
      "definition" : "Client's symptoms include acute necrotizing ulcerative stomatitis"
    },
    {
      "code" : "HIV.D.DE317",
      "display" : "Acute necrotizing ulcerative gingivitis",
      "definition" : "Client's symptoms include acute necrotizing ulcerative gingivitis"
    },
    {
      "code" : "HIV.D.DE318",
      "display" : "Acute necrotizing ulcerative periodontitis",
      "definition" : "Client's symptoms include acute necrotizing ulcerative periodontitis"
    },
    {
      "code" : "HIV.D.DE319",
      "display" : "Unexplained anaemia (<8 g/dL)",
      "definition" : "Client's symptoms include unexplained anaemia (<8 g/dL)"
    },
    {
      "code" : "HIV.D.DE320",
      "display" : "Neutropaenia (<0.5 x 10^9/L)",
      "definition" : "Client's symptoms include neutropaenia (<0.5 x 10^9/L)"
    },
    {
      "code" : "HIV.D.DE321",
      "display" : "Chronic thrombocytopaenia (<50 x 10^9/L)",
      "definition" : "Client's symptoms include chronic thrombocytopaenia (<50 x 10^9/L)"
    },
    {
      "code" : "HIV.D.DE322",
      "display" : "Symptomatic lymphoid interstitial pneumonitis",
      "definition" : "Client's symptoms include symptomatic lymphoid interstitial pneumonitis"
    },
    {
      "code" : "HIV.D.DE323",
      "display" : "Chronic HIV-associated lung disease, including bronchiectasis",
      "definition" : "Client's symptoms include chronic HIV-associated lung disease, including bronchiectasis"
    },
    {
      "code" : "HIV.D.DE324",
      "display" : "HIV wasting syndrome",
      "definition" : "Unexplained involuntary weight loss (>10% baseline body weight), with obvious wasting or body mass index <18.5; PLUS EITHER unexplained chronic reported for longer than one month; OR reports of fever or night sweats for more than one month without other cause and lack of response to antibiotics or antimalarial agents; malaria must be excluded in malarious areas."
    },
    {
      "code" : "HIV.D.DE325",
      "display" : "Unexplained severe wasting not responding to standard therapy",
      "definition" : "Client has unexplained severe wasting not responding to standard therapy . For under 5 years old, defined as weight-for-height < -3 z-score"
    },
    {
      "code" : "HIV.D.DE326",
      "display" : "Unexplained stunting not responding to standard therapy",
      "definition" : "Client has unexplained stunting not responding to standard therapy . For under 5 years old, defined as length-for- age/height-for-age < -2 z-score"
    },
    {
      "code" : "HIV.D.DE327",
      "display" : "Unexplained severe malnutrition not responding to standard therapy",
      "definition" : "Client has unexplained severe malnutrition not responding to standard therapy . For under 5 years old, weight for height < -3 z-score or mid-upper arm circumference <115 mm or the presence of oedema"
    },
    {
      "code" : "HIV.D.DE328",
      "display" : "Pneumocystis (jirovecii) pneumonia",
      "definition" : "Client's symptoms include pneumocystis (jirovecii) pneumonia"
    },
    {
      "code" : "HIV.D.DE329",
      "display" : "Recurrent severe bacterial pneumonia",
      "definition" : "Client's symptoms include recurrent severe bacterial pneumonia"
    },
    {
      "code" : "HIV.D.DE330",
      "display" : "Recurrent severe bacterial infections (such as empyema, pyomyositis, bone or joint infection, meningitis, but excluding pneumonia)",
      "definition" : "Client's symptoms include recurrent severe bacterial infections (such as empyema, pyomyositis, bone or joint infection, meningitis, but excluding pneumonia)"
    },
    {
      "code" : "HIV.D.DE331",
      "display" : "Empyema",
      "definition" : "Client's symptoms include recurrent empyema"
    },
    {
      "code" : "HIV.D.DE332",
      "display" : "Pyomyositis",
      "definition" : "Client's symptoms include recurrent pyomyositis"
    },
    {
      "code" : "HIV.D.DE333",
      "display" : "Bone or joint infection",
      "definition" : "Client's symptoms include recurrent bone or joint infections"
    },
    {
      "code" : "HIV.D.DE334",
      "display" : "Meningitis",
      "definition" : "Client's symptoms include recurrent meningitis"
    },
    {
      "code" : "HIV.D.DE335",
      "display" : "Chronic herpes simplex infection (orolabial or cutaneous of more than 1 month duration or visceral at any site)",
      "definition" : "Client's symptoms include chronic herpes simplex infection (orolabial or cutaneous of more than 1 month duration or visceral at any site)"
    },
    {
      "code" : "HIV.D.DE336",
      "display" : "Chronic herpes simplex infection (orolabial, genital or anorectal of more than 1 month in duration or visceral at any site)",
      "definition" : "Client's symptoms include chronic herpes simplex infection (orolabial, genital or anorectal of more than one month in duration or visceral at any site)"
    },
    {
      "code" : "HIV.D.DE337",
      "display" : "Oesophageal candidiasis (or candidiasis of trachea, bronchi or lungs)",
      "definition" : "Client's symptoms include oesophageal candidiasis (or candidiasis of trachea, bronchi or lungs)"
    },
    {
      "code" : "HIV.D.DE338",
      "display" : "Extrapulmonary TB",
      "definition" : "Client's symptoms include extrapulmonary tuberculosis"
    },
    {
      "code" : "HIV.D.DE339",
      "display" : "Kaposi sarcoma",
      "definition" : "Client's symptoms include Kaposi sarcoma"
    },
    {
      "code" : "HIV.D.DE340",
      "display" : "Cytomegalovirus infection (retinitis or infection of other organs)",
      "definition" : "Client's symptoms include cytomegalovirus infection (retinitis or infection of other organs)"
    },
    {
      "code" : "HIV.D.DE341",
      "display" : "Central nervous system toxoplasmosis",
      "definition" : "Client's symptoms include central nervous system toxoplasmosis"
    },
    {
      "code" : "HIV.D.DE342",
      "display" : "HIV encephalopathy",
      "definition" : "Client's symptoms include HIV encephalopathy"
    },
    {
      "code" : "HIV.D.DE343",
      "display" : "Extrapulmonary cryptococcosis, including meningitis",
      "definition" : "Client's symptoms include extrapulmonary cryptococcosis, including meningitis"
    },
    {
      "code" : "HIV.D.DE344",
      "display" : "Disseminated nontuberculous mycobacterial infection",
      "definition" : "Client's symptoms include disseminated nontuberculous mycobacterial infection"
    },
    {
      "code" : "HIV.D.DE345",
      "display" : "Progressive multifocal leukoencephalopathy",
      "definition" : "Client's symptoms include progressive multifocal leukoencephalopathy"
    },
    {
      "code" : "HIV.D.DE346",
      "display" : "Chronic cryptosporidiosis",
      "definition" : "Client's symptoms include chronic cryptosporidiosis"
    },
    {
      "code" : "HIV.D.DE347",
      "display" : "Chronic cryptosporidiosis (with diarrhoea)",
      "definition" : "Client's symptoms include chronic cryptosporidiosis (with diarrhoea)"
    },
    {
      "code" : "HIV.D.DE348",
      "display" : "Chronic isosporiasis",
      "definition" : "Client's symptoms include chronic isosporiasis"
    },
    {
      "code" : "HIV.D.DE349",
      "display" : "Disseminated mycosis (extrapulmonary histoplasmosis, coccidioidomycosis)",
      "definition" : "Client's symptoms include disseminated mycosis (extrapulmonary histoplasmosis, coccidioidomycosis)"
    },
    {
      "code" : "HIV.D.DE350",
      "display" : "Disseminated endemic mycosis (extrapulmonary histoplasmosis, coccidioidomycosis, penicilliosis)",
      "definition" : "Client's symptoms include disseminated endemic mycosis (extrapulmonary histoplasmosis, coccidioidomycosis, penicilliosis)"
    },
    {
      "code" : "HIV.D.DE351",
      "display" : "Cerebral lymphoma",
      "definition" : "Client's symptoms include cerebral lymphoma"
    },
    {
      "code" : "HIV.D.DE352",
      "display" : "B-cell non-Hodgkin lymphoma",
      "definition" : "Client's symptoms include b-cell non-Hodgkin lymphoma"
    },
    {
      "code" : "HIV.D.DE353",
      "display" : "HIV-associated nephropathy or cardiomyopathy",
      "definition" : "Client's symptoms include HIV- associated nephropathy or cardiomyopathy"
    },
    {
      "code" : "HIV.D.DE354",
      "display" : "Recurrent septicaemia (including nontyphoidal Salmonella)",
      "definition" : "Client's symptoms include recurrent bacteraemia (septicaemia) (including nontyphoidal salmonella)"
    },
    {
      "code" : "HIV.D.DE355",
      "display" : "Invasive cervical carcinoma",
      "definition" : "Client's symptoms include invasive cervical carcinoma"
    },
    {
      "code" : "HIV.D.DE356",
      "display" : "Atypical disseminated leishmaniasis",
      "definition" : "Client's symptoms include atypical disseminated leishmaniasis"
    },
    {
      "code" : "HIV.D.DE357",
      "display" : "Neutropenia",
      "definition" : "Client's symptoms include neutropenia, an abnormally low count of a type of white blood cell (neutrophils)"
    },
    {
      "code" : "HIV.D.DE358",
      "display" : "Clinical stage at start of ART",
      "definition" : "WHO clinical stage of client based on signs and symptoms at start of ART"
    },
    {
      "code" : "HIV.D.DE359",
      "display" : "WHO clinical stage 1",
      "definition" : "Client is assessed to be at a clinical stage of 1 at the time of starting ART, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE360",
      "display" : "WHO clinical stage 2",
      "definition" : "Client is assessed to be at a clinical stage of 2 at the time of starting ART, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE361",
      "display" : "WHO clinical stage 3",
      "definition" : "Client is assessed to be at a clinical stage of 3 at the time of starting ART, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE362",
      "display" : "WHO clinical stage 4",
      "definition" : "Client is assessed to be at a clinical stage of 4 at the time of starting ART, based on clinical assessment and diagnostics"
    },
    {
      "code" : "HIV.D.DE363",
      "display" : "Date of clinical status change",
      "definition" : "Date on which the client's WHO HIV clinical stage changed, including the date when the client's stage is first determined"
    },
    {
      "code" : "HIV.D.DE364",
      "display" : "CD4 count",
      "definition" : "CD4 cell count in cells/mm^3"
    },
    {
      "code" : "HIV.D.DE365",
      "display" : "CD4 cell percentage",
      "definition" : "CD4 cell percentage"
    },
    {
      "code" : "HIV.D.DE366",
      "display" : "Date of CD4 count test",
      "definition" : "Date and time when CD4 count test was conducted"
    },
    {
      "code" : "HIV.D.DE367",
      "display" : "Baseline CD4 count",
      "definition" : "CD4 count performed at HIV diagnosis"
    },
    {
      "code" : "HIV.D.DE368",
      "display" : "Date of baseline CD4 count test",
      "definition" : "Date and time when baseline CD4 count test was conducted"
    },
    {
      "code" : "HIV.D.DE369",
      "display" : "Late ART initiation",
      "definition" : "Client had late ART initiation. That is, the client's first CD4 count from baseline CD4 test performed (such as at HIV diagnosis) was a count of <200 cells/mm3"
    },
    {
      "code" : "HIV.D.DE370",
      "display" : "Reasons for delayed ART initiation",
      "definition" : "Reason why ART was not initiated at diagnosis or within 7 days of diagnosis"
    },
    {
      "code" : "HIV.D.DE371",
      "display" : "Patient self-reported as not ready/willing",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client self-reported as not ready/willing"
    },
    {
      "code" : "HIV.D.DE372",
      "display" : "Not completed education, support and preparation for ART",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client had not completed education, support and preparation for ART"
    },
    {
      "code" : "HIV.D.DE373",
      "display" : "Fear of disclosure",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because of client's fear of disclosure"
    },
    {
      "code" : "HIV.D.DE374",
      "display" : "Patient lacks finances",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client lacks finances"
    },
    {
      "code" : "HIV.D.DE375",
      "display" : "Initiated on TB treatment",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client initiated on TB treatment"
    },
    {
      "code" : "HIV.D.DE376",
      "display" : "Patient initiated on treatment for TB meningitis",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client initiated on treatment for TB meningitis"
    },
    {
      "code" : "HIV.D.DE377",
      "display" : "Patient diagnosed with cryptococcal meningitis",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client diagnosed with cryptococcal meningitis"
    },
    {
      "code" : "HIV.D.DE378",
      "display" : "Patient diagnosed with histoplasmosis",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client diagnosed with histoplasmosis"
    },
    {
      "code" : "HIV.D.DE379",
      "display" : "Patient critically/severely ill",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because client critically/severely ill"
    },
    {
      "code" : "HIV.D.DE380",
      "display" : "Other",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because of other reason"
    },
    {
      "code" : "HIV.D.DE381",
      "display" : "Other (specify)",
      "definition" : "Client did not initiate ART at diagnosis or within 7 days of diagnosis because of other reason (specify)"
    },
    {
      "code" : "HIV.D.DE382",
      "display" : "ART initiated within 7 days of diagnosis",
      "definition" : "Client initiated ART within 7 days of diagnosis"
    },
    {
      "code" : "HIV.D.DE383",
      "display" : "Time to start ART",
      "definition" : "Time from HIV diagnosis to when client started ART"
    },
    {
      "code" : "HIV.D.DE384",
      "display" : "Within 7 days of HIV diagnosis",
      "definition" : "Client started ART within 7 days"
    },
    {
      "code" : "HIV.D.DE385",
      "display" : "Within 30 days of HIV diagnosis",
      "definition" : "Client started ART within 30 days of ART initiation (but over 7 days)"
    },
    {
      "code" : "HIV.D.DE386",
      "display" : "Within 90 days of HIV diagnosis",
      "definition" : "Client started ART within 90 days of ART initiation (but over 30 days)"
    },
    {
      "code" : "HIV.D.DE387",
      "display" : "Viral load test result",
      "definition" : "Result from the viral load test in number of copies/mL"
    },
    {
      "code" : "HIV.D.DE388",
      "display" : "Virally suppressed",
      "definition" : "The client is virally suppressed for HIV, based on the client's most recent viral load test result being less than 1000 copies/mL"
    },
    {
      "code" : "HIV.D.DE389",
      "display" : "Date viral load test results received",
      "definition" : "Date the viral load test result was received from the lab or completed in the facility"
    },
    {
      "code" : "HIV.D.DE390",
      "display" : "Viral load suppression date",
      "definition" : "Date on which the client tested as becoming virally suppressed, as indicated by a viral load test result under 1000 copies/mL"
    },
    {
      "code" : "HIV.D.DE391",
      "display" : "Reason for HIV viral load test",
      "definition" : "Whether the viral load is being tested for routine monitoring on a set schedule or for targeted monitoring for suspected treatment failure"
    },
    {
      "code" : "HIV.D.DE392",
      "display" : "Routine viral load test",
      "definition" : "Routine refers to viral load tests obtained at standard intervals following ART initiation to monitor viral load response to ART"
    },
    {
      "code" : "HIV.D.DE393",
      "display" : "Targeted viral load monitoring",
      "definition" : "Targeted refers to viral load tests obtained based on a specific clinical indication (such as concern about disease progression or failure to respond to ART)"
    },
    {
      "code" : "HIV.D.DE394",
      "display" : "Initial viral load test",
      "definition" : "The first viral load test of the client"
    },
    {
      "code" : "HIV.D.DE395",
      "display" : "Follow-up viral load test after receiving enhanced adherence counselling",
      "definition" : "A follow-up viral load test within 3-6 months after enhanced adherence counselling after client received a high viral load test result"
    },
    {
      "code" : "HIV.D.DE396",
      "display" : "Hepatitis B test required",
      "definition" : "Hepatitis B test is required"
    },
    {
      "code" : "HIV.D.DE397",
      "display" : "Hepatitis C test recommended",
      "definition" : "Hepatitis C test is recommended or should be considered"
    },
    {
      "code" : "HIV.D.DE398",
      "display" : "Syphilis test required",
      "definition" : "Syphilis test is required"
    },
    {
      "code" : "HIV.D.DE399",
      "display" : "Monitoring examinations",
      "definition" : "Name of examinations, test and results for any relevant investigations carried out for client"
    },
    {
      "code" : "HIV.D.DE400",
      "display" : "Haemoglobin (Hb)",
      "definition" : "Provider ordered a Haemoglobin (Hb) test, number in g/dL test"
    },
    {
      "code" : "HIV.D.DE401",
      "display" : "Pregnancy test",
      "definition" : "Provider ordered a pregnancy test for client"
    },
    {
      "code" : "HIV.D.DE402",
      "display" : "Syphilis test",
      "definition" : "Provider ordered a syphilis test"
    },
    {
      "code" : "HIV.D.DE403",
      "display" : "Chest X-ray (CXR)",
      "definition" : "Provider ordered a chest X-ray (CXR)"
    },
    {
      "code" : "HIV.D.DE404",
      "display" : "Sputum or culture for TB",
      "definition" : "Provider ordered sputum or culture for TB"
    },
    {
      "code" : "HIV.D.DE405",
      "display" : "HBsAg test (HBV)",
      "definition" : "Provider ordered an HBsAg test (HBV) test"
    },
    {
      "code" : "HIV.D.DE406",
      "display" : "HIV viral load test ordered",
      "definition" : "Provider ordered an HIV viral load test"
    },
    {
      "code" : "HIV.D.DE407",
      "display" : "HIV viral load test scheduled",
      "definition" : "Scheduled an HIV viral load test with client"
    },
    {
      "code" : "HIV.D.DE408",
      "display" : "CD4 count ordered",
      "definition" : "Provider ordered a CD4 cell count"
    },
    {
      "code" : "HIV.D.DE409",
      "display" : "CD4 count test scheduled",
      "definition" : "Scheduled a CD4 test with client"
    },
    {
      "code" : "HIV.D.DE410",
      "display" : "Cryptococcal antigen test",
      "definition" : "Provider ordered a cryptococcal antigen test"
    },
    {
      "code" : "HIV.D.DE411",
      "display" : "Histoplasmosis antigen test",
      "definition" : "Provider ordered a histoplasmosis antigen test"
    },
    {
      "code" : "HIV.D.DE412",
      "display" : "Cervical cancer screening scheduled",
      "definition" : "Scheduled cervical cancer screening with client"
    },
    {
      "code" : "HIV.D.DE413",
      "display" : "Date of scheduled monitoring examination",
      "definition" : "Date of scheduled monitoring examination"
    },
    {
      "code" : "HIV.D.DE414",
      "display" : "Hepatitis C test ordered",
      "definition" : "Hepatitis C test has been ordered"
    },
    {
      "code" : "HIV.D.DE415",
      "display" : "Syphilis test ordered",
      "definition" : "Syphilis test has been ordered"
    },
    {
      "code" : "HIV.D.DE416",
      "display" : "Received viral load test results",
      "definition" : "Client received results from viral load test"
    },
    {
      "code" : "HIV.D.DE417",
      "display" : "Date viral load test results received by client",
      "definition" : "The date on which the client received results from a viral load test"
    },
    {
      "code" : "HIV.D.DE418",
      "display" : "Reason for ARV drug regimen substitution",
      "definition" : "Reason why a substitution was made to the antiretroviral (ARV) drug regimen"
    },
    {
      "code" : "HIV.D.DE419",
      "display" : "Toxicity/side effects",
      "definition" : "A substitution was made to the regimen because of toxicity/side effects"
    },
    {
      "code" : "HIV.D.DE420",
      "display" : "Drug-drug interaction",
      "definition" : "A substitution was made to the regimen because of a drug-drug interaction"
    },
    {
      "code" : "HIV.D.DE421",
      "display" : "Pregnancy",
      "definition" : "A substitution was made to the regimen because of pregnancy"
    },
    {
      "code" : "HIV.D.DE422",
      "display" : "New TB",
      "definition" : "A substitution was made to the regimen because of new tuberculosis (TB)"
    },
    {
      "code" : "HIV.D.DE423",
      "display" : "New drug available",
      "definition" : "A substitution was made to the regimen because a new drug was available"
    },
    {
      "code" : "HIV.D.DE424",
      "display" : "Drug out of stock",
      "definition" : "A substitution was made to the regimen because drug was out of stock"
    },
    {
      "code" : "HIV.D.DE425",
      "display" : "Other reason for regimen substitution",
      "definition" : "A substitution was made for another reason"
    },
    {
      "code" : "HIV.D.DE426",
      "display" : "Other reason for regimen substitution (specify)",
      "definition" : "A substitution was made for another reason (specify)"
    },
    {
      "code" : "HIV.D.DE427",
      "display" : "Switch to second-line ART regimen recommended",
      "definition" : "A switch to second-line ART regimen is recommended"
    },
    {
      "code" : "HIV.D.DE428",
      "display" : "Switch to third-line ART regimen recommended",
      "definition" : "A switch to third-line ART regimen is recommended"
    },
    {
      "code" : "HIV.D.DE429",
      "display" : "Regimen switch made",
      "definition" : "Provider has made a regimen switch"
    },
    {
      "code" : "HIV.D.DE430",
      "display" : "Reason for regimen switch",
      "definition" : "Reason why a switch to a second- or third-line regimen was made"
    },
    {
      "code" : "HIV.D.DE431",
      "display" : "Clinical treatment failure",
      "definition" : "A switch was made to the regimen because of clinical treatment failure"
    },
    {
      "code" : "HIV.D.DE432",
      "display" : "Immunological failure",
      "definition" : "A switch was made to the regimen because of immunological failure"
    },
    {
      "code" : "HIV.D.DE433",
      "display" : "Virological failure",
      "definition" : "A switch was made to the regimen because of virological failure"
    },
    {
      "code" : "HIV.D.DE434",
      "display" : "Other",
      "definition" : "A switch was made to the regimen for another reason"
    },
    {
      "code" : "HIV.D.DE435",
      "display" : "Other (specify)",
      "definition" : "A switch was made to the regimen for another reason (specify)"
    },
    {
      "code" : "HIV.D.DE436",
      "display" : "Regimen substitution recommended",
      "definition" : "A drug substitution is recommended"
    },
    {
      "code" : "HIV.D.DE437",
      "display" : "Dose adjustment recommended",
      "definition" : "A dosage change is recommended"
    },
    {
      "code" : "HIV.D.DE438",
      "display" : "Regimen substitution made",
      "definition" : "Provider has made a regimen substitution"
    },
    {
      "code" : "HIV.D.DE439",
      "display" : "Co-trimoxazole prophylaxis start date",
      "definition" : "Date co-trimoxazole prophylaxis prescribed to client"
    },
    {
      "code" : "HIV.D.DE440",
      "display" : "Co-trimoxazole prophylaxis completion date",
      "definition" : "Completion date of co-trimoxazole prophylaxis prescribed to client"
    },
    {
      "code" : "HIV.D.DE441",
      "display" : "Co-trimoxazole prophylaxis dosage",
      "definition" : "Dose of co-trimoxazole prophylaxis prescribed to client"
    },
    {
      "code" : "HIV.D.DE442",
      "display" : "Co-trimoxazole prophylaxis number of days prescribed",
      "definition" : "Number of days of co-trimoxazole prophylaxis prescribed to client"
    },
    {
      "code" : "HIV.D.DE443",
      "display" : "Suspicion of treatment failure or interruption",
      "definition" : "Client has been on ART, but has stopped taking it or a treatment failure is suspected"
    },
    {
      "code" : "HIV.D.DE444",
      "display" : "ART regimen prescribed",
      "definition" : "INCLUDE VALUE SETS OF REGIMENS"
    },
    {
      "code" : "HIV.D.DE445",
      "display" : "Antiretroviral toxicity",
      "definition" : "Client is experiencing antiretroviral drug (ARV) toxicity"
    },
    {
      "code" : "HIV.D.DE446",
      "display" : "Coinfection status at ART start",
      "definition" : "Clients status of coinfections at the time when ART was initiated"
    },
    {
      "code" : "HIV.D.DE447",
      "display" : "Hepatitis B",
      "definition" : "Client was hepatitis B positive at the start of ART"
    },
    {
      "code" : "HIV.D.DE448",
      "display" : "Hepatitis C",
      "definition" : "Client was hepatitis C positive at the start of ART"
    },
    {
      "code" : "HIV.D.DE449",
      "display" : "Pregnant and breastfeeding status at ART start",
      "definition" : "ART status of women to prevent mother-to-child transmission"
    },
    {
      "code" : "HIV.D.DE450",
      "display" : "Pregnant at ART start",
      "definition" : "Client was pregnant when ART was initiated"
    },
    {
      "code" : "HIV.D.DE451",
      "display" : "Postpartum at ART start",
      "definition" : "Client was postpartum when ART was initiated"
    },
    {
      "code" : "HIV.D.DE452",
      "display" : "ART start at labour and delivery",
      "definition" : "Client initiated ART at labour and delivery"
    },
    {
      "code" : "HIV.D.DE453",
      "display" : "Breastfeeding at ART start",
      "definition" : "Client was breastfeeding when ART was initiated"
    },
    {
      "code" : "HIV.D.DE454",
      "display" : "Delivery date of infant",
      "definition" : "Date of delivery/birth of infant if breastfeeding at ART start"
    },
    {
      "code" : "HIV.D.DE455",
      "display" : "Serodiscordant partner at ART start",
      "definition" : "Client living with HIV was in an ongoing sexual relationship with an HIV-negative partner when ART was started"
    },
    {
      "code" : "HIV.D.DE456",
      "display" : "Regimen start date",
      "definition" : "The date on which the client started taking the current ART regimen"
    },
    {
      "code" : "HIV.D.DE457",
      "display" : "Medications prescribed",
      "definition" : "Name or regimen code of all other medications prescribed during the visit"
    },
    {
      "code" : "HIV.D.DE458",
      "display" : "Date medications prescribed",
      "definition" : "Date the medications were prescribed"
    },
    {
      "code" : "HIV.D.DE459",
      "display" : "Dose of medications prescribed",
      "definition" : "Number of doses (quantity taken at a single point in time) of drugs prescribed/dispensed"
    },
    {
      "code" : "HIV.D.DE460",
      "display" : "Number of days medications prescribed",
      "definition" : "Number of days supply of each medication or regimen prescribed during the visit"
    },
    {
      "code" : "HIV.D.DE461",
      "display" : "Medications dispensed",
      "definition" : "Any other medications that were dispensed to client, including preventive treatment"
    },
    {
      "code" : "HIV.D.DE462",
      "display" : "Number of days of medications dispensed",
      "definition" : "Number of days supply of each medication or regimen dispensed during the visit"
    },
    {
      "code" : "HIV.D.DE463",
      "display" : "Dosage",
      "definition" : "Prescribed dosage of the medication"
    },
    {
      "code" : "HIV.D.DE464",
      "display" : "Frequency",
      "definition" : "Prescribed frequency for taking the medication"
    },
    {
      "code" : "HIV.D.DE465",
      "display" : "Adherence counselling provided",
      "definition" : "Counselling was carried out during visit"
    },
    {
      "code" : "HIV.D.DE466",
      "display" : "Type of treatment-limiting toxicity",
      "definition" : "Type of treatment-limiting toxicity experienced by client. Treatment-limiting toxicity is defined as a serious adverse drug reaction that results in drug discontinuation or substitution. In addition, any reaction that leads to treatment interruption or requires changing the drug or regimen because of an adverse drug reaction is also considered a serious adverse drug reaction."
    },
    {
      "code" : "HIV.D.DE467",
      "display" : "Gastrointestinal",
      "definition" : "Treatment-limiting toxicity due to GI issues (nausea, diarrhoea, abdominal pain, vomiting)"
    },
    {
      "code" : "HIV.D.DE468",
      "display" : "Skin issues",
      "definition" : "Treatment-limiting toxicity due to skin issues (rash, hypersensitivity reaction)"
    },
    {
      "code" : "HIV.D.DE469",
      "display" : "Peripheral neuropathy",
      "definition" : "Treatment-limiting toxicity due to peripheral neuropathy (burning/numbness/ tingling)"
    },
    {
      "code" : "HIV.D.DE470",
      "display" : "Central nervous system symptoms",
      "definition" : "Treatment-limiting toxicity due to central nervous system symptoms (dizzy, anxiety, nightmare, depression, seizures)"
    },
    {
      "code" : "HIV.D.DE471",
      "display" : "Weight gain",
      "definition" : "Treatment-limiting toxicity due to weight gain"
    },
    {
      "code" : "HIV.D.DE472",
      "display" : "Hepatic dysfunction",
      "definition" : "Treatment-limiting toxicity due to hepatic dysfunction (jaundice)"
    },
    {
      "code" : "HIV.D.DE473",
      "display" : "Haematological disorders",
      "definition" : "Treatment-limiting toxicity due to haematological (anaemia, neutropenia) disorders"
    },
    {
      "code" : "HIV.D.DE474",
      "display" : "Fatigue",
      "definition" : "Treatment-limiting toxicity due to fatigue"
    },
    {
      "code" : "HIV.D.DE475",
      "display" : "Headache",
      "definition" : "Treatment-limiting toxicity due to headache"
    },
    {
      "code" : "HIV.D.DE476",
      "display" : "Bone dysfunction",
      "definition" : "Treatment-limiting toxicity due to bone dysfunction (fractures, osteopenia)"
    },
    {
      "code" : "HIV.D.DE477",
      "display" : "Metabolic symptoms",
      "definition" : "Treatment-limiting toxicity due to metabolic symptoms (body fat changes, hyperglycaemia, dyslipidaemia)"
    },
    {
      "code" : "HIV.D.DE478",
      "display" : "Kidney dysfunction",
      "definition" : "Treatment-limiting toxicity due to kidney dysfunction (nephrolithiasis, renal insufficiency)"
    },
    {
      "code" : "HIV.D.DE479",
      "display" : "Unexpected adverse drug reaction",
      "definition" : "Client experienced an unexpected adverse drug reaction"
    },
    {
      "code" : "HIV.D.DE480",
      "display" : "Unexpected adverse drug reaction (specify)",
      "definition" : "Specify the type of unexpected adverse drug reaction the client experienced"
    },
    {
      "code" : "HIV.D.DE481",
      "display" : "Date(s) of substitution within first-line regimen",
      "definition" : "Date on which ARV drug regimen (one or more drugs) for client was changed within the first-line regimen (substitution)"
    },
    {
      "code" : "HIV.D.DE482",
      "display" : "Reason(s) for substitution within first-line regimen",
      "definition" : "Reason(s) why one ore more drugs in client's first-line ARV drug regimen was changed (substituted)"
    },
    {
      "code" : "HIV.D.DE483",
      "display" : "New antiretroviral regimen after substitution within first-line regimen",
      "definition" : "New antiretroviral (ARV) drugs after client changed regimen within the first-line regimen"
    },
    {
      "code" : "HIV.D.DE484",
      "display" : "Date of switch to second-line regimen",
      "definition" : "Date client was changed from a first-line to second-line ARV drug regimen (switch)"
    },
    {
      "code" : "HIV.D.DE485",
      "display" : "New regimen after switch to second-line regimen",
      "definition" : "New ART regimen after switch to second-line ART regimen"
    },
    {
      "code" : "HIV.D.DE486",
      "display" : "Reason for switch to second-line regimen",
      "definition" : "Reason why client was switched from first- to second-line ARV drug regimen (see 'Reason for regimen switch' for levels)"
    },
    {
      "code" : "HIV.D.DE487",
      "display" : "Date(s) of substitution within second-line regimen",
      "definition" : "Date on which ARV drug regimen for client was changed within the second-line regimen (substitution)"
    },
    {
      "code" : "HIV.D.DE488",
      "display" : "Reason(s) for substitution within second-line regimen",
      "definition" : "Reason(s) why client changed drug regimen (within the second-line)"
    },
    {
      "code" : "HIV.D.DE489",
      "display" : "New regimen(s) after substitution within second-line regimen",
      "definition" : "New ARV drugs after client changed regimen within the second- line regimen"
    },
    {
      "code" : "HIV.D.DE490",
      "display" : "Date of switch to third-line regimen",
      "definition" : "Date client was changed from a second- to third-line ARV drug regimen (switch)"
    },
    {
      "code" : "HIV.D.DE491",
      "display" : "New regimen after switch to third-line regimen",
      "definition" : "New ART regimen after switch to third-line ART regimen"
    },
    {
      "code" : "HIV.D.DE492",
      "display" : "Reason for switch to third-line regimen",
      "definition" : "Reason why client was switched from second- to third-line ARV drug regimen (see 'Reason for regimen switch' for levels)"
    },
    {
      "code" : "HIV.D.DE493",
      "display" : "Date(s) of substitution within third-line regimen",
      "definition" : "Date on which ARV drug regimen for client was changed within the third-line (substitution)"
    },
    {
      "code" : "HIV.D.DE494",
      "display" : "Reason(s) for substitution within third-line regimen",
      "definition" : "Reason(s) why client changed drug regimen (within the third-line)"
    },
    {
      "code" : "HIV.D.DE495",
      "display" : "New regimen(s) after substitution within third-line regimen",
      "definition" : "New ARV drugs after client changed regimen within the third-line regimen"
    },
    {
      "code" : "HIV.D.DE496",
      "display" : "Enhanced adherence counselling provided",
      "definition" : "Enhanced adherence counselling was provided to the client during the visit"
    },
    {
      "code" : "HIV.D.DE497",
      "display" : "First enhanced adherence counselling session completed",
      "definition" : "A first enhanced adherence counselling was provided to the client during the visit"
    },
    {
      "code" : "HIV.D.DE498",
      "display" : "Date of first enhanced adherence counselling session completed",
      "definition" : "The date on which the first enhanced adherence counselling was provided to the client"
    },
    {
      "code" : "HIV.D.DE499",
      "display" : "Second enhanced adherence counselling session completed",
      "definition" : "A second enhanced adherence counselling was provided to the client during the visit"
    },
    {
      "code" : "HIV.D.DE500",
      "display" : "Date of second enhanced adherence counselling session completed",
      "definition" : "The date on which the second enhanced adherence counselling was provided to the client"
    },
    {
      "code" : "HIV.D.DE501",
      "display" : "Third enhanced adherence counselling session completed",
      "definition" : "A third enhanced adherence counselling was provided to the client during the visit"
    },
    {
      "code" : "HIV.D.DE502",
      "display" : "Date of third enhanced adherence counselling session completed",
      "definition" : "The date on which the third enhanced adherence counselling was provided to the client"
    },
    {
      "code" : "HIV.D.DE503",
      "display" : "Name of treatment supporter",
      "definition" : "Full name of person providing support to client for adherence, care, treatment and other needs (e.g. ARV pick-up if ill)"
    },
    {
      "code" : "HIV.D.DE504",
      "display" : "Address of treatment supporter",
      "definition" : "Full address or description of home of treatment supporter"
    },
    {
      "code" : "HIV.D.DE505",
      "display" : "Telephone number of treatment supporter",
      "definition" : "Telephone number if available, or else telephone number of neighbour/friend"
    },
    {
      "code" : "HIV.D.DE506",
      "display" : "Home-based care provider",
      "definition" : "Name of individual or organization that provides home-based care to client"
    },
    {
      "code" : "HIV.D.DE507",
      "display" : "Counselling provided on diagnoses",
      "definition" : "Counselling provided on diagnoses"
    },
    {
      "code" : "HIV.D.DE508",
      "display" : "Hepatitis B positive counselling conducted",
      "definition" : "Whether counselling was provided to a client who has been diagnosed with hepatitis B"
    },
    {
      "code" : "HIV.D.DE509",
      "display" : "Hepatitis C positive counselling conducted",
      "definition" : "Whether counselling was provided to a client who has been diagnosed with hepatitis C"
    },
    {
      "code" : "HIV.D.DE510",
      "display" : "Syphilis counselling and treatment",
      "definition" : "Whether counselling and treatment was provided to a client who has been diagnosed with syphilis"
    },
    {
      "code" : "HIV.D.DE511",
      "display" : "Syphilis counselling, treatment and further testing",
      "definition" : "Whether counselling and treatment was provided to a client who has been diagnosed with syphilis. Additional testing (RPR test) recommended."
    },
    {
      "code" : "HIV.D.DE512",
      "display" : "Accepted partner services",
      "definition" : "Client accepted offer for partner services"
    },
    {
      "code" : "HIV.D.DE513",
      "display" : "HIV testing for partners and biological children",
      "definition" : "Offer voluntary testing for all partners and biological children of positive cases (includes partner services and index case testing), as well as partners and social contacts of people from key populations, where appropriate"
    },
    {
      "code" : "HIV.D.DE514",
      "display" : "HIV status of family member",
      "definition" : "HIV status of each family member at time of patient's enrolment, including partner (for mothers)"
    },
    {
      "code" : "HIV.D.DE515",
      "display" : "Unique ID of family member",
      "definition" : "Unique ID number of each family member if enrolled in HIV care according to national guidelines (see unique ID number)"
    },
    {
      "code" : "HIV.D.DE516",
      "display" : "Date of death of family member",
      "definition" : "Date of death for each family member as appropriate"
    },
    {
      "code" : "HIV.D.DE517",
      "display" : "Offered voluntary partner services",
      "definition" : "Whether the client was offered voluntary partner services or family services"
    },
    {
      "code" : "HIV.D.DE518",
      "display" : "Provided support for disclosure and partner services",
      "definition" : "Offer or refer for support for disclosure and partner services"
    },
    {
      "code" : "HIV.D.DE519",
      "display" : "Other support services",
      "definition" : "Offer or refer for other support services"
    },
    {
      "code" : "HIV.D.DE520",
      "display" : "Mental health services",
      "definition" : "Offer or refer for mental health services"
    },
    {
      "code" : "HIV.D.DE521",
      "display" : "Psychosocial counselling, support and treatment adherence counselling",
      "definition" : "Offer or refer for psychosocial counselling, support and treatment adherence counselling"
    },
    {
      "code" : "HIV.D.DE522",
      "display" : "Legal and social services",
      "definition" : "Offer or refer for legal and social services"
    },
    {
      "code" : "HIV.D.DE523",
      "display" : "Services for responding to violence against women",
      "definition" : "Offer or refer for services for responding to violence against women, including first-line support and psychosocial support, post-rape care and other support services including shelters, legal services and women and child protection services"
    },
    {
      "code" : "HIV.D.DE524",
      "display" : "Date/time of follow-up appointment",
      "definition" : "Date the client is to return for monitoring, re-supply or any other reason"
    },
    {
      "code" : "HIV.D.DE525",
      "display" : "Type of follow-up appointment",
      "definition" : "Whether the visit will be clinical only, ARV drug pick-up or other. Client may have multiple follow-ups scheduled."
    },
    {
      "code" : "HIV.D.DE526",
      "display" : "Clinical visit",
      "definition" : "Appointment for clinical care by a provider"
    },
    {
      "code" : "HIV.D.DE527",
      "display" : "Antiretroviral drug pick up",
      "definition" : "Appointment for a drug pick up"
    },
    {
      "code" : "HIV.D.DE528",
      "display" : "Post-treatment follow-up visit for cervical precancer lesions or invasive cervical cancer",
      "definition" : "Appointment for a post-treatment follow-up visit for cervical precancer lesions or invasive cervical cancer"
    },
    {
      "code" : "HIV.D.DE529",
      "display" : "Other",
      "definition" : "Other reason for the follow-up appointment"
    },
    {
      "code" : "HIV.D.DE530",
      "display" : "Other (specify)",
      "definition" : "Other reason for the follow-up appointment (specify)"
    },
    {
      "code" : "HIV.D.DE531",
      "display" : "Follow-up test recommended date",
      "definition" : "A test or screening recommended for the client's care plan at a future date"
    },
    {
      "code" : "HIV.D.DE532",
      "display" : "Reason blood pressure reading not done",
      "definition" : "Reason why test was not performed"
    },
    {
      "code" : "HIV.D.DE533",
      "display" : "BP cuff (sphygmomanometer) not available",
      "definition" : "Blood pressure cuff is not available"
    },
    {
      "code" : "HIV.D.DE534",
      "display" : "BP cuff (sphygmomanometer) is broken",
      "definition" : "Blood pressure cuff is broken"
    },
    {
      "code" : "HIV.D.DE535",
      "display" : "Other",
      "definition" : "Other reason blood pressure can not be taken"
    },
    {
      "code" : "HIV.D.DE536",
      "display" : "Other (specify)",
      "definition" : "Other reason blood pressure can not be taken (specify)"
    },
    {
      "code" : "HIV.D.DE537",
      "display" : "Current medications",
      "definition" : "List of all of the medications the client is currently taking"
    },
    {
      "code" : "HIV.D.DE538",
      "display" : "No medications",
      "definition" : "The client is currently not on any medications"
    },
    {
      "code" : "HIV.D.DE539",
      "display" : "Don't know of any current medications",
      "definition" : "The client does not know if she is on any medications"
    },
    {
      "code" : "HIV.D.DE540",
      "display" : "Analgesic",
      "definition" : "Analgesic medication (painkiller)"
    },
    {
      "code" : "HIV.D.DE541",
      "display" : "Antacids",
      "definition" : "Antacids"
    },
    {
      "code" : "HIV.D.DE542",
      "display" : "Antibiotics (broad-spectrum)",
      "definition" : "Client is currently taking broad-spectrum antibiotics"
    },
    {
      "code" : "HIV.D.DE543",
      "display" : "Anticonvulsive",
      "definition" : "Anticonvulsive medication"
    },
    {
      "code" : "HIV.D.DE544",
      "display" : "Antidiabetic",
      "definition" : "Antidiabetic medication"
    },
    {
      "code" : "HIV.D.DE545",
      "display" : "Antifungals",
      "definition" : "Client is currently taking antifungals"
    },
    {
      "code" : "HIV.D.DE546",
      "display" : "Antihelmintic",
      "definition" : "Antihelmintic or antiparasitic medication"
    },
    {
      "code" : "HIV.D.DE547",
      "display" : "Antihypertensive",
      "definition" : "Antihypertensive medication"
    },
    {
      "code" : "HIV.D.DE548",
      "display" : "Antimalarials",
      "definition" : "Antimalarial medication"
    },
    {
      "code" : "HIV.D.DE549",
      "display" : "Antiretrovirals (ARVs)",
      "definition" : "Antiretrovirals (ARVs)"
    },
    {
      "code" : "HIV.D.DE550",
      "display" : "Antiparasitics",
      "definition" : "Client is currently taking antiparasitics"
    },
    {
      "code" : "HIV.D.DE551",
      "display" : "Antivirals",
      "definition" : "Antiviral medication"
    },
    {
      "code" : "HIV.D.DE552",
      "display" : "Buprenorphine",
      "definition" : "Opioid substitution to treat opioid dependence"
    },
    {
      "code" : "HIV.D.DE553",
      "display" : "Co-trimoxazole preventive therapy (CPT)",
      "definition" : "Combination of two antimicrobial drugs (sulfamethoxazole and trimethoprim) that covers a variety of bacterial, fungal and protozoan infections"
    },
    {
      "code" : "HIV.D.DE554",
      "display" : "Hormonal family planning method",
      "definition" : "Hormonal family planning method"
    },
    {
      "code" : "HIV.D.DE555",
      "display" : "Methadone",
      "definition" : "Opioid substitution to treat opioid dependence"
    },
    {
      "code" : "HIV.D.DE556",
      "display" : "PrEP to prevent HIV",
      "definition" : "Pre-exposure prophylaxis (PrEP) medication for preventing the acquisition of HIV"
    },
    {
      "code" : "HIV.D.DE557",
      "display" : "Other antibiotics",
      "definition" : "Other antibiotics not listed above"
    },
    {
      "code" : "HIV.D.DE558",
      "display" : "Other medications",
      "definition" : "Other medications or supplements that are not listed above"
    },
    {
      "code" : "HIV.D.DE559",
      "display" : "Other medications (specify)",
      "definition" : "Other medications or supplements that are not listed above (specify)"
    },
    {
      "code" : "HIV.D.DE560",
      "display" : "Allergies",
      "definition" : "Does the client have any allergies?"
    },
    {
      "code" : "HIV.D.DE561",
      "display" : "No known allergies",
      "definition" : "Client does not have any known allergies"
    },
    {
      "code" : "HIV.D.DE562",
      "display" : "Don't know of any allergies",
      "definition" : "Client does not know whether or not she has allergies"
    },
    {
      "code" : "HIV.D.DE563",
      "display" : "Albendazole",
      "definition" : "Allergy to albendazole"
    },
    {
      "code" : "HIV.D.DE564",
      "display" : "Malaria medication (sulfadoxine-pyrimethamine)",
      "definition" : "Allergy to malaria medication (sulfadoxine-pyrimethamine)"
    },
    {
      "code" : "HIV.D.DE565",
      "display" : "Penicillin",
      "definition" : "Allergy to penicillin"
    },
    {
      "code" : "HIV.D.DE566",
      "display" : "Tenofovir disoproxil fumarate (TDF)",
      "definition" : "Allergy to pre-exposure prophylaxis (PrEP) tenofovir disoproxil fumarate (TDF)"
    },
    {
      "code" : "HIV.D.DE567",
      "display" : "Other allergies",
      "definition" : "Client has other allergies not listed here"
    },
    {
      "code" : "HIV.D.DE568",
      "display" : "Other allergies (specify)",
      "definition" : "Client has other allergies not listed here (specify)"
    },
    {
      "code" : "HIV.D.DE569",
      "display" : "Family planning method used",
      "definition" : "Method the client reports currently using at intake"
    },
    {
      "code" : "HIV.D.DE570",
      "display" : "Copper-bearing intrauterine device (Cu-IUD)",
      "definition" : "A copper-bearing intrauterine device is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE571",
      "display" : "Levonorgestrel intrauterine device (LNG-IUD)",
      "definition" : "A levonorgestrel intrauterine device (hormone-releasing intrauterine contraceptive device) is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE572",
      "display" : "Etonogestrel (ETG) one-rod implant",
      "definition" : "An etonogestrel one-rod implant is being used"
    },
    {
      "code" : "HIV.D.DE573",
      "display" : "Levonorgestrel (LNG) two-rod implant",
      "definition" : "A levonorgestrel two-rod implant is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE574",
      "display" : "DMPA-IM",
      "definition" : "Injectable depot medroxyprogesterone acetate (DMPA), administered intramuscularly, is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE575",
      "display" : "DMPA-SC",
      "definition" : "Injectable depot medroxyprogesterone acetate (DMPA), administered subcutaneously is being used"
    },
    {
      "code" : "HIV.D.DE576",
      "display" : "NET-EN norethisterone enanthate",
      "definition" : "Injectable norethisterone enanthate (NET-EN) is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE577",
      "display" : "Progestogen-only pills (POP)",
      "definition" : "Progestogen-only pills (POP) are being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE578",
      "display" : "Combined oral contraceptives (COCs)",
      "definition" : "Combined oral contraceptives (COCs) pills are being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE579",
      "display" : "Combined contraceptive patch",
      "definition" : "Transdermal combined contraceptive patch is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE580",
      "display" : "Combined contraceptive vaginal ring (CVR)",
      "definition" : "Combined contraceptive vaginal ring (CVR) is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE581",
      "display" : "Progesterone-releasing vaginal ring (PVR)",
      "definition" : "Progesterone-releasing vaginal ring (PVR) is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE582",
      "display" : "Lactational amenorrhea method (LAM)",
      "definition" : "Lactational amenorrhea method (LAM) is being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE583",
      "display" : "Emergency contraceptive pills (ECPs)",
      "definition" : "Client uses emergency contraceptive pills (ECPs)"
    },
    {
      "code" : "HIV.D.DE584",
      "display" : "Fertility awareness-based methods (FAB)",
      "definition" : "Client uses fertility awareness-based methods (FAB)"
    },
    {
      "code" : "HIV.D.DE585",
      "display" : "Male condoms",
      "definition" : "Male condoms are being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE586",
      "display" : "Female condoms",
      "definition" : "Female condoms are being used as a family planning method"
    },
    {
      "code" : "HIV.D.DE587",
      "display" : "Withdrawal",
      "definition" : "Client uses withdrawal method"
    },
    {
      "code" : "HIV.D.DE588",
      "display" : "Female relying on male method",
      "definition" : "The female client is relying on her male partner for contraceptive methods (e.g. male condoms, male sterilization, withdrawal)"
    },
    {
      "code" : "HIV.D.DE589",
      "display" : "Male relying on female method",
      "definition" : "The male client is relying on his female partner for contraceptive methods"
    },
    {
      "code" : "HIV.D.DE590",
      "display" : "Male sterilization",
      "definition" : "Male surgical sterilization (a vasectomy) is the family planning method used"
    },
    {
      "code" : "HIV.D.DE591",
      "display" : "Female sterilization",
      "definition" : "Female surgical sterilization procedure is the family planning method used"
    },
    {
      "code" : "HIV.D.DE592",
      "display" : "No method",
      "definition" : "Client is not using any family planning methods"
    },
    {
      "code" : "HIV.D.DE593",
      "display" : "Medication status",
      "definition" : "Current state of the client's taking of the medication"
    },
    {
      "code" : "HIV.D.DE594",
      "display" : "Currently taking",
      "definition" : "The medication is still being taken (active)"
    },
    {
      "code" : "HIV.D.DE595",
      "display" : "Completed",
      "definition" : "The medication is no longer being taken"
    },
    {
      "code" : "HIV.D.DE596",
      "display" : "Entered in error",
      "definition" : "Entered in error"
    },
    {
      "code" : "HIV.D.DE597",
      "display" : "Intended",
      "definition" : "The medication may be taken at some time in the future"
    },
    {
      "code" : "HIV.D.DE598",
      "display" : "Stopped",
      "definition" : "Actions implied by the statement have been permanently halted, before all of them occurred. This should not be used if the statement was entered in error."
    },
    {
      "code" : "HIV.D.DE599",
      "display" : "On hold",
      "definition" : "The client has temporarily stopped taking the medication, but is expected to continue again later. May also be called 'suspended'."
    },
    {
      "code" : "HIV.D.DE600",
      "display" : "Unknown",
      "definition" : "The state of the medication use is not currently known"
    },
    {
      "code" : "HIV.D.DE601",
      "display" : "Did not take",
      "definition" : "The client did not take the medication"
    },
    {
      "code" : "HIV.D.DE602",
      "display" : "Hepatitis B negative counselling conducted",
      "definition" : "Hepatitis B negative counselling conducted"
    },
    {
      "code" : "HIV.D.DE603",
      "display" : "Vaccine brand",
      "definition" : "The brand or trade name used to refer to the vaccine received"
    },
    {
      "code" : "HIV.D.DE604",
      "display" : "Vaccine type",
      "definition" : "Type of vaccine received (such as IPV, OPV)"
    },
    {
      "code" : "HIV.D.DE605",
      "display" : "Date and time of vaccination",
      "definition" : "Represents the visit/encounter date, which is the date and time when the vaccine was administered to the client"
    },
    {
      "code" : "HIV.D.DE606",
      "display" : "Vaccination location",
      "definition" : "The service delivery location where the vaccine adminstration occurred"
    },
    {
      "code" : "HIV.D.DE607",
      "display" : "Dose number",
      "definition" : "Vaccine dose number within series"
    },
    {
      "code" : "HIV.D.DE608",
      "display" : "Dose quantity",
      "definition" : "The quantity of vaccine product that was administered"
    },
    {
      "code" : "HIV.D.DE609",
      "display" : "Total doses in series",
      "definition" : "The recommended number of vaccine doses for immunity according to national protocol"
    },
    {
      "code" : "HIV.D.DE610",
      "display" : "Disease targeted",
      "definition" : "Vaccine preventable disease being targeted by vaccine administered"
    },
    {
      "code" : "HIV.D.DE611",
      "display" : "Hepatitis A",
      "definition" : "The client is receiving vaccination to prevent against hepatitis A"
    },
    {
      "code" : "HIV.D.DE612",
      "display" : "Hepatitis B",
      "definition" : "The client is receiving vaccination to prevent against hepatitis B"
    },
    {
      "code" : "HIV.D.DE613",
      "display" : "Tetanus",
      "definition" : "The client is receiving vaccination to prevent against tetanus"
    },
    {
      "code" : "HIV.D.DE614",
      "display" : "COVID-19",
      "definition" : "The client is receiving vaccination to prevent against COVID-19 due to SARS-CoV-2"
    },
    {
      "code" : "HIV.D.DE615",
      "display" : "Influenza due to influenza B virus",
      "definition" : "The client is receiving vaccination to prevent against influenza due to influenza B virus"
    },
    {
      "code" : "HIV.D.DE616",
      "display" : "Tuberculosis",
      "definition" : "The client is receiving vaccination to prevent against tuberculosis (e.g. BCG vaccine)"
    },
    {
      "code" : "HIV.D.DE617",
      "display" : "Acute poliomyelitis",
      "definition" : "The client is receiving vaccination to prevent against acute poliomyelitis (polio)"
    },
    {
      "code" : "HIV.D.DE618",
      "display" : "Measles",
      "definition" : "The client is receiving vaccination to prevent against measles"
    },
    {
      "code" : "HIV.D.DE619",
      "display" : "Diptheria",
      "definition" : "The client is receiving vaccination to prevent against diptheria"
    },
    {
      "code" : "HIV.D.DE620",
      "display" : "Rabies",
      "definition" : "The client is receiving vaccination to prevent against rabies"
    },
    {
      "code" : "HIV.D.DE621",
      "display" : "Cholera",
      "definition" : "The client is receiving vaccination to prevent against cholera"
    },
    {
      "code" : "HIV.D.DE622",
      "display" : "Mumps",
      "definition" : "The client is receiving vaccination to prevent against mumps"
    },
    {
      "code" : "HIV.D.DE623",
      "display" : "HPV infection",
      "definition" : "The client is receiving vaccination to prevent against human papilloma virus (HPV) infection"
    },
    {
      "code" : "HIV.D.DE624",
      "display" : "Haemophilus influenzae type B",
      "definition" : "The client is receiving vaccination to prevent against Haemophilus influenzae type B (Hib)"
    },
    {
      "code" : "HIV.D.DE625",
      "display" : "Varicella",
      "definition" : "The client is receiving vaccination to prevent against varicella"
    },
    {
      "code" : "HIV.D.DE626",
      "display" : "Dengue",
      "definition" : "The client is receiving vaccination to prevent against dengue"
    },
    {
      "code" : "HIV.D.DE627",
      "display" : "Yellow fever",
      "definition" : "The client is receiving vaccination to prevent against yellow fever"
    },
    {
      "code" : "HIV.D.DE628",
      "display" : "Japanese Encephalitis",
      "definition" : "The client is receiving vaccination to prevent against Japanese encephalitis"
    },
    {
      "code" : "HIV.D.DE629",
      "display" : "Rubella",
      "definition" : "The client is receiving vaccination to prevent against rubella"
    },
    {
      "code" : "HIV.D.DE630",
      "display" : "Pertussis",
      "definition" : "The client is receiving vaccination to prevent against pertussis"
    },
    {
      "code" : "HIV.D.DE631",
      "display" : "Enteritis due to rotavirus",
      "definition" : "The client is receiving vaccination to prevent against enteritis due to rotavirus"
    },
    {
      "code" : "HIV.D.DE632",
      "display" : "Pneumococcal disease",
      "definition" : "The client is receiving vaccination to prevent against pneumococcal disease"
    },
    {
      "code" : "HIV.D.DE633",
      "display" : "Meningococcal disease",
      "definition" : "The client is receiving vaccination to prevent against meningococcal disease"
    },
    {
      "code" : "HIV.D.DE634",
      "display" : "Tick-borne encephalitis",
      "definition" : "The client is receiving vaccination to prevent against tick-borne encephalitis"
    },
    {
      "code" : "HIV.D.DE635",
      "display" : "Typhoid",
      "definition" : "The client is receiving vaccination to prevent against typhoid"
    },
    {
      "code" : "HIV.D.DE636",
      "display" : "Reason immunization was not provided",
      "definition" : "Reason the vaccine dose was not given"
    },
    {
      "code" : "HIV.D.DE637",
      "display" : "Stock-out",
      "definition" : "Stock-out of vaccine"
    },
    {
      "code" : "HIV.D.DE638",
      "display" : "Client is ill",
      "definition" : "Client is ill"
    },
    {
      "code" : "HIV.D.DE639",
      "display" : "Client refused",
      "definition" : "Client refused vaccine"
    },
    {
      "code" : "HIV.D.DE640",
      "display" : "Allergy to vaccine",
      "definition" : "Client has an allergy to the vaccine"
    },
    {
      "code" : "HIV.D.DE641",
      "display" : "Other reason immunization not provided",
      "definition" : "Other reason why the immunization was not provided"
    },
    {
      "code" : "HIV.D.DE642",
      "display" : "Other reason immunization not provided (specify)",
      "definition" : "Other reason why the immunization was not provided (specify)"
    },
    {
      "code" : "HIV.D.DE643",
      "display" : "Malaria prophylaxis",
      "definition" : "Whether malaria prophylaxis was given"
    },
    {
      "code" : "HIV.D.DE644",
      "display" : "IPTp-SP dose number provided",
      "definition" : "IPTp-SP dose number that was provided"
    },
    {
      "code" : "HIV.D.DE645",
      "display" : "Date IPTp-SP dose provided",
      "definition" : "Date on which the IPTp-SP dose was provided"
    },
    {
      "code" : "HIV.D.DE646",
      "display" : "Reason malaria prophylaxis not provided",
      "definition" : "Reason why the treatment was not given"
    },
    {
      "code" : "HIV.D.DE647",
      "display" : "Client was referred",
      "definition" : "Client was referred to another provider/facility"
    },
    {
      "code" : "HIV.D.DE648",
      "display" : "Stock out",
      "definition" : "There was a stock out of malaria prophylaxis"
    },
    {
      "code" : "HIV.D.DE649",
      "display" : "Expired",
      "definition" : "Malaria prophylaxis in stock was expired"
    },
    {
      "code" : "HIV.D.DE650",
      "display" : "Other reason not provided",
      "definition" : "Other reason why the prophylaxis was not provided"
    },
    {
      "code" : "HIV.D.DE651",
      "display" : "Other reason not provided (specify)",
      "definition" : "Other reason why the prophylaxis was not provided"
    },
    {
      "code" : "HIV.D.DE652",
      "display" : ">28 days since last missed appointment",
      "definition" : "More than 28 days have passed since client's last missed appointment"
    },
    {
      "code" : "HIV.D.DE653",
      "display" : "AIDS-related death",
      "definition" : "Death of client was AIDS-related"
    },
    {
      "code" : "HIV.D.DE654",
      "display" : "Date of first AIDS diagnosis",
      "definition" : "Date of client's first AIDS diagnosis"
    },
    {
      "code" : "HIV.D.DE655",
      "display" : "Age at final HPV vaccination dose received",
      "definition" : "Client's age at date received final HPV vaccination dose"
    },
    {
      "code" : "HIV.D.DE656",
      "display" : "Date of cervical cancer screening test",
      "definition" : "Date of cervical cancer screening test"
    },
    {
      "code" : "HIV.D.DE657",
      "display" : "Lifetime screening test number",
      "definition" : "Client's lifetime number of screenings for cervical cancer"
    },
    {
      "code" : "HIV.D.DE658",
      "display" : "Cervical cancer primary screening test type",
      "definition" : "Type of cervical cancer screening test used in primary screening"
    },
    {
      "code" : "HIV.D.DE659",
      "display" : "HPV-DNA",
      "definition" : "Screened for cervical cancer using HPV-DNA test"
    },
    {
      "code" : "HIV.D.DE660",
      "display" : "VIA",
      "definition" : "Screened for cervical cancer using visual inspection with acetic acid (VIA)"
    },
    {
      "code" : "HIV.D.DE661",
      "display" : "Cervical cytology",
      "definition" : "Screened for cervical cancer using cervical cytology"
    },
    {
      "code" : "HIV.D.DE662",
      "display" : "Other",
      "definition" : "Screened for cervical cancer using other method"
    },
    {
      "code" : "HIV.D.DE663",
      "display" : "Other (specify)",
      "definition" : "Screened for cervical cancer using other method (specify)"
    },
    {
      "code" : "HIV.D.DE664",
      "display" : "HPV-DNA cervical cancer screening test result",
      "definition" : "HPV-DNA cervical cancer screening test result"
    },
    {
      "code" : "HIV.D.DE665",
      "display" : "Negative",
      "definition" : "HPV-DNA screening test was negative"
    },
    {
      "code" : "HIV.D.DE666",
      "display" : "Positive",
      "definition" : "HPV-DNA screening test was positive"
    },
    {
      "code" : "HIV.D.DE667",
      "display" : "Invalid",
      "definition" : "HPV-DNA screening test was invalid"
    },
    {
      "code" : "HIV.D.DE668",
      "display" : "VIA cervical cancer screening test result",
      "definition" : "Screening test result for VIA"
    },
    {
      "code" : "HIV.D.DE669",
      "display" : "Negative",
      "definition" : "Screening result is negative"
    },
    {
      "code" : "HIV.D.DE670",
      "display" : "Positive",
      "definition" : "Screening result is positive"
    },
    {
      "code" : "HIV.D.DE671",
      "display" : "Suspected cancer",
      "definition" : "Screening result is suspected cancer"
    },
    {
      "code" : "HIV.D.DE672",
      "display" : "Invalid",
      "definition" : "Screening result is invalid"
    },
    {
      "code" : "HIV.D.DE673",
      "display" : "Cervical cytology screening test result",
      "definition" : "Screening result for cervical cytology"
    },
    {
      "code" : "HIV.D.DE674",
      "display" : "NILM",
      "definition" : "Negative for Intraepithelial Lesion Malignancy (NILM)"
    },
    {
      "code" : "HIV.D.DE675",
      "display" : "ASCUS",
      "definition" : "Atypical squamous cells of undetermined significance (ASCUS)"
    },
    {
      "code" : "HIV.D.DE676",
      "display" : "LSIL",
      "definition" : "Low grade squamous intraepithelial lesion (LSIL)"
    },
    {
      "code" : "HIV.D.DE677",
      "display" : "HSIL",
      "definition" : "High grade squamous intraepithelial lesion (HSIL)"
    },
    {
      "code" : "HIV.D.DE678",
      "display" : "Cancer",
      "definition" : "Result was positive for cancer"
    },
    {
      "code" : "HIV.D.DE679",
      "display" : "Invalid/inadequate",
      "definition" : "Screening result was invalid or inadequate"
    },
    {
      "code" : "HIV.D.DE680",
      "display" : "Cervical cancer triage test date",
      "definition" : "Date of triage test for cervical cancer"
    },
    {
      "code" : "HIV.D.DE681",
      "display" : "Cervical cancer triage test type",
      "definition" : "Type of triage test for cervical cancer"
    },
    {
      "code" : "HIV.D.DE682",
      "display" : "VIA",
      "definition" : "Triage test for cervical cancer using visual inspection with acetic acid (VIA)"
    },
    {
      "code" : "HIV.D.DE683",
      "display" : "Colposcopy",
      "definition" : "Triage test for cervical cancer using colposcopy"
    },
    {
      "code" : "HIV.D.DE684",
      "display" : "Cervical cytology",
      "definition" : "Triage test for cervical cancer using cervical cytology"
    },
    {
      "code" : "HIV.D.DE685",
      "display" : "HPV16/18",
      "definition" : "Triage test for cervical cancer using test for HPV16/18"
    },
    {
      "code" : "HIV.D.DE686",
      "display" : "Other",
      "definition" : "Triage test for cervical cancer using another test"
    },
    {
      "code" : "HIV.D.DE687",
      "display" : "Other (specify)",
      "definition" : "Triage test for cervical cancer using another test (specify)"
    },
    {
      "code" : "HIV.D.DE688",
      "display" : "HPV16/18 test result",
      "definition" : "Test result from HPV16/18 test"
    },
    {
      "code" : "HIV.D.DE689",
      "display" : "Positive",
      "definition" : "Test is positive for HPV16/18"
    },
    {
      "code" : "HIV.D.DE690",
      "display" : "Negative",
      "definition" : "Test is negative for HPV16/18"
    },
    {
      "code" : "HIV.D.DE691",
      "display" : "Cervical cancer colposcopy result",
      "definition" : "Result of cervical cancer colposcopy"
    },
    {
      "code" : "HIV.D.DE692",
      "display" : "Normal colposcopic findings",
      "definition" : "Colposcopy has normal colposcopic findings"
    },
    {
      "code" : "HIV.D.DE693",
      "display" : "Abnormal colposcopic findings",
      "definition" : "Colposcopy has abnormal colposcopic findings"
    },
    {
      "code" : "HIV.D.DE694",
      "display" : "Suspicious for invasive cervical cancer",
      "definition" : "Colposcopy is suspicious for invasive cervical cancer"
    },
    {
      "code" : "HIV.D.DE695",
      "display" : "Miscellaneous findings",
      "definition" : "Colposcopy has miscellaneous findings"
    },
    {
      "code" : "HIV.D.DE696",
      "display" : "Inadequate",
      "definition" : "Colposcopy exam is inadequate"
    },
    {
      "code" : "HIV.D.DE697",
      "display" : "Cervical cancer histopathology result",
      "definition" : "Result of cervical cancer histopathology"
    },
    {
      "code" : "HIV.D.DE698",
      "display" : "Normal",
      "definition" : "Result of cervical cancer histopathology was normal"
    },
    {
      "code" : "HIV.D.DE699",
      "display" : "LSIL (inclusive of LSIL-CIN1)",
      "definition" : "Result of cervical cancer histopathology was low-grade squamous intraepithelial lesion (LSIL)"
    },
    {
      "code" : "HIV.D.DE700",
      "display" : "HSIL (inclusive of HSIL-CIN2 or HSIL-CIN3)",
      "definition" : "Result of cervical cancer histopathology was high-grade squamous intraepithelial lesion (HSIL)"
    },
    {
      "code" : "HIV.D.DE701",
      "display" : "Invasive cervical cancer",
      "definition" : "Result of cervical cancer histopathology is invasive cervical cancer"
    },
    {
      "code" : "HIV.D.DE702",
      "display" : "Date of additional cervical cancer triage test",
      "definition" : "Date of tertiary cervical cancer screening test"
    },
    {
      "code" : "HIV.D.DE703",
      "display" : "Additional cervical cancer triage test type (specify)",
      "definition" : "Additional cervical cancer triage test type (specify)"
    },
    {
      "code" : "HIV.D.DE704",
      "display" : "Additional cervical cancer triage test result (specify)",
      "definition" : "Additional cervical cancer triage test result (specify)"
    },
    {
      "code" : "HIV.D.DE705",
      "display" : "Date of diagnosis of cervical precancer lesions or invasive cervical cancer",
      "definition" : "Date of diagnosis of cervical precancer lesions or invasive cervical cancer"
    },
    {
      "code" : "HIV.D.DE706",
      "display" : "Cervical cancer screening outcome",
      "definition" : "Client's screening outcome for cervical cancer"
    },
    {
      "code" : "HIV.D.DE707",
      "display" : "Positive for cervical precancer lesions",
      "definition" : "Screening outcome for cervical precancer lesions is positive"
    },
    {
      "code" : "HIV.D.DE708",
      "display" : "Negative for cervical precancer lesions",
      "definition" : "Screening outcome for cervical precancer lesions is negative"
    },
    {
      "code" : "HIV.D.DE709",
      "display" : "Cervical cancer diagnosis",
      "definition" : "Type of cervical cancer diagnosis"
    },
    {
      "code" : "HIV.D.DE710",
      "display" : "Cervical precancer lesions",
      "definition" : "Client is diagnosed with cervical precancer lesions"
    },
    {
      "code" : "HIV.D.DE711",
      "display" : "Invasive cervical cancer",
      "definition" : "Client is diagnosed with invasive cervical cancer disease"
    },
    {
      "code" : "HIV.D.DE712",
      "display" : "Cervical cancer stage at diagnosis",
      "definition" : "Cervical cancer stage at diagnosis of cervical cancer"
    },
    {
      "code" : "HIV.D.DE713",
      "display" : "Stage 0",
      "definition" : "Stage 0 cervical cancer at diagnosis of cervical cancer"
    },
    {
      "code" : "HIV.D.DE714",
      "display" : "Stage I",
      "definition" : "Stage I cervical cancer at diagnosis of cervical cancer"
    },
    {
      "code" : "HIV.D.DE715",
      "display" : "Stage II",
      "definition" : "Stage II cervical cancer at diagnosis of cervical cancer"
    },
    {
      "code" : "HIV.D.DE716",
      "display" : "Stage III",
      "definition" : "Stage III cervical cancer at diagnosis of cervical cancer"
    },
    {
      "code" : "HIV.D.DE717",
      "display" : "Stage IV",
      "definition" : "Stage IV cervical cancer at diagnosis of cervical cancer"
    },
    {
      "code" : "HIV.D.DE718",
      "display" : "Date of treatment for cervical precancer lesions",
      "definition" : "Date of treatment for cervical precancer lesions"
    },
    {
      "code" : "HIV.D.DE719",
      "display" : "Treatment method for cervical precancer lesions",
      "definition" : "Treatment method for cervical precancer lesions"
    },
    {
      "code" : "HIV.D.DE720",
      "display" : "Cryotherapy",
      "definition" : "Treatment for cervical precancer lesions is cryotherapy"
    },
    {
      "code" : "HIV.D.DE721",
      "display" : "Thermal ablation",
      "definition" : "Treatment for cervical precancer lesions is Thermal ablation"
    },
    {
      "code" : "HIV.D.DE722",
      "display" : "Laser ablation",
      "definition" : "Treatment for cervical precancer lesions is Laser ablation"
    },
    {
      "code" : "HIV.D.DE723",
      "display" : "CKC",
      "definition" : "Treatment for cervical precancer lesions is Cold knife conization (CKC)"
    },
    {
      "code" : "HIV.D.DE724",
      "display" : "Laser cone biopsy",
      "definition" : "Treatment for cervical precancer lesions is Laser cone biopsy"
    },
    {
      "code" : "HIV.D.DE725",
      "display" : "LLETZ/LEEP",
      "definition" : "Treatment for cervical precancer lesions is large loop excision of the transformation zone (LLETZ)/loop electrosurgical excision procedure (LEEP)"
    },
    {
      "code" : "HIV.D.DE726",
      "display" : "Other",
      "definition" : "Treatment for cervical precancer lesions is not listed"
    },
    {
      "code" : "HIV.D.DE727",
      "display" : "Other (specify)",
      "definition" : "Treatment for cervical precancer lesions is not listed (specify)"
    },
    {
      "code" : "HIV.D.DE728",
      "display" : "Date of follow-up for treatment for cervical precancer lesions",
      "definition" : "Date of follow-up for treatment for cervical precancer lesions"
    },
    {
      "code" : "HIV.D.DE729",
      "display" : "Date of start of invasive cancer treatment",
      "definition" : "Date of start of invasive cancer treatment"
    },
    {
      "code" : "HIV.D.DE730",
      "display" : "Invasive cervical cancer treatment episode",
      "definition" : "Client's lifetime number of treatments for invasive cervical cancer"
    },
    {
      "code" : "HIV.D.DE731",
      "display" : "Invasive cervical cancer treatment method",
      "definition" : "Invasive cervical cancer treatment method"
    },
    {
      "code" : "HIV.D.DE732",
      "display" : "Conization",
      "definition" : "Invasive cervical cancer treatment method is a conization"
    },
    {
      "code" : "HIV.D.DE733",
      "display" : "Trachelectomy",
      "definition" : "Invasive cervical cancer treatment method is a trachelectomy"
    },
    {
      "code" : "HIV.D.DE734",
      "display" : "Hysterectomy",
      "definition" : "Invasive cervical cancer treatment method is a hysterectomy"
    },
    {
      "code" : "HIV.D.DE735",
      "display" : "Management of invasive cervical cancer",
      "definition" : "Invasive cervical cancer treatment method is management of invasive cervical cancer"
    },
    {
      "code" : "HIV.D.DE736",
      "display" : "Radiotherapy",
      "definition" : "Invasive cervical cancer treatment method is a radiotherapy"
    },
    {
      "code" : "HIV.D.DE737",
      "display" : "Chemotherapy",
      "definition" : "Invasive cervical cancer treatment method is a chemotherapy"
    },
    {
      "code" : "HIV.D.DE738",
      "display" : "Chemoradiation",
      "definition" : "Invasive cervical cancer treatment method is a chemoradiation"
    },
    {
      "code" : "HIV.D.DE739",
      "display" : "Other",
      "definition" : "Invasive cervical cancer treatment method is a not in list"
    },
    {
      "code" : "HIV.D.DE740",
      "display" : "Other (specify)",
      "definition" : "Invasive cervical cancer treatment method is a not in list (specify)"
    },
    {
      "code" : "HIV.D.DE741",
      "display" : "Treatment outcome",
      "definition" : "Treatment outcome from cervical pre-cancerous lesion treatment or invasive cancer treatment (specify)"
    },
    {
      "code" : "HIV.D.DE742",
      "display" : "Secondary/other cancers diagnosed",
      "definition" : "Secondary and other cancers that client is diagnosed with (specify)"
    },
    {
      "code" : "HIV.D.DE743",
      "display" : "Cancers at other sites (HPV- and non-HPV related)",
      "definition" : "Cancers at other sites that client has (specify)"
    },
    {
      "code" : "HIV.D.DE744",
      "display" : "Date of death",
      "definition" : "If deceased, the date that the client died"
    },
    {
      "code" : "HIV.D.DE745",
      "display" : "Cervical cancer screening interval amongst WLHIV",
      "definition" : "Country-specific interval between cancer screenings amongst women living with HIV (typically 3 or 5 years)"
    },
    {
      "code" : "HIV.D.DE746",
      "display" : "Entry point for facility-level testing",
      "definition" : "Specific point where testing is happening at a facility"
    },
    {
      "code" : "HIV.D.DE747",
      "display" : "Provider-initiated tested in a clinic or emergency facility",
      "definition" : "The client tested though provider-initiated HIV testing & counselling, which could be at an emergency facility"
    },
    {
      "code" : "HIV.D.DE748",
      "display" : "Antenatal care clinic",
      "definition" : "The client tested at an antenatal care clinic, including labour and delivery"
    },
    {
      "code" : "HIV.D.DE749",
      "display" : "Voluntary counselling and testing (within a health facility setting)",
      "definition" : "The client tested through voluntary counselling and testing (within a health facility setting)"
    },
    {
      "code" : "HIV.D.DE750",
      "display" : "Family planning clinic",
      "definition" : "The client tested at a family planning clinic"
    },
    {
      "code" : "HIV.D.DE751",
      "display" : "Other facility-level testing",
      "definition" : "The client tested at another type of facility"
    },
    {
      "code" : "HIV.D.DE752",
      "display" : "Tuberculosis (TB) clinic",
      "definition" : "The client tested at a TB clinic"
    },
    {
      "code" : "HIV.D.DE753",
      "display" : "Offer other clinical services",
      "definition" : "Other clinical services offered or referrals given to the client"
    },
    {
      "code" : "HIV.D.DE754",
      "display" : "Assessment and provision of vaccinations",
      "definition" : "Assessment and provision of vaccinations, such as for people from Key population member type, pregnant women and infants; and, where appropriate, tetanus vaccination for adolescent boys and men receiving VMMC"
    },
    {
      "code" : "HIV.D.DE755",
      "display" : "Hepatitis B (HBV) and hepatitis C virus (HCV) testing and treatment",
      "definition" : "Offer or refer for HBV and/or HCV testing and treatment"
    },
    {
      "code" : "HIV.D.DE756",
      "display" : "Co-trimoxazole chemoprophylaxis to prevent pneumocystis carinii pneumonia",
      "definition" : "Offer or refer for co-trimoxazole chemoprophylaxis to prevent pneumocystis carinii pneumonia"
    },
    {
      "code" : "HIV.D.DE757",
      "display" : "Intensified TB case finding and linkage to TB treatment",
      "definition" : "Offer or refer for intensified TB case finding and linkage to TB treatment"
    },
    {
      "code" : "HIV.D.DE758",
      "display" : "Provision of isoniazid preventive therapy if person does not have TB",
      "definition" : "Offer or refer for provision of isoniazid preventive therapy if person does not have TB"
    },
    {
      "code" : "HIV.D.DE759",
      "display" : "Malaria prevention (such as bed nets and prophylaxis), depending on epidemiology",
      "definition" : "Offer or refer for malaria prevention (such as bed nets and prophylaxis), depending on epidemiology"
    },
    {
      "code" : "HIV.D.DE760",
      "display" : "Eligible for DSD ART",
      "definition" : "Client is eligible for differentiated service delivery (DSD) for ART"
    },
    {
      "code" : "HIV.D.DE761",
      "display" : "Date DSD ART eligibility assessed",
      "definition" : "Date client was assessed for eligibility for differentiated service delivery (DSD) for ART"
    },
    {
      "code" : "HIV.D.DE762",
      "display" : "Currently enrolled in DSD ART model",
      "definition" : "Client currently enrolled in differentiated service delivery (DSD) ART model"
    },
    {
      "code" : "HIV.D.DE763",
      "display" : "DSD ART start date",
      "definition" : "Date client started on differentiated service delivery (DSD) for ART"
    },
    {
      "code" : "HIV.D.DE764",
      "display" : "DSD ART model(s)",
      "definition" : "Type of DSD ART model client is enrolled in (country-specific)"
    },
    {
      "code" : "HIV.D.DE765",
      "display" : "Fast track ART refill",
      "definition" : "Client is enrolled in fast track ART refill (DSD ART model)"
    },
    {
      "code" : "HIV.D.DE766",
      "display" : "Facility adherence club",
      "definition" : "Client is enrolled in facility adherence club (DSD ART model)"
    },
    {
      "code" : "HIV.D.DE767",
      "display" : "Community ART distribution point",
      "definition" : "Client is enrolled in community ART distribution point (DSD ART model)"
    },
    {
      "code" : "HIV.D.DE768",
      "display" : "CHW/peer educator community ART group",
      "definition" : "Client is enrolled in community health worker/peer educator community ART group (DSD ART model)"
    },
    {
      "code" : "HIV.D.DE769",
      "display" : "Patient/client community ART group",
      "definition" : "Client is enrolled in patient/client community ART group (DSD ART model)"
    },
    {
      "code" : "HIV.D.DE770",
      "display" : "Other DSD ART model",
      "definition" : "Client is enrolled in another DSD ART model"
    },
    {
      "code" : "HIV.D.DE771",
      "display" : "Other DSD ART model (specify)",
      "definition" : "Client is enrolled in another DSD ART model (specify)"
    },
    {
      "code" : "HIV.D.DE772",
      "display" : "Partner testing offered",
      "definition" : "Whether client was offered partner testing"
    },
    {
      "code" : "HIV.D.DE773",
      "display" : "Partner testing accepted",
      "definition" : "Whether partner testing was accepted"
    },
    {
      "code" : "HIV.D.DE774",
      "display" : "Date partner contacted for index testing",
      "definition" : "Date on which client's partner was contacted for index testing"
    },
    {
      "code" : "HIV.D.DE775",
      "display" : "Date partner tested for HIV",
      "definition" : "Date on which client's partner was tested for HIV"
    },
    {
      "code" : "HIV.D.DE776",
      "display" : "Date of next scheduled follow-up appointment",
      "definition" : "Date of client's next scheduled follow-up appointment"
    },
    {
      "code" : "HIV.D.DE777",
      "display" : "Type of next follow-up appointment",
      "definition" : "Type of client's next follow-up appointment (specify)"
    },
    {
      "code" : "HIV.D.DE778",
      "display" : "Syndrome/STI diagnosed",
      "definition" : "Syndrome or STI for which client is diagnosed"
    },
    {
      "code" : "HIV.D.DE779",
      "display" : "Urethral discharge syndrome",
      "definition" : "Client diagnosed with urethral discharge syndrome"
    },
    {
      "code" : "HIV.D.DE780",
      "display" : "Vaginal discharge syndrome",
      "definition" : "Client diagnosed with vaginal discharge syndrome"
    },
    {
      "code" : "HIV.D.DE781",
      "display" : "Lower Abdominal pain",
      "definition" : "Client diagnosed with lower abdominal pain"
    },
    {
      "code" : "HIV.D.DE782",
      "display" : "Genital ulcer disease syndrome",
      "definition" : "Client diagnosed with genital ulcer disease syndrome"
    },
    {
      "code" : "HIV.D.DE783",
      "display" : "Anorectal discharge",
      "definition" : "Client diagnosed with anorectal discharge"
    },
    {
      "code" : "HIV.D.DE784",
      "display" : "Sent for testing",
      "definition" : "Specimen sent for testing"
    },
    {
      "code" : "HIV.D.DE785",
      "display" : "Other",
      "definition" : "Other syndrome/STI diagnosed"
    },
    {
      "code" : "HIV.D.DE786",
      "display" : "Other (specify)",
      "definition" : "Other syndrome/STI diagnosed (specify)"
    },
    {
      "code" : "HIV.D.DE787",
      "display" : "Any STI syndrome diagnosed",
      "definition" : "Was the client diagnosed with any of the five STI syndromes during this visit?"
    },
    {
      "code" : "HIV.D.DE788",
      "display" : "Date of STI test",
      "definition" : "Date on which the STI test was conducted"
    },
    {
      "code" : "HIV.D.DE789",
      "display" : "STI tested for",
      "definition" : "STI for which the client was tested"
    },
    {
      "code" : "HIV.D.DE790",
      "display" : "Neisseria gonorrhoeae",
      "definition" : "Client tested for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.D.DE791",
      "display" : "Chlamydia trachomatis",
      "definition" : "Client tested for Chlamydia trachomatis"
    },
    {
      "code" : "HIV.D.DE792",
      "display" : "Trichomonas vaginalis",
      "definition" : "Client tested for Trichomonas vaginalis"
    },
    {
      "code" : "HIV.D.DE793",
      "display" : "Syphilis (Treponema pallidum)",
      "definition" : "Client tested for Syphilis (treponema pallidum)"
    },
    {
      "code" : "HIV.D.DE794",
      "display" : "Herpes simplex virus (HSV1, HSV2)",
      "definition" : "Client tested for herpes simplex virus (HSV1, HSV2)"
    },
    {
      "code" : "HIV.D.DE795",
      "display" : "Mycoplasma genitalium",
      "definition" : "Client tested for Mycoplasma genitalium"
    },
    {
      "code" : "HIV.D.DE796",
      "display" : "Mpox",
      "definition" : "Client tested for Mpox"
    },
    {
      "code" : "HIV.D.DE797",
      "display" : "Hepatitis B",
      "definition" : "Client tested for Hepatitis B"
    },
    {
      "code" : "HIV.D.DE798",
      "display" : "Hepatitis C",
      "definition" : "Client tested for Hepatitis C"
    },
    {
      "code" : "HIV.D.DE799",
      "display" : "Other",
      "definition" : "Client tested for other STI"
    },
    {
      "code" : "HIV.D.DE800",
      "display" : "Other (specify)",
      "definition" : "Client tested for other STI (specify)"
    },
    {
      "code" : "HIV.D.DE801",
      "display" : "Syphilis test date",
      "definition" : "Date of syphilis test"
    },
    {
      "code" : "HIV.D.DE802",
      "display" : "Syphilis test result",
      "definition" : "Result from syphilis test"
    },
    {
      "code" : "HIV.D.DE803",
      "display" : "Positive",
      "definition" : "Test result is positive for syphilis"
    },
    {
      "code" : "HIV.D.DE804",
      "display" : "Negative",
      "definition" : "Test result is negative for syphilis"
    },
    {
      "code" : "HIV.D.DE805",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.D.DE806",
      "display" : "Syphilis treatment start date",
      "definition" : "Date of initiation of syphilis treatment"
    },
    {
      "code" : "HIV.D.DE807",
      "display" : "Gonorrhoea test date",
      "definition" : "Date of Gonorrhoea test"
    },
    {
      "code" : "HIV.D.DE808",
      "display" : "Gonorrhoea test result",
      "definition" : "Result from Gonorrhoea test"
    },
    {
      "code" : "HIV.D.DE809",
      "display" : "Positive",
      "definition" : "Test result is positive for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.D.DE810",
      "display" : "Negative",
      "definition" : "Test result is negative for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.D.DE811",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.D.DE812",
      "display" : "Gonorrhoea treatment start date",
      "definition" : "Date of initiation of Gonorrhoea treatment"
    },
    {
      "code" : "HIV.D.DE813",
      "display" : "Type of specimen",
      "definition" : "Type of specimen to be collected"
    },
    {
      "code" : "HIV.D.DE814",
      "display" : "Blood",
      "definition" : "Blood specimen to be collected"
    },
    {
      "code" : "HIV.D.DE815",
      "display" : "Urine",
      "definition" : "Urine specimen to be collected"
    },
    {
      "code" : "HIV.D.DE816",
      "display" : "Cervical or vaginal swab",
      "definition" : "Cervical or vaginal swab to be collected"
    },
    {
      "code" : "HIV.D.DE817",
      "display" : "Urethral or penile swab",
      "definition" : "Urethral or penile swab to be collected"
    },
    {
      "code" : "HIV.D.DE818",
      "display" : "Rectal swab",
      "definition" : "Rectal swab to be collected"
    },
    {
      "code" : "HIV.D.DE819",
      "display" : "Other",
      "definition" : "Other specimen type to be collected"
    },
    {
      "code" : "HIV.D.DE820",
      "display" : "Other type of specimen (specify)",
      "definition" : "Other specimen type to be collected (specify)"
    },
    {
      "code" : "HIV.D.DE821",
      "display" : "Syphilis test type",
      "definition" : "Type of diagnostic test used for syphilis (Treponema pallidum)"
    },
    {
      "code" : "HIV.D.DE822",
      "display" : "Treponemal",
      "definition" : "Treponemal test used"
    },
    {
      "code" : "HIV.D.DE823",
      "display" : "Non-treponemal",
      "definition" : "Non-treponemal test used"
    },
    {
      "code" : "HIV.D.DE824",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.D.DE825",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.D.DE826",
      "display" : "Other",
      "definition" : "Other test used"
    },
    {
      "code" : "HIV.D.DE827",
      "display" : "Other syphilis test type (specify)",
      "definition" : "Other test used (specify)"
    },
    {
      "code" : "HIV.D.DE828",
      "display" : "Neisseria gonorrhoeae test type",
      "definition" : "Type of diagnostic test used for Neisseria gonorrhoeae"
    },
    {
      "code" : "HIV.D.DE829",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.D.DE830",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.D.DE831",
      "display" : "Culture",
      "definition" : "Culture test used"
    },
    {
      "code" : "HIV.D.DE832",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.D.DE833",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.D.DE834",
      "display" : "Other (specify)",
      "definition" : "Other type of test used (specify)"
    },
    {
      "code" : "HIV.D.DE835",
      "display" : "POC Test for Neisseria gonorrhoeae (specify)",
      "definition" : "Point-of-care (POC) test used for Neisseria gonorrhoeae (specify)"
    },
    {
      "code" : "HIV.D.DE836",
      "display" : "Chlamydia trachomatis test type",
      "definition" : "Type of diagnostic test used for Chlamydia trachomatis"
    },
    {
      "code" : "HIV.D.DE837",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.D.DE838",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.D.DE839",
      "display" : "Culture",
      "definition" : "Culture test used"
    },
    {
      "code" : "HIV.D.DE840",
      "display" : "ELISA",
      "definition" : "ELISA test used"
    },
    {
      "code" : "HIV.D.DE841",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.D.DE842",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.D.DE843",
      "display" : "Other test for Chlamydia (specify)",
      "definition" : "Other type of test used for Chlaymdia (specify)"
    },
    {
      "code" : "HIV.D.DE844",
      "display" : "POC Test type for Chlamydia test (specify)",
      "definition" : "Point-of-care (POC) test used for Chlamydia (specify)"
    },
    {
      "code" : "HIV.D.DE845",
      "display" : "Trichomonas vaginalis test type",
      "definition" : "Type of diagnostic test used for Trichomonas vaginalis"
    },
    {
      "code" : "HIV.D.DE846",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.D.DE847",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.D.DE848",
      "display" : "Culture",
      "definition" : "Culture test used"
    },
    {
      "code" : "HIV.D.DE849",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.D.DE850",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.D.DE851",
      "display" : "Other (specify)",
      "definition" : "Other type of test used (specify)"
    },
    {
      "code" : "HIV.D.DE852",
      "display" : "POC Test type for Trichomonas vaginalis test (specify)",
      "definition" : "Point-of-care (POC) test used (specify)"
    },
    {
      "code" : "HIV.D.DE853",
      "display" : "Herpes simplex virus (HSV) test type",
      "definition" : "Type of diagnostic test used for Herpes simplex virus (HSV)"
    },
    {
      "code" : "HIV.D.DE854",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.D.DE855",
      "display" : "Antibody test",
      "definition" : "Antibody test used"
    },
    {
      "code" : "HIV.D.DE856",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.D.DE857",
      "display" : "Other (specify)",
      "definition" : "Other type of test used for Herpes simplex virus (HSV) test (specify)"
    },
    {
      "code" : "HIV.D.DE858",
      "display" : "Mycoplasma genitalium test type",
      "definition" : "Type of diagnostic test used for Mycoplasma genitalium"
    },
    {
      "code" : "HIV.D.DE859",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.D.DE860",
      "display" : "Microscopy",
      "definition" : "Microscopy test used"
    },
    {
      "code" : "HIV.D.DE861",
      "display" : "Other",
      "definition" : "Other type of test used"
    },
    {
      "code" : "HIV.D.DE862",
      "display" : "Other (specify)",
      "definition" : "Other type of test used for Mycoplasma genitalium test (specify)"
    },
    {
      "code" : "HIV.D.DE863",
      "display" : "Test type for other STI tested for (specify)",
      "definition" : "Test type used for the other specified STI"
    },
    {
      "code" : "HIV.D.DE864",
      "display" : "STI test result",
      "definition" : "Result from STI test"
    },
    {
      "code" : "HIV.D.DE865",
      "display" : "Positive",
      "definition" : "Test result is positive"
    },
    {
      "code" : "HIV.D.DE866",
      "display" : "Negative",
      "definition" : "Test result is negative"
    },
    {
      "code" : "HIV.D.DE867",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.D.DE868",
      "display" : "Date of STI confirmatory test",
      "definition" : "Date of STI confirmatory test"
    },
    {
      "code" : "HIV.D.DE869",
      "display" : "Confirmatory syphilis test type",
      "definition" : "Type of test ued for confirmatory syphilis test"
    },
    {
      "code" : "HIV.D.DE870",
      "display" : "Treponemal",
      "definition" : "Treponemal test used"
    },
    {
      "code" : "HIV.D.DE871",
      "display" : "Non-treponemal",
      "definition" : "Non-treponemal test used"
    },
    {
      "code" : "HIV.D.DE872",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.D.DE873",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.D.DE874",
      "display" : "Other",
      "definition" : "Other test used"
    },
    {
      "code" : "HIV.D.DE875",
      "display" : "Other (specify)",
      "definition" : "Other test used for confirmatory syphilis test (specify)"
    },
    {
      "code" : "HIV.D.DE876",
      "display" : "Confirmatory test type for other STI (specify)",
      "definition" : "Confirmatory test type for other STI"
    },
    {
      "code" : "HIV.D.DE877",
      "display" : "Confirmatory STI test result",
      "definition" : "Result from confirmatory STI test"
    },
    {
      "code" : "HIV.D.DE878",
      "display" : "Positive",
      "definition" : "Test result is positive"
    },
    {
      "code" : "HIV.D.DE879",
      "display" : "Negative",
      "definition" : "Test result is negative"
    },
    {
      "code" : "HIV.D.DE880",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.D.DE881",
      "display" : "Date STI treatment prescribed",
      "definition" : "Date STI treatment was prescribed to the client"
    },
    {
      "code" : "HIV.D.DE882",
      "display" : "Date STI treatment dispensed",
      "definition" : "Date STI treatment dispensed to the client"
    },
    {
      "code" : "HIV.D.DE883",
      "display" : "STI treatment dispensed (specify)",
      "definition" : "STI treatment dispensed to the client"
    },
    {
      "code" : "HIV.D.DE884",
      "display" : "Mid-upper arm circumference (MUAC)",
      "definition" : "Client's mid-upper arm circumference (MUAC)"
    },
    {
      "code" : "HIV.D.DE885",
      "display" : "Date of start of fluconazole prophylaxis",
      "definition" : "Date of client's start of fluconazole prophylaxis"
    },
    {
      "code" : "HIV.D.DE886",
      "display" : "Fluconazole prophylaxis",
      "definition" : "Client provided with fluconazole prophylaxis"
    },
    {
      "code" : "HIV.D.DE887",
      "display" : "Date started cryptococcal meningitis treatment induction regimen",
      "definition" : "Date client started cryptococcal meningitis treatment induction regimen"
    },
    {
      "code" : "HIV.D.DE888",
      "display" : "Date completed cryptococcal meningitis treatment induction regimen",
      "definition" : "Date client completed cryptococcal meningitis treatment induction regimen"
    },
    {
      "code" : "HIV.D.DE889",
      "display" : "Date started cryptococcal meningitis treatment maintenance regimen",
      "definition" : "Date client started cryptococcal meningitis treatment maintenance regimen"
    },
    {
      "code" : "HIV.D.DE890",
      "display" : "Date completed cryptococcal meningitis treatment maintenance regimen",
      "definition" : "Date client completed cryptococcal meningitis treatment maintenance regimen"
    },
    {
      "code" : "HIV.D.DE891",
      "display" : "Date started cryptococcal meningitis treatment consolidation regimen",
      "definition" : "Date client started cryptococcal meningitis treatment consolidation regimen"
    },
    {
      "code" : "HIV.D.DE892",
      "display" : "Date completed cryptococcal meningitis treatment consolidation regimen",
      "definition" : "Date client completed cryptococcal meningitis treatment consolidation regimen"
    },
    {
      "code" : "HIV.D.DE893",
      "display" : "Staging of liver disease",
      "definition" : "Staging of liver disease in client"
    },
    {
      "code" : "HIV.D.DE894",
      "display" : "F0-4, fibrosis staging",
      "definition" : "Fibrosis staging of liver disease"
    },
    {
      "code" : "HIV.D.DE895",
      "display" : "F4 or cirrhosis, presence of cirrhosis",
      "definition" : "Presence of cirrhosis"
    },
    {
      "code" : "HIV.D.DE896",
      "display" : "Advanced HIV disease",
      "definition" : "Client has Advanced HIV disease (AHD)"
    },
    {
      "code" : "HIV.D.DE897",
      "display" : "WHO functional status",
      "definition" : "Functional status of people with advanced HIV disease"
    },
    {
      "code" : "HIV.D.DE898",
      "display" : "Working, able to perform usual work inside and outside the home",
      "definition" : "Client is able to perform usual work inside and outside the home (working)"
    },
    {
      "code" : "HIV.D.DE899",
      "display" : "Ambulatory, able to perform activity of daily living (ADL), not able to work",
      "definition" : "Client is able to perform activity of daily living (ADL), not able to work (ambulatory)"
    },
    {
      "code" : "HIV.D.DE900",
      "display" : "Bedridden not able to perform ADL",
      "definition" : "Client is dedridden not able to perform ADL"
    },
    {
      "code" : "HIV.D.DE901",
      "display" : "Tailored adherence counselling for advanced HIV disease",
      "definition" : "Client provided with tailored adherence counselling for advanced HIV disease"
    },
    {
      "code" : "HIV.D.DE902",
      "display" : "Date(s) of tracing interventions",
      "definition" : "Date tracing interventions to support reengagement into HIV care conducted"
    },
    {
      "code" : "HIV.D.DE903",
      "display" : "Medication/drug",
      "definition" : "Current or considered medication/drug, for the purpose of determining drug interactions"
    },
    {
      "code" : "HIV.D.DE904",
      "display" : "Rifampicin",
      "definition" : "Rifampicin currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE905",
      "display" : "Halofantrine",
      "definition" : "Halofantrine currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE906",
      "display" : "Lovastatin",
      "definition" : "Lovastatin currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE907",
      "display" : "Simvastatin",
      "definition" : "Simvastatin currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE908",
      "display" : "Hormonal contraception",
      "definition" : "Hormonal contraception currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE909",
      "display" : "Metformin",
      "definition" : "Metformin currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE910",
      "display" : "Astemizole",
      "definition" : "Astemizole currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE911",
      "display" : "Terfenadine",
      "definition" : "Terfenadine currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE912",
      "display" : "TDF",
      "definition" : "TDF currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE913",
      "display" : "Simeprevir",
      "definition" : "Simeprevir currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE914",
      "display" : "Ombitasvir + paritaprevir/ritonavir + dasabuvir",
      "definition" : "Ombitasvir + paritaprevir/ritonavir + dasabuvir currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE915",
      "display" : "Methadone",
      "definition" : "Methadone currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE916",
      "display" : "Buprenorphine",
      "definition" : "Buprenorphine currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE917",
      "display" : "Dofetilide",
      "definition" : "Dofetilide currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE918",
      "display" : "Carbamazepine",
      "definition" : "Carbamazepine currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE919",
      "display" : "Phenobarbital",
      "definition" : "Phenobarbital currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE920",
      "display" : "Phenytoin",
      "definition" : "Phenytoin currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE921",
      "display" : "Polyvalent cation products containing Mg, Al, Fe, Ca and Zn",
      "definition" : "Polyvalent cation products containing Mg, Al, Fe, Ca and Zn currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE922",
      "display" : "Amodiaquine",
      "definition" : "Amodiaquine currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE923",
      "display" : "Cisapride",
      "definition" : "Cisapride currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE924",
      "display" : "Ergotamine",
      "definition" : "Ergotamine currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE925",
      "display" : "Dihydroergotamine",
      "definition" : "Dihydroergotamine currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE926",
      "display" : "Midazolam",
      "definition" : "Midazolam currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE927",
      "display" : "Triazolam",
      "definition" : "Triazolam currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE928",
      "display" : "Estrogen-based hormonal contraception",
      "definition" : "Estrogen-based hormonal contraception currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE929",
      "display" : "Ribavirin",
      "definition" : "Ribavirin currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE930",
      "display" : "Peginterferon alfa-2a",
      "definition" : "Peginterferon alfa-2a currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE931",
      "display" : "Other",
      "definition" : "Other medication currently being taken by, or considered for, client"
    },
    {
      "code" : "HIV.D.DE932",
      "display" : "Other (specify)",
      "definition" : "Other medication currently being taken by, or considered for, client (specify)"
    },
    {
      "code" : "HIV.D.DE933",
      "display" : "Medication change recommended",
      "definition" : "A medication change is recommended for the client based upon current or considered medications"
    },
    {
      "code" : "HIV.D.DE934",
      "display" : "WHO HIV clinical stage condition or symptom",
      "definition" : "New or recurrent clinical events used to categorize HIV disease severity based at baseline and follow up"
    },
    {
      "code" : "HIV.D.DE935",
      "display" : "Pulmonary TB",
      "definition" : "Client's symptoms include pulmonary TB"
    },
    {
      "code" : "HIV.D.DE936",
      "display" : "Lymph node TB",
      "definition" : "Client's symptoms include lymph node TB"
    },
    {
      "code" : "HIV.D.DE937",
      "display" : "Extrapulmonary TB",
      "definition" : "Client's symptoms include extrapulmonary tuberculosis (TB)"
    },
    {
      "code" : "HIV.D.DE938",
      "display" : "TB disease",
      "definition" : "Whether the client has tuberculosis (TB) disease. Sometimes known as active TB"
    },
    {
      "code" : "HIV.D.DE939",
      "display" : "TB diagnosis result",
      "definition" : "Final result of the TB investigation (bacteriological and/or clinical)"
    },
    {
      "code" : "HIV.D.DE940",
      "display" : "Diagnosed TB",
      "definition" : "Client is diagnosed with TB disease"
    },
    {
      "code" : "HIV.D.DE941",
      "display" : "TB excluded",
      "definition" : "Client is not diagnosed with TB"
    },
    {
      "code" : "HIV.D.DE942",
      "display" : "Method of TB diagnosis",
      "definition" : "Method used to set the TB diagnosis"
    },
    {
      "code" : "HIV.D.DE943",
      "display" : "Bacteriologically confirmed",
      "definition" : "A person from whom a biological specimen is positive by smear microscopy, culture or a WHO-recommended rapid diagnostic"
    },
    {
      "code" : "HIV.D.DE944",
      "display" : "Clinically diagnosed",
      "definition" : "A person who does not fulfil the criteria for bacteriological confirmation but has been diagnosed with TB disease by a medical practitioner who has decided to give the person a full course of TB treatment"
    },
    {
      "code" : "HIV.D.DE945",
      "display" : "Presumptive TB",
      "definition" : "Client has signs or symptoms of tuberculosis (TB) without laboratory confirmation"
    },
    {
      "code" : "HIV.D.DE946",
      "display" : "Presumptive TB registration date",
      "definition" : "Date client is registered as having signs or symptoms of tuberculosis (TB) without laboratory confirmation"
    },
    {
      "code" : "HIV.D.DE947",
      "display" : "TB treatment history",
      "definition" : "History of previous TB treatment"
    },
    {
      "code" : "HIV.D.DE948",
      "display" : "New",
      "definition" : "A person with TB disease who has never been treated for TB before or has only previously ever taken TB drugs for less than 1 month"
    },
    {
      "code" : "HIV.D.DE949",
      "display" : "Recurrent",
      "definition" : "A person with TB disease who was previously treated for TB, was declared cured or treatment completed at the end of their most recent course of TB treatment and is now diagnosed with a new episode of TB."
    },
    {
      "code" : "HIV.D.DE950",
      "display" : "Re-registered",
      "definition" : "A person with TB disease who had been notified previously as a TB case, but was not declared cured or treatment completed, and is now being registered for a new course of TB treatment."
    },
    {
      "code" : "HIV.D.DE951",
      "display" : "Unknown",
      "definition" : "A person with TB disease who has undocumented history of TB treatment"
    },
    {
      "code" : "HIV.D.DE952",
      "display" : "Date of TB diagnosis",
      "definition" : "The date when the diagnosis was established"
    },
    {
      "code" : "HIV.D.DE953",
      "display" : "Currently on TB preventive treatment (TPT)",
      "definition" : "Client is currently taking TPT"
    },
    {
      "code" : "HIV.D.DE954",
      "display" : "TB preventive treatment (TPT) start date",
      "definition" : "The date on which the client began taking TPT"
    },
    {
      "code" : "HIV.D.DE955",
      "display" : "TB preventive treatment (TPT) completion date",
      "definition" : "The date on which the client completed TPT"
    },
    {
      "code" : "HIV.D.DE956",
      "display" : "TB screening algorithm",
      "definition" : "Screening algorithm selected for screening activities"
    },
    {
      "code" : "HIV.D.DE957",
      "display" : "Screening with cough",
      "definition" : "Client screened for TB based on cough symptom"
    },
    {
      "code" : "HIV.D.DE958",
      "display" : "Screening with any TB symptom",
      "definition" : "Client screened for TB based on any TB symptom"
    },
    {
      "code" : "HIV.D.DE959",
      "display" : "W4SS single screening algorithm",
      "definition" : "Client screened for TB based on the WHO-recommended four-symptom screen"
    },
    {
      "code" : "HIV.D.DE960",
      "display" : "CRP single screening algorithm",
      "definition" : "Client screened for TB based on C-reactive protein (CRP) testing"
    },
    {
      "code" : "HIV.D.DE961",
      "display" : "CXR single screening algorithm",
      "definition" : "Client screened for TB with a chest radiography (CXR)"
    },
    {
      "code" : "HIV.D.DE962",
      "display" : "Parallel screening algorithm with W4SS and CRP",
      "definition" : "Client screened for TB using parallel screening with WHO-recommended four-symptom screen and C-reactive protein (CRP) testing"
    },
    {
      "code" : "HIV.D.DE963",
      "display" : "Sequential positive screening algorithm with W4SS and CRP",
      "definition" : "Client screened for TB using sequential positive screening with WHO-recommended four-symptom screen and C-reactive protein (CRP) testing."
    },
    {
      "code" : "HIV.D.DE964",
      "display" : "Sequential negative screening algorithm with W4SS and CRP",
      "definition" : "Client screened for TB using sequential negative screening with WHO-recommended four-symptom screen and C-reactive protein (CRP) testing"
    },
    {
      "code" : "HIV.D.DE965",
      "display" : "Parallel screening algorithm with W4SS and CXR",
      "definition" : "Client screened for TB using the parallel screening algorithm with W4SS and CXR"
    },
    {
      "code" : "HIV.D.DE966",
      "display" : "Sequential positive screening algorithm with W4SS and CXR",
      "definition" : "Client screened for TB using sequential positive screening with WHO-recommended four-symptom screen and chest radiography"
    },
    {
      "code" : "HIV.D.DE967",
      "display" : "Sequential negative screening algorithm with W4SS and CXR",
      "definition" : "Client screened for TB using sequential negative screening with WHO-recommended four-symptom screen and chest radiography"
    },
    {
      "code" : "HIV.D.DE968",
      "display" : "Screening with mWRD",
      "definition" : "Client screened for TB with a molecular WHO-recommended rapid diagnostic test (mWRD), such as an Xpert MTB/RIF test to detect Mycobacterium tuberculosis (MTB)"
    },
    {
      "code" : "HIV.D.DE969",
      "display" : "Clinical assessment",
      "definition" : "Client screened for with a clinical evaluation for tuberculosis (TB) based on national guidelines. Clinical assessment may be used as an eligibility evaluation for testing with LF-LAM or for empiric TB treatment."
    },
    {
      "code" : "HIV.D.DE970",
      "display" : "Other TB screening algorithm",
      "definition" : "Client screened for tuberculosis (TB) with a different screening method not listed"
    },
    {
      "code" : "HIV.D.DE971",
      "display" : "Other TB screening algorithm (specify)",
      "definition" : "Client screened for tuberculosis (TB) with a different screening method not listed (specify)"
    },
    {
      "code" : "HIV.D.DE972",
      "display" : "TB screening conducted",
      "definition" : "A screening for tuberculosis (TB) was performed"
    },
    {
      "code" : "HIV.D.DE973",
      "display" : "Symptoms of TB",
      "definition" : "Symptoms that may indicate TB disease in clients living with HIV, based on a clinical algorithm"
    },
    {
      "code" : "HIV.D.DE974",
      "display" : "Current cough",
      "definition" : "Client has a cough regardless of duration"
    },
    {
      "code" : "HIV.D.DE975",
      "display" : "Prolonged cough (>=2w)",
      "definition" : "Client has a prolonged cough of 2 weeks or more"
    },
    {
      "code" : "HIV.D.DE976",
      "display" : "Fever of 39 °C or greater",
      "definition" : "Client has a fever with a measured temperature of 102.2 °F/39 °C or greater"
    },
    {
      "code" : "HIV.D.DE977",
      "display" : "Weight loss (reported)",
      "definition" : "Unexplained weight loss"
    },
    {
      "code" : "HIV.D.DE978",
      "display" : "Night sweats",
      "definition" : "Client reports experiencing night sweats"
    },
    {
      "code" : "HIV.D.DE979",
      "display" : "Poor weight gain",
      "definition" : "Client reports poor weight gain of child or infant or growth curve flattening or weight for age <-2 Z-scores."
    },
    {
      "code" : "HIV.D.DE980",
      "display" : "Reduced playfulness",
      "definition" : "Client reports reduced playfulness of child"
    },
    {
      "code" : "HIV.D.DE981",
      "display" : "Chest pain",
      "definition" : "Client reports chest pain"
    },
    {
      "code" : "HIV.D.DE982",
      "display" : "Haemoptysis",
      "definition" : "Client reports experiencing haemoptysis"
    },
    {
      "code" : "HIV.D.DE983",
      "display" : "Lethargy",
      "definition" : "Client reports lethargy"
    },
    {
      "code" : "HIV.D.DE984",
      "definition" : "No symptoms of TB identified"
    },
    {
      "code" : "HIV.D.DE985",
      "display" : "History of contact with a person with TB",
      "definition" : "Client had a history of a contact with a person with TB"
    },
    {
      "code" : "HIV.D.DE986",
      "display" : "TB screening result",
      "definition" : "Record the result of the tuberculosis (TB) screening"
    },
    {
      "code" : "HIV.D.DE987",
      "display" : "Screen positive for TB",
      "definition" : "Screening result was positive for tuberculosis (TB)"
    },
    {
      "code" : "HIV.D.DE988",
      "display" : "Screen negative for TB",
      "definition" : "Screening result was negative for tuberculosis (TB)"
    },
    {
      "code" : "HIV.D.DE989",
      "display" : "Inconclusive",
      "definition" : "Screening result was inconclusive for tuberculosis (TB)"
    },
    {
      "code" : "HIV.D.DE990",
      "display" : "TB screening date",
      "definition" : "Date the TB screening was conducted"
    },
    {
      "code" : "HIV.D.DE991",
      "display" : "TB screening result date",
      "definition" : "The date when the result of TB screening is available"
    },
    {
      "code" : "HIV.D.DE992",
      "display" : "TB diagnostic test category",
      "definition" : "The type of diagnostic test performed to detect tuberculosis (TB) disease"
    },
    {
      "code" : "HIV.D.DE993",
      "display" : "LF-LAM",
      "definition" : "Client tested for tuberculosis with a lateral flow urine lipoarabinomannan assay"
    },
    {
      "code" : "HIV.D.DE994",
      "display" : "mWRD test for TB",
      "definition" : "Client tested with a WHO-recommended molecular diagnostic test to detect Mycobacterium tuberculosis (MTB)"
    },
    {
      "code" : "HIV.D.DE995",
      "display" : "Microscopy - Sputum acid-fast bacilli (AFB)",
      "definition" : "Client tested for tuberculosis with a sputum acid-fast bacilli (AFB)"
    },
    {
      "code" : "HIV.D.DE996",
      "display" : "TB Culture",
      "definition" : "Client tested for tuberculosis (TB) with a culture"
    },
    {
      "code" : "HIV.D.DE997",
      "display" : "TB diagnostic test date",
      "definition" : "The date when TB diagnostic test was performed"
    },
    {
      "code" : "HIV.D.DE998",
      "display" : "Test sample collection date",
      "definition" : "The date when the test sample was collected from the client"
    },
    {
      "code" : "HIV.D.DE999",
      "display" : "TB diagnostic test result date",
      "definition" : "The date when the result of the TB diagnostic test is available"
    },
    {
      "code" : "HIV.D.DE1000",
      "display" : "TB treatment started",
      "definition" : "Indicates if TB treatment was started"
    },
    {
      "code" : "HIV.D.DE1001",
      "display" : "TB treatment start date",
      "definition" : "The date on which the client start or restarted tuberculosis (TB) treatment"
    },
    {
      "code" : "HIV.D.DE1002",
      "display" : "TB treatment outcome",
      "definition" : "Indicates patient's TB treatment outcome"
    },
    {
      "code" : "HIV.D.DE1003",
      "display" : "Treatment failed",
      "definition" : "The treatment regimen terminated or permanently changed to a new regimen or treatment strategy. Reasons for the change include:\n- no clinical response or no bacteriological response, or both (see note;\n- adverse drug reaction; or\n- evidence of additional drug-resistance to medicines in the regimen."
    },
    {
      "code" : "HIV.D.DE1004",
      "display" : "Cured",
      "definition" : "Client with pulmonary TB with bacteriologically confirmed TB at the beginning of treatment who completed treatment as recommended by the national policy, with evidence of bacteriological response and no evidence of failure."
    },
    {
      "code" : "HIV.D.DE1005",
      "display" : "Treatment completed",
      "definition" : "Patient completed treatment as recommended by the national policy but the outcome does not meet the definition for cure or treatment failure"
    },
    {
      "code" : "HIV.D.DE1006",
      "display" : "Died",
      "definition" : "Client died before starting treatment or during the course of treatment"
    },
    {
      "code" : "HIV.D.DE1007",
      "display" : "Lost to follow-up",
      "definition" : "Client was lost to follow-up"
    },
    {
      "code" : "HIV.D.DE1008",
      "display" : "Not evaluated",
      "definition" : "No treatment outcome was assigned. This includes cases 'transferred out' to another treatment unit and whose treatment outcome is unknown; however, it excludes those lost to follow-up."
    },
    {
      "code" : "HIV.D.DE1009",
      "display" : "TB treatment completion date",
      "definition" : "Date client completes TB treatment"
    },
    {
      "code" : "HIV.D.DE1010",
      "display" : "TB treatment regimen composition",
      "definition" : "TB drugs currently being taken by the client"
    },
    {
      "code" : "HIV.D.DE1011",
      "display" : "Isoniazid",
      "definition" : "Client is currently taking isoniazid"
    },
    {
      "code" : "HIV.D.DE1012",
      "display" : "Rifampicin",
      "definition" : "Client is currently taking rifampicin"
    },
    {
      "code" : "HIV.D.DE1013",
      "display" : "Rifabutin",
      "definition" : "Client is currently taking rifabutin"
    },
    {
      "code" : "HIV.D.DE1014",
      "display" : "Ethambutol",
      "definition" : "Client is currently taking ethambutol"
    },
    {
      "code" : "HIV.D.DE1015",
      "display" : "Levofloxacin",
      "definition" : "Client is currently taking levofloxacin"
    },
    {
      "code" : "HIV.D.DE1016",
      "display" : "Pyrazinamide",
      "definition" : "Client is currently taking pyrazinamide, a first-line anti-tuberculosis drug"
    },
    {
      "code" : "HIV.D.DE1017",
      "display" : "Eligible for TB preventive treatment",
      "definition" : "Client is eligible for tuberculosis preventive treatment (TPT)"
    },
    {
      "code" : "HIV.D.DE1018",
      "display" : "Date when eligibility for TB preventive treatment (TPT) was determined",
      "definition" : "Date when a determination of the client's eligibility for TPT was made"
    },
    {
      "code" : "HIV.D.DE1019",
      "display" : "TB status at ART start",
      "definition" : "Client's tuberculosis (TB) status when antiretroviral therapy (ART) is started"
    },
    {
      "code" : "HIV.D.DE1020",
      "display" : "Symptomatic for TB",
      "definition" : "Signs or symptoms of tuberculosis (TB) without laboratory confirmation"
    },
    {
      "code" : "HIV.D.DE1021",
      "display" : "Diagnosed TB",
      "definition" : "Laboratory confirmed tuberculosis (TB) diagnosis"
    },
    {
      "code" : "HIV.D.DE1022",
      "definition" : "Client has no signs or symptoms of tuberculosis (TB) and is not diagnosed with tuberculosis (TB)"
    },
    {
      "code" : "HIV.D.DE1023",
      "display" : "TB prevention services accepted",
      "definition" : "Indicates if the client accepts to be evaluated for TB infection and to take the treatment in case he/she is eligible"
    },
    {
      "code" : "HIV.D.DE1024",
      "display" : "TB meningitis",
      "definition" : "Type of extrapulmonary TB identified for the client is TB meningitis"
    },
    {
      "code" : "HIV.D.DE1025",
      "display" : "C reactive protein test date",
      "definition" : "The date on which the client has a test for C reactive protein"
    },
    {
      "code" : "HIV.D.DE1026",
      "display" : "C reactive protein test result",
      "definition" : "Test result of the client's C reactive protein test result in mg/L"
    },
    {
      "code" : "HIV.D.DE1027",
      "display" : "C reactive protein test result date",
      "definition" : "The date when the client's test result for C reactive protein is available"
    },
    {
      "code" : "HIV.D.DE1028",
      "display" : "TPT regimen type",
      "definition" : "Type of TPT regimen the client is currently on"
    },
    {
      "code" : "HIV.D.DE1029",
      "display" : "3HP",
      "definition" : "The client's current TPT regimen is 3HP"
    },
    {
      "code" : "HIV.D.DE1030",
      "display" : "1HP",
      "definition" : "The client's current TPT regimen is 1HP"
    },
    {
      "code" : "HIV.D.DE1031",
      "display" : "6H",
      "definition" : "The client's current TPT regimen is 6H"
    },
    {
      "code" : "HIV.D.DE1032",
      "display" : "Six months of levofloxacin daily",
      "definition" : "The client's current TPT regimen is six months of levofloxacin daily"
    },
    {
      "code" : "HIV.D.DE1033",
      "display" : "Other TB preventive treatment (TPT) regimen",
      "definition" : "The client's current TPT regimen is another regimen than those listed above"
    },
    {
      "code" : "HIV.D.DE1034",
      "display" : "TB preventive treatment (TPT) status",
      "definition" : "Indicates the current status of TB preventive treatment (TPT)"
    },
    {
      "code" : "HIV.D.DE1035",
      "display" : "Not started",
      "definition" : "The client did not start the TB preventive treatment (TPT)"
    },
    {
      "code" : "HIV.D.DE1036",
      "display" : "On TPT",
      "definition" : "The client started the TB preventive treatment (TPT) and is currently taking the medication, without treatment interruptions"
    },
    {
      "code" : "HIV.D.DE1037",
      "display" : "On TPT with interruptions",
      "definition" : "The client started the TB preventive treatment (TPT) and is currently taking the medication, with treatment interruptions"
    },
    {
      "code" : "HIV.D.DE1038",
      "display" : "On hold",
      "definition" : "The health care worker has temporarily stopped the TB preventive treatment (TPT), but TPT is expected to continue again later. May also be called 'suspended'."
    },
    {
      "code" : "HIV.D.DE1039",
      "display" : "Completed",
      "definition" : "TB preventive treatment (TPT) was completed"
    },
    {
      "code" : "HIV.E.DE1",
      "display" : "Pregnant woman's first name",
      "definition" : "Pregnant woman's first or given name"
    },
    {
      "code" : "HIV.E.DE2",
      "display" : "Pregnant woman's surname",
      "definition" : "Pregnant woman's family name or last name"
    },
    {
      "code" : "HIV.E.DE3",
      "display" : "Pregnant woman's unique ID",
      "definition" : "Unique identifier generated for new clients or a universal ID, if used in the country"
    },
    {
      "code" : "HIV.E.DE4",
      "display" : "Antenatal care number",
      "definition" : "Identification number assigned to woman at first visit to the ANC based on national system"
    },
    {
      "code" : "HIV.E.DE5",
      "display" : "Gestational age",
      "definition" : "Gestational age in weeks and/or days depending on the source of gestational age"
    },
    {
      "code" : "HIV.E.DE6",
      "display" : "Source of gestational age",
      "definition" : "Gestational age can be calculated multiple ways. This data element describes where the gestational age above has been calculated from."
    },
    {
      "code" : "HIV.E.DE7",
      "display" : "Last menstrual period (LMP)",
      "definition" : "Gestational age (GA) calculated from LMP"
    },
    {
      "code" : "HIV.E.DE8",
      "display" : "Ultrasound",
      "definition" : "Woman's gestational age today calculated field using ultrasound GA and ultrasound date"
    },
    {
      "code" : "HIV.E.DE9",
      "display" : "Symphysis fundal height (SFH) or abdominal palpation",
      "definition" : "If LMP is unknown and either ultrasound wasn't done or it wasn't done early enough, then show the option for health worker to enter GA in weeks based on Symphysis Fundal Height (SFH) or abdominal palpation."
    },
    {
      "code" : "HIV.E.DE10",
      "display" : "Expected date of delivery (EDD)",
      "definition" : "Expected date of delivery based on gestational age"
    },
    {
      "code" : "HIV.E.DE11",
      "display" : "Number of pregnancies (gravida)",
      "definition" : "Total number of times the woman has been pregnant (including this pregnancy). Also referred to as gravida."
    },
    {
      "code" : "HIV.E.DE12",
      "display" : "Number of previous pregnancies",
      "definition" : "This calculates the total number of all previous pregnancies (i.e. not including this current pregnancy). This is done for easier obstetric history calculations."
    },
    {
      "code" : "HIV.E.DE13",
      "display" : "Number of miscarriages and/or abortions",
      "definition" : "Total number of pregnancies lost or ended due to miscarriages and/or abortions before 22 weeks / 5 months"
    },
    {
      "code" : "HIV.E.DE14",
      "display" : "Number of live births",
      "definition" : "Total number of live births after 22 weeks"
    },
    {
      "code" : "HIV.E.DE15",
      "display" : "Number of caesarian sections",
      "definition" : "Total number of caesarean sections"
    },
    {
      "code" : "HIV.E.DE16",
      "display" : "Number of stillbirths",
      "definition" : "Total number of stillbirths after 22 weeks"
    },
    {
      "code" : "HIV.E.DE17",
      "display" : "Past pregnancy complications",
      "definition" : "Whether the woman has had any complications or problems in any previous pregnancy"
    },
    {
      "code" : "HIV.E.DE18",
      "display" : "No past pregnancy complications",
      "definition" : "No known past pregnancy problems"
    },
    {
      "code" : "HIV.E.DE19",
      "display" : "Does not know of any past pregnancy complications",
      "definition" : "Don't know if there were any problems during past pregnancies"
    },
    {
      "code" : "HIV.E.DE20",
      "display" : "Pre-eclampsia",
      "definition" : "A condition specific to pregnancy, arising after the 20th week of gestation, characterized by hypertension and proteinuria. Oedema may also be present, but is no longer considered a cardinal sign because it is present to some extent in most pregnancies. If not controlled, pre-eclampsia will lead to eclampsia which is characterized by fits, followed by coma, and has a high mortality rate."
    },
    {
      "code" : "HIV.E.DE21",
      "display" : "Eclampsia",
      "definition" : "A condition peculiar to pregnancy or a newly delivered woman, characterized by fits followed coma. The woman usually has hypertension and proteinuria. The fits may occur in the antepartum, intrapartum or early postpartum periods."
    },
    {
      "code" : "HIV.E.DE22",
      "display" : "Alcohol use",
      "definition" : "Alcohol intake"
    },
    {
      "code" : "HIV.E.DE23",
      "display" : "Baby died within 24 hours of birth",
      "definition" : "The woman's baby died within 24 hours of childbirth"
    },
    {
      "code" : "HIV.E.DE24",
      "display" : "Prolonged labour",
      "definition" : "The woman's experienced prolonged labour"
    },
    {
      "code" : "HIV.E.DE25",
      "display" : "Convulsions",
      "definition" : "Woman had convulsions during her past pregnancy"
    },
    {
      "code" : "HIV.E.DE26",
      "display" : "Forceps",
      "definition" : "Woman required forceps delivery"
    },
    {
      "code" : "HIV.E.DE27",
      "display" : "Gestational diabetes mellitus",
      "definition" : "Hyperglycaemia first detected at any time during pregnancy"
    },
    {
      "code" : "HIV.E.DE28",
      "display" : "Heavy bleeding (during or after delivery)",
      "definition" : "Woman was bleeding heavily during or after giving birth during previous pregnancy/pregnancies"
    },
    {
      "code" : "HIV.E.DE29",
      "display" : "Macrosomia",
      "definition" : "Fetus large for gestational age"
    },
    {
      "code" : "HIV.E.DE30",
      "display" : "Perineal tear (3rd or 4th degree)",
      "definition" : "Woman experienced 3rd or 4th degree perineal tear"
    },
    {
      "code" : "HIV.E.DE31",
      "display" : "Substance use",
      "definition" : "Illicit drug use (e.g. cannabis, amphetamines, prescription stimulants, opioids, opiates, ecstasy, cocaine)"
    },
    {
      "code" : "HIV.E.DE32",
      "display" : "Tobacco use",
      "definition" : "Use of tobacco products, in any form"
    },
    {
      "code" : "HIV.E.DE33",
      "display" : "Vacuum delivery",
      "definition" : "Woman required vacuum delivery"
    },
    {
      "code" : "HIV.E.DE34",
      "display" : "Other past pregnancy problems",
      "definition" : "Woman experienced other past pregnancy problems not described above"
    },
    {
      "code" : "HIV.E.DE35",
      "display" : "Other past pregnancy problems (specify)",
      "definition" : "Woman experienced other past pregnancy problems not described above (specify)"
    },
    {
      "code" : "HIV.E.DE36",
      "display" : "Parity",
      "definition" : "Total number of live and stillbirths (calculated)"
    },
    {
      "code" : "HIV.E.DE37",
      "display" : "Pregnancy in HIV-infected woman",
      "definition" : "Any HIV diagnosis in a pregnant woman as determined by the national HIV testing algorithm, or a pregnancy in a woman previously diagnosed with HIV"
    },
    {
      "code" : "HIV.E.DE38",
      "display" : "Date new pregnancy of HIV-positive woman identified",
      "definition" : "Earliest date when a new pregnancy of an HIV-positive woman is recorded"
    },
    {
      "code" : "HIV.E.DE39",
      "display" : "ANC contact during pregnancy",
      "definition" : "Whether the mother had at least one ANC contact (visit)"
    },
    {
      "code" : "HIV.E.DE40",
      "display" : "Date of first ANC visit",
      "definition" : "Date of the pregnant woman's first ANC visit"
    },
    {
      "code" : "HIV.E.DE41",
      "display" : "Timing of ART initiation",
      "definition" : "When the pregnant woman or mother initiated ART, for women living with HIV."
    },
    {
      "code" : "HIV.E.DE42",
      "display" : "Already on ART at first antenatal care visit",
      "definition" : "The pregnant woman was already on antiretroviral therapy (ART) at first antenatal care visit"
    },
    {
      "code" : "HIV.E.DE43",
      "display" : "Newly on ART during pregnancy",
      "definition" : "The pregnant woman started ART during her pregnancy"
    },
    {
      "code" : "HIV.E.DE44",
      "display" : "Newly on ART during labour and delivery",
      "definition" : "The woman started ART during labour and delivery"
    },
    {
      "code" : "HIV.E.DE45",
      "display" : "Maternal use of recommended ART regimen",
      "definition" : "Whether the mother is taking a recommended ART regimen"
    },
    {
      "code" : "HIV.E.DE46",
      "display" : "Delivery date",
      "definition" : "Date on which the woman delivered"
    },
    {
      "code" : "HIV.E.DE47",
      "display" : "Pregnancy outcome",
      "definition" : "Outcome of current pregnancy"
    },
    {
      "code" : "HIV.E.DE48",
      "display" : "Live birth",
      "definition" : "Outcome of pregnancy was a live birth"
    },
    {
      "code" : "HIV.E.DE49",
      "display" : "Early fetal loss/miscarriage",
      "definition" : "Outcome of pregnancy was early fetal loss/miscarriage"
    },
    {
      "code" : "HIV.E.DE50",
      "display" : "Induced abortion",
      "definition" : "Outcome of pregnancy was induced abortion"
    },
    {
      "code" : "HIV.E.DE51",
      "display" : "Stillbirth",
      "definition" : "Outcome of pregnancy was stillbirth"
    },
    {
      "code" : "HIV.E.DE52",
      "display" : "Delivery mode",
      "definition" : "Mode of delivery for current pregnancy"
    },
    {
      "code" : "HIV.E.DE53",
      "display" : "Spontaneous vaginal delivery",
      "definition" : "Mode of delivery for current pregnancy spontaneous vaginal delivery (SVD)"
    },
    {
      "code" : "HIV.E.DE54",
      "display" : "Assisted vaginal delivery",
      "definition" : "Mode of delivery for current pregnancy was assisted vaginal delivery"
    },
    {
      "code" : "HIV.E.DE55",
      "display" : "Caesarian section (C/S, operative delivery)",
      "definition" : "Mode of delivery for current pregnancy was caesarian section (C/S; operative delivery)"
    },
    {
      "code" : "HIV.E.DE56",
      "display" : "Indications for caesarian section (C/S)",
      "definition" : "Indications for caesarian section"
    },
    {
      "code" : "HIV.E.DE57",
      "display" : "Obstetric complications",
      "definition" : "Serious or life-threatening obstetric complications during pregnancy, delivery or postpartum experienced by mother or her newborn"
    },
    {
      "code" : "HIV.E.DE58",
      "display" : "Live birth",
      "definition" : "The woman had a live birth"
    },
    {
      "code" : "HIV.E.DE59",
      "display" : "Live birth to an HIV-positive woman",
      "definition" : "A woman living with HIV had a live birth"
    },
    {
      "code" : "HIV.E.DE60",
      "display" : "Gestational age at birth",
      "definition" : "Best estimate of gestational age in completed weeks when infant was born (an indication of prematurity, preterm and extreme preterm)"
    },
    {
      "code" : "HIV.E.DE61",
      "display" : "Small for gestational age (SGA)",
      "definition" : "Whether the infant was small for gestational age (SGA) at birth (<10th percentile)"
    },
    {
      "code" : "HIV.E.DE62",
      "display" : "Preterm birth status",
      "definition" : "The woman gave birth when the gestational age is less than 37 weeks"
    },
    {
      "code" : "HIV.E.DE63",
      "display" : "Not preterm",
      "definition" : "The birth was not preterm"
    },
    {
      "code" : "HIV.E.DE64",
      "display" : "Preterm (<37 weeks gestation)",
      "definition" : "Gestational age at birth was <37 weeks"
    },
    {
      "code" : "HIV.E.DE65",
      "display" : "Very preterm (<32 weeks gestation)",
      "definition" : "Gestational age at birth was <32 weeks"
    },
    {
      "code" : "HIV.E.DE66",
      "display" : "Maternal ART start date",
      "definition" : "The date on which the infant was started or restarted on ART"
    },
    {
      "code" : "HIV.E.DE67",
      "display" : "Place of delivery",
      "definition" : "The type of place where the woman delivered"
    },
    {
      "code" : "HIV.E.DE68",
      "display" : "Health facility",
      "definition" : "The woman delivered at a health facility"
    },
    {
      "code" : "HIV.E.DE69",
      "display" : "Home",
      "definition" : "The woman delivered at home"
    },
    {
      "code" : "HIV.E.DE70",
      "display" : "Other",
      "definition" : "The woman delivered at another location that is not at home or at a health facility"
    },
    {
      "code" : "HIV.E.DE71",
      "display" : "Other (specify)",
      "definition" : "The woman delivered at another location that is not at home or at a health facility (specify)"
    },
    {
      "code" : "HIV.E.DE72",
      "display" : "Delivery facility",
      "definition" : "Facility where the infant or child was born"
    },
    {
      "code" : "HIV.E.DE73",
      "display" : "Date of miscarriage or abortion",
      "definition" : "Date of the miscarriage/abortion"
    },
    {
      "code" : "HIV.E.DE74",
      "display" : "Date of death of mother",
      "definition" : "Date that the woman died"
    },
    {
      "code" : "HIV.E.DE75",
      "display" : "Cause of death of mother",
      "definition" : "The woman's cause of death"
    },
    {
      "code" : "HIV.E.DE76",
      "display" : "Infant's first name",
      "definition" : "Infant's first or given name"
    },
    {
      "code" : "HIV.E.DE77",
      "display" : "Infant's surname",
      "definition" : "Infant's family name or last name"
    },
    {
      "code" : "HIV.E.DE78",
      "display" : "Infant's unique ID",
      "definition" : "Unique identifier generated for new clients or a universal ID, if used in the country"
    },
    {
      "code" : "HIV.E.DE79",
      "display" : "Mother's first name",
      "definition" : "Biological mother's first or given name"
    },
    {
      "code" : "HIV.E.DE80",
      "display" : "Mother's surname",
      "definition" : "Biological mother's family name or last name"
    },
    {
      "code" : "HIV.E.DE81",
      "display" : "Mother's unique ID",
      "definition" : "Unique identifier generated for new clients or a universal ID, if used in the country"
    },
    {
      "code" : "HIV.E.DE82",
      "display" : "Caregiver's first name",
      "definition" : "Caregiver's first or given name"
    },
    {
      "code" : "HIV.E.DE83",
      "display" : "Caregiver's surname",
      "definition" : "Caregiver's family name or last name"
    },
    {
      "code" : "HIV.E.DE84",
      "display" : "Caregiver's unique identifier",
      "definition" : "Unique identifier generated for new clients or a universal ID, if used in the country"
    },
    {
      "code" : "HIV.E.DE85",
      "display" : "ANC contact date",
      "definition" : "The date and time of the client's ANC contact (in the ANC DAK this is called 'Contact date')"
    },
    {
      "code" : "HIV.E.DE86",
      "display" : "Referral",
      "definition" : "If infant was referred for care"
    },
    {
      "code" : "HIV.E.DE87",
      "display" : "Infant date of birth",
      "definition" : "The infant's date of birth (DOB) if known"
    },
    {
      "code" : "HIV.E.DE88",
      "display" : "Date of birth of infant unknown",
      "definition" : "Is the client's DOB unknown?"
    },
    {
      "code" : "HIV.E.DE89",
      "display" : "Estimated age of infant",
      "definition" : "If DOB is unknown, enter the client's estimated age. Display client's age in number of years"
    },
    {
      "code" : "HIV.E.DE90",
      "display" : "Age of infant",
      "definition" : "Infant age calculated using date of birth"
    },
    {
      "code" : "HIV.E.DE91",
      "display" : "Gender of infant",
      "definition" : "Gender of the infant"
    },
    {
      "code" : "HIV.E.DE92",
      "display" : "Female",
      "definition" : "Client identifies as female"
    },
    {
      "code" : "HIV.E.DE93",
      "display" : "Male",
      "definition" : "Client identifies as male"
    },
    {
      "code" : "HIV.E.DE94",
      "display" : "Other",
      "definition" : "Client identifies in a non-binary way"
    },
    {
      "code" : "HIV.E.DE95",
      "display" : "Infant height",
      "definition" : "The infant's height in centimetres"
    },
    {
      "code" : "HIV.E.DE96",
      "display" : "Infant weight",
      "definition" : "The infant's current weight in kilograms"
    },
    {
      "code" : "HIV.E.DE97",
      "display" : "Birth weight",
      "definition" : "Birth weight in kg of the baby"
    },
    {
      "code" : "HIV.E.DE98",
      "display" : "Low birth weight",
      "definition" : "Note if infant </¬¨‚â•2500 g at birth"
    },
    {
      "code" : "HIV.E.DE99",
      "display" : "Length of infant",
      "definition" : "Length of infant at birth in cm"
    },
    {
      "code" : "HIV.E.DE100",
      "display" : "Head circumference",
      "definition" : "Head circumference of infant at birth in cm"
    },
    {
      "code" : "HIV.E.DE101",
      "display" : "Mother HIV test conducted",
      "definition" : "Whether an HIV test of the mother was conducted"
    },
    {
      "code" : "HIV.E.DE102",
      "display" : "Mother HIV test ordered",
      "definition" : "Whether an HIV test of the mother was ordered"
    },
    {
      "code" : "HIV.E.DE103",
      "display" : "Mother HIV test date",
      "definition" : "Date when a mother's HIV test was conducted"
    },
    {
      "code" : "HIV.E.DE104",
      "display" : "Maternal HIV test result",
      "definition" : "Test result for mother after applying the testing strategy"
    },
    {
      "code" : "HIV.E.DE105",
      "display" : "HIV-positive",
      "definition" : "Test result is HIV-positive"
    },
    {
      "code" : "HIV.E.DE106",
      "display" : "HIV-negative",
      "definition" : "Test result is HIV-negative"
    },
    {
      "code" : "HIV.E.DE107",
      "display" : "HIV-inconclusive",
      "definition" : "Test result is HIV-inconclusive"
    },
    {
      "code" : "HIV.E.DE108",
      "display" : "Infant or child exposure to HIV",
      "definition" : "Whether the infant or child was determined to have had HIV exposure through mother"
    },
    {
      "code" : "HIV.E.DE109",
      "display" : "Not exposed",
      "definition" : "Infant or child is not known to have been exposed to HIV"
    },
    {
      "code" : "HIV.E.DE110",
      "display" : "HIV-exposed",
      "definition" : "Infant had known exposure to HIV"
    },
    {
      "code" : "HIV.E.DE111",
      "display" : "Unknown HIV exposure",
      "definition" : "Don't know whether infant or child was exposed to HIV, such as if mother's HIV status is unknown"
    },
    {
      "code" : "HIV.E.DE112",
      "display" : "HIV-exposed infant or child",
      "definition" : "Whether the infant or child was determined to have had HIV exposure"
    },
    {
      "code" : "HIV.E.DE113",
      "display" : "Key population member",
      "definition" : "Mother is a member of a key population which has an increased risk of HIV"
    },
    {
      "code" : "HIV.E.DE114",
      "display" : "Key population member type",
      "definition" : "The type of key population that the infant's mother is included in"
    },
    {
      "code" : "HIV.E.DE115",
      "display" : "Sex worker",
      "definition" : "Infant's mother is a sex worker"
    },
    {
      "code" : "HIV.E.DE116",
      "display" : "People who inject drugs",
      "definition" : "Infant's mother is a person who injects drugs"
    },
    {
      "code" : "HIV.E.DE117",
      "display" : "Trans and gender-diverse people",
      "definition" : "Infant's mother identifies as trans and gender-diverse"
    },
    {
      "code" : "HIV.E.DE118",
      "display" : "People living in prisons and other closed setting",
      "definition" : "Infant's mother is in a prison or closed setting"
    },
    {
      "code" : "HIV.E.DE119",
      "display" : "Postpartum family planning counselling conducted",
      "definition" : "Provide family planning and contraception counselling"
    },
    {
      "code" : "HIV.E.DE120",
      "display" : "Age of infant on HIV test date",
      "definition" : "Infant's age when an HIV test is performed in months and years (calculated from date of birth)"
    },
    {
      "code" : "HIV.E.DE121",
      "display" : "ARV adherence counselling",
      "definition" : "Counselling was carried out during visit"
    },
    {
      "code" : "HIV.E.DE122",
      "display" : "Infant feeding counselling provided",
      "definition" : "Support on infant and child feeding to mother or caregiver provided"
    },
    {
      "code" : "HIV.E.DE123",
      "display" : "Date infant feeding counselling provided",
      "definition" : "Date support on infant and child feeding to mother or caregiver provided"
    },
    {
      "code" : "HIV.E.DE124",
      "display" : "Malaria prevention counselling conducted",
      "definition" : "Counselling provided on how to prevent malaria"
    },
    {
      "code" : "HIV.E.DE125",
      "display" : "Insecticide treated bednet (ITN) provided or referred",
      "definition" : "An insecticide treated bednet (ITN) was provided or the client was referred"
    },
    {
      "code" : "HIV.E.DE126",
      "display" : "Maternal syphilis treatment",
      "definition" : "Whether or not mother was treated for syphilis"
    },
    {
      "code" : "HIV.E.DE127",
      "display" : "Infant feeding practice",
      "definition" : "Infant feeding practice"
    },
    {
      "code" : "HIV.E.DE128",
      "display" : "Exclusively breastfeeding",
      "definition" : "Specifies whether the infant is exclusively being breastfed by the mother"
    },
    {
      "code" : "HIV.E.DE129",
      "display" : "Replacement feeding",
      "definition" : "Infant is not receiving any breast milk with a diet that provides all the nutrients needed until they can be fully fed on family foods"
    },
    {
      "code" : "HIV.E.DE130",
      "display" : "Mixed feeding",
      "definition" : "Infant younger than 6 months of age is given other liquids and/or foods together with breast milk. This could be water, other types of milk or any type of solid food."
    },
    {
      "code" : "HIV.E.DE131",
      "display" : "Infant feeding practice recorded date",
      "definition" : "Date on which infant feeding practice was recorded"
    },
    {
      "code" : "HIV.E.DE132",
      "display" : "Stopped breastfeeding",
      "definition" : "The mother has fully stopped breastfeeding the infant or child"
    },
    {
      "code" : "HIV.E.DE133",
      "display" : "Date stopped breastfeeding",
      "definition" : "The date on which the mother stopped breastfeeding the infant"
    },
    {
      "code" : "HIV.E.DE134",
      "display" : "Taking iron and folic acid (IFA) tablets",
      "definition" : "Is client taking her iron and folic acid (IFA) tablets? Select whether the woman is continuing to take IFA supplements"
    },
    {
      "code" : "HIV.E.DE135",
      "display" : "Amount of iron prescribed",
      "definition" : "Amount of iron supplements prescribed in milligrams for intake"
    },
    {
      "code" : "HIV.E.DE136",
      "display" : "Type of iron supplement dosage provided",
      "definition" : "Whether the amount of iron prescribed is for daily or weekly intake"
    },
    {
      "code" : "HIV.E.DE137",
      "display" : "Daily",
      "definition" : "Iron supplements prescribed for daily intake"
    },
    {
      "code" : "HIV.E.DE138",
      "display" : "Weekly",
      "definition" : "Iron supplements prescribed for daily intake"
    },
    {
      "code" : "HIV.E.DE139",
      "display" : "Amount of daily dose of folic acid prescribed",
      "definition" : "Amount of folic acid supplements prescribed in milligrams for daily intake"
    },
    {
      "code" : "HIV.E.DE140",
      "display" : "Date infant ARV prophylaxis dispensed (or started)",
      "definition" : "Date HIV-exposed infant received ARV prophylaxis (for the first time)"
    },
    {
      "code" : "HIV.E.DE141",
      "display" : "Maternal HIV status",
      "definition" : "The HIV status of the infant's mother"
    },
    {
      "code" : "HIV.E.DE142",
      "display" : "HIV-positive",
      "definition" : "Infant's mother is HIV-positive"
    },
    {
      "code" : "HIV.E.DE143",
      "display" : "HIV-negative",
      "definition" : "Infant's mother is HIV-negative"
    },
    {
      "code" : "HIV.E.DE144",
      "display" : "Unknown",
      "definition" : "Don't know HIV status - client does not know partner's HIV status"
    },
    {
      "code" : "HIV.E.DE145",
      "display" : "Maternal HIV status at first ANC visit",
      "definition" : "The HIV status of the infant's mother at first ANC visit"
    },
    {
      "code" : "HIV.E.DE146",
      "display" : "HIV-positive",
      "definition" : "Infant's mother is HIV-positive"
    },
    {
      "code" : "HIV.E.DE147",
      "display" : "HIV-negative",
      "definition" : "Infant's mother is HIV-negative"
    },
    {
      "code" : "HIV.E.DE148",
      "display" : "Unknown",
      "definition" : "Don't know HIV status - client does not know partner's HIV status"
    },
    {
      "code" : "HIV.E.DE149",
      "display" : "Maternal syphilis test result",
      "definition" : "Result from maternal syphilis test"
    },
    {
      "code" : "HIV.E.DE150",
      "display" : "Positive",
      "definition" : "Test result is positive for syphilis"
    },
    {
      "code" : "HIV.E.DE151",
      "display" : "Negative",
      "definition" : "Test result is negative for syphilis"
    },
    {
      "code" : "HIV.E.DE152",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.E.DE153",
      "display" : "Hypertension",
      "definition" : "Whether the client has developed hypertension associated with pregnancy"
    },
    {
      "code" : "HIV.E.DE154",
      "display" : "Pre-eclampsia",
      "definition" : "Whether the client has pre-eclampsia"
    },
    {
      "code" : "HIV.E.DE155",
      "display" : "Signs of substantial risk of HIV infection",
      "definition" : "Signs the client is at a substantial risk of HIV infection"
    },
    {
      "code" : "HIV.E.DE156",
      "display" : "No condom use during sex with more than one partner in the past 6 months",
      "definition" : "Recent vaginal or anal sexual intercourse without a condom with more than one partner"
    },
    {
      "code" : "HIV.E.DE157",
      "display" : "STI in the past 6 months",
      "definition" : "A recent history (in the last 6 months) of a sexually transmitted infection (STI) by laboratory testing or self-report of syndromic STI treatment"
    },
    {
      "code" : "HIV.E.DE158",
      "display" : "A sexual partner in the past 6 months had one or more HIV risk factors",
      "definition" : "A recent sex partner of the client had HIV risk factors"
    },
    {
      "code" : "HIV.E.DE159",
      "display" : "PrEP requested by client",
      "definition" : "Client is requesting PrEP, reflecting a decision-making process has already taken place and suggesting of substantial risk of HIV"
    },
    {
      "code" : "HIV.E.DE160",
      "display" : "Serodiscordant partner",
      "definition" : "Mother's HIV status is different from a current partner's HIV status"
    },
    {
      "code" : "HIV.E.DE161",
      "display" : "Date woman received counselling for CPT",
      "definition" : "Date woman received counselling for co-trimoxazole preventive therapy (CPT)"
    },
    {
      "code" : "HIV.E.DE162",
      "display" : "Date woman received counselling for TPT",
      "definition" : "Date woman received counselling for TB preventive therapy"
    },
    {
      "code" : "HIV.E.DE163",
      "display" : "Infant's co-trimoxazole prophylaxis start date",
      "definition" : "Start date of co-trimoxazole prophylaxis"
    },
    {
      "code" : "HIV.E.DE164",
      "display" : "Infant's age when co-trimoxazole prophylaxis was started",
      "definition" : "The number of weeks or months infant was when started on co-trimoxazole (CTX) prophylaxis preventive therapy"
    },
    {
      "code" : "HIV.E.DE165",
      "display" : "Presumptive clinical diagnosis of severe HIV infection in infants",
      "definition" : "Presumptive clinical diagnosis of severe HIV infection in infants"
    },
    {
      "code" : "HIV.E.DE166",
      "display" : "Infant ARV prophylaxis",
      "definition" : "Infant is taking an antiretroviral prophylaxis to prevent infection from HIV exposure"
    },
    {
      "code" : "HIV.E.DE167",
      "display" : "Infant ARV prophylaxis start date",
      "definition" : "The date on which the infant was started on an antiretroviral prophylaxis"
    },
    {
      "code" : "HIV.E.DE168",
      "display" : "HIV test type",
      "definition" : "Type of HIV test"
    },
    {
      "code" : "HIV.E.DE169",
      "display" : "Rapid diagnostic test for HIV",
      "definition" : "Antibody test for HIV performed with a rapid diagnostic (RDT)"
    },
    {
      "code" : "HIV.E.DE170",
      "display" : "Enzyme immunoassay for HIV",
      "definition" : "Antibody test for HIV performed with an enzyme immunoassay (EIA)"
    },
    {
      "code" : "HIV.E.DE171",
      "display" : "Nucleic acid test for HIV",
      "definition" : "Virological test, which includes testing for early infant diagnosis"
    },
    {
      "code" : "HIV.E.DE172",
      "display" : "Dual HIV/syphilis rapid diagnostic test",
      "definition" : "Antibody test for HIV and syphilis performed with a rapid diagnostic"
    },
    {
      "code" : "HIV.E.DE173",
      "display" : "Maternal and child health service visit",
      "definition" : "Maternal and child health service visit attended by an HIV-exposed infant"
    },
    {
      "code" : "HIV.E.DE174",
      "display" : "12-month visit",
      "definition" : "HIV-exposed infant attending MCH services for a 12-month visit"
    },
    {
      "code" : "HIV.E.DE175",
      "display" : "24-month visit",
      "definition" : "HIV-exposed infants attending MCH services for a 24-month visit"
    },
    {
      "code" : "HIV.E.DE176",
      "display" : "First visit after the end of breastfeeding",
      "definition" : "HIV-exposed infant attending MCH services for a first visit after the end of breastfeeding"
    },
    {
      "code" : "HIV.E.DE177",
      "display" : "Weeks postpartum",
      "definition" : "Number of weeks postpartum on this visit date"
    },
    {
      "code" : "HIV.E.DE178",
      "display" : "Birth cohort",
      "definition" : "Month and year of infant's birth, which the infant is registered into. The cohort is a group of infants born in the same month, whose status is followed over time."
    },
    {
      "code" : "HIV.E.DE179",
      "display" : "Registered in birth cohort",
      "definition" : "Whether the infant has been registered in a birth cohort"
    },
    {
      "code" : "HIV.E.DE180",
      "display" : "EID sample number",
      "definition" : "Early infant diagnosis (EID) sample number"
    },
    {
      "code" : "HIV.E.DE181",
      "display" : "EID sample 1",
      "definition" : "First sample used to test an infant for HIV"
    },
    {
      "code" : "HIV.E.DE182",
      "display" : "EID sample 2",
      "definition" : "Second sample used to test an infant for HIV"
    },
    {
      "code" : "HIV.E.DE183",
      "display" : "EID test number",
      "definition" : "Early infant diagnosis (EID) HIV test number using the same sample"
    },
    {
      "code" : "HIV.E.DE184",
      "display" : "EID test number 1",
      "definition" : "First test on a sample to test an infant for HIV"
    },
    {
      "code" : "HIV.E.DE185",
      "display" : "EID test number 2",
      "definition" : "Second test on a sample to test an infant for HIV"
    },
    {
      "code" : "HIV.E.DE186",
      "display" : "EID test number 1 test result",
      "definition" : "Early infant diagnosis test number 1 test result"
    },
    {
      "code" : "HIV.E.DE187",
      "display" : "Positive",
      "definition" : "Positive HIV test result from the nucleic acid test"
    },
    {
      "code" : "HIV.E.DE188",
      "display" : "Negative",
      "definition" : "Negative HIV test result from the nucleic acid test"
    },
    {
      "code" : "HIV.E.DE189",
      "display" : "Indeterminate",
      "definition" : "Indeterminate HIV test result from the nucleic acid test"
    },
    {
      "code" : "HIV.E.DE190",
      "display" : "EID test number 2 test result",
      "definition" : "Early infant diagnosis test number 2 test result"
    },
    {
      "code" : "HIV.E.DE191",
      "display" : "Positive",
      "definition" : "Positive HIV test result from the nucleic acid test"
    },
    {
      "code" : "HIV.E.DE192",
      "display" : "Negative",
      "definition" : "Negative HIV test result from the nucleic acid test"
    },
    {
      "code" : "HIV.E.DE193",
      "display" : "Indeterminate",
      "definition" : "Indeterminate HIV test result from the nucleic acid test"
    },
    {
      "code" : "HIV.E.DE194",
      "display" : "Assay number in testing strategy",
      "definition" : "The number of the assay (test kit) in the HIV testing strategy"
    },
    {
      "code" : "HIV.E.DE195",
      "display" : "Assay 0",
      "definition" : "A community outreach test-for-triage or self-test which is not included in the HIV testing strategy"
    },
    {
      "code" : "HIV.E.DE196",
      "display" : "Assay 1",
      "definition" : "The first test in the HIV testing strategy"
    },
    {
      "code" : "HIV.E.DE197",
      "display" : "Assay 2",
      "definition" : "The second test in the HIV testing strategy"
    },
    {
      "code" : "HIV.E.DE198",
      "display" : "Assay 3",
      "definition" : "The third test in the HIV testing strategy"
    },
    {
      "code" : "HIV.E.DE199",
      "display" : "Assay 1 repeated",
      "definition" : "The first test in the HIV testing strategy"
    },
    {
      "code" : "HIV.E.DE200",
      "display" : "Test result of HIV assay 1",
      "definition" : "The result of the first HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.E.DE201",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.E.DE202",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.E.DE203",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.E.DE204",
      "display" : "Test result of HIV assay 2",
      "definition" : "The result of the second HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.E.DE205",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.E.DE206",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.E.DE207",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.E.DE208",
      "display" : "Test result of HIV assay 3",
      "definition" : "The result of the third HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.E.DE209",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.E.DE210",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.E.DE211",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.E.DE212",
      "display" : "Test result of HIV assay 1 repeated",
      "definition" : "The result of the repeated first HIV assay in the testing strategy"
    },
    {
      "code" : "HIV.E.DE213",
      "display" : "Reactive",
      "definition" : "The result of the HIV assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.E.DE214",
      "display" : "Non-reactive",
      "definition" : "The result of the HIV assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.E.DE215",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.E.DE216",
      "display" : "Test result of syphilis assay 1",
      "definition" : "The result of the first syphilis assay in the testing strategy"
    },
    {
      "code" : "HIV.E.DE217",
      "display" : "Reactive",
      "definition" : "The result of the first syphilis assay in the testing strategy was reactive"
    },
    {
      "code" : "HIV.E.DE218",
      "display" : "Non-reactive",
      "definition" : "The result of the first syphilis assay in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.E.DE219",
      "display" : "Invalid",
      "definition" : "The result of the HIV assay in the testing strategy was invalid"
    },
    {
      "code" : "HIV.E.DE220",
      "display" : "Test result of syphilis assay 1 repeated",
      "definition" : "The result of the first syphilis assay repeated in the testing strategy"
    },
    {
      "code" : "HIV.E.DE221",
      "display" : "Reactive",
      "definition" : "The result of the first syphilis assay repeated in the testing strategy was reactive"
    },
    {
      "code" : "HIV.E.DE222",
      "display" : "Non-reactive",
      "definition" : "The result of the first syphilis assay repeated in the testing strategy was non-reactive"
    },
    {
      "code" : "HIV.E.DE223",
      "display" : "Invalid",
      "definition" : "The result of the first syphilis assay repeated in the testing strategy was invalid"
    },
    {
      "code" : "HIV.E.DE224",
      "display" : "HIV test date",
      "definition" : "Date of the HIV test"
    },
    {
      "code" : "HIV.E.DE225",
      "display" : "Infant HIV status",
      "definition" : "HIV status reported after applying the HIV testing algorithm. No single HIV test can provide an HIV-positive diagnosis."
    },
    {
      "code" : "HIV.E.DE226",
      "display" : "HIV-positive",
      "definition" : "Infant is HIV-positive"
    },
    {
      "code" : "HIV.E.DE227",
      "display" : "HIV-negative",
      "definition" : "Infant is HIV-negative"
    },
    {
      "code" : "HIV.E.DE228",
      "display" : "Unknown",
      "definition" : "Infant has unknown HIV status"
    },
    {
      "code" : "HIV.E.DE229",
      "display" : "Infant ART start date",
      "definition" : "The date on which the infant was started or restarted on antiretroviral therapy (ART)"
    },
    {
      "code" : "HIV.E.DE230",
      "display" : "Final diagnosis of HIV-exposed infant",
      "definition" : "HIV-exposed infant final status at 18 months or 3 months after cessation of breastfeeding (whichever is later)."
    },
    {
      "code" : "HIV.E.DE231",
      "display" : "HIV-positive",
      "definition" : "The infant is HIV-positive"
    },
    {
      "code" : "HIV.E.DE232",
      "display" : "HIV-negative and no longer breastfeeding",
      "definition" : "The infant is HIV-negative and the mother has quit breastfeeding"
    },
    {
      "code" : "HIV.E.DE233",
      "display" : "HIV status unknown",
      "definition" : "The final HIV status of the child is unknown because the infant died, was lost to follow-up or transferred out without ever having an HIV-positive diagnosis or is active in care but was not tested at 18 months"
    },
    {
      "code" : "HIV.E.DE234",
      "display" : "HIV-exposed infant reason for unknown final status",
      "definition" : "The outcome for the infant does not have a final outcome, which may because of death, stopped treatment or lost to follow-up."
    },
    {
      "code" : "HIV.E.DE235",
      "display" : "Lost to follow-up",
      "definition" : "Twenty-eight days or more since last missed appointment"
    },
    {
      "code" : "HIV.E.DE236",
      "display" : "Transferred out",
      "definition" : "The client transferred to another facility"
    },
    {
      "code" : "HIV.E.DE237",
      "display" : "Death (documented)",
      "definition" : "People living with HIV previously on ART who are confirmed to have died from any cause"
    },
    {
      "code" : "HIV.E.DE238",
      "display" : "Refused (stopped) treatment",
      "definition" : "Client was contacted and confirmed to have stopped ART"
    },
    {
      "code" : "HIV.E.DE239",
      "display" : "Date of death of infant",
      "definition" : "Date that the infant died"
    },
    {
      "code" : "HIV.E.DE240",
      "display" : "Cause of death of infant",
      "definition" : "The infant's cause of death"
    },
    {
      "code" : "HIV.E.DE241",
      "display" : "Infant died within 24 hours of childbirth",
      "definition" : "The infant died within 24 hours of childbirth"
    },
    {
      "code" : "HIV.E.DE242",
      "display" : "Action(s) needed during infant follow-up visit",
      "definition" : "Any actions needed during infant follow-up visit"
    },
    {
      "code" : "HIV.E.DE243",
      "display" : "Timing of additional infant HIV test",
      "definition" : "Age in months when additional infant HIV test is performed"
    },
    {
      "code" : "HIV.E.DE244",
      "display" : "Date of sample collection of additional infant HIV test",
      "definition" : "Date of sample collection of additional infant HIV test"
    },
    {
      "code" : "HIV.E.DE245",
      "display" : "Haemoglobin (Hb) result",
      "definition" : "Result of woman's haemoglobin test during ANC, labour or delivery. Full blood count testing is recommended, and if not available, use of  haemoglobinometer over haemoglobin colour scale."
    },
    {
      "code" : "HIV.E.DE246",
      "display" : "Blood group and Rh factor",
      "definition" : "Mother's blood type and blood Rh factor"
    },
    {
      "code" : "HIV.E.DE247",
      "display" : "A+",
      "definition" : "Mother's blood type and blood Rh factor is A+"
    },
    {
      "code" : "HIV.E.DE248",
      "display" : "A-",
      "definition" : "Mother's blood type and blood Rh factor is A-"
    },
    {
      "code" : "HIV.E.DE249",
      "display" : "B+",
      "definition" : "Mother's blood type and blood Rh factor is B+"
    },
    {
      "code" : "HIV.E.DE250",
      "display" : "B-",
      "definition" : "Mother's blood type and blood Rh factor is B-"
    },
    {
      "code" : "HIV.E.DE251",
      "display" : "O+",
      "definition" : "Mother's blood type and blood Rh factor is O+"
    },
    {
      "code" : "HIV.E.DE252",
      "display" : "O-",
      "definition" : "Mother's blood type and blood Rh factor is O-"
    },
    {
      "code" : "HIV.E.DE253",
      "display" : "AB+",
      "definition" : "Mother's blood type and blood Rh factor is AB+"
    },
    {
      "code" : "HIV.E.DE254",
      "display" : "AB-",
      "definition" : "Mother's blood type and blood Rh factor is AB-"
    },
    {
      "code" : "HIV.E.DE255",
      "display" : "Asymptomatic bacteriuria (ASB) test result",
      "definition" : "Result of urine culture (or urine Gram-staining if not available over dipstick tests) for diagnosing asymptomatic bacteriuria"
    },
    {
      "code" : "HIV.E.DE256",
      "display" : "Positive",
      "definition" : "Result of test for asymptomatic bacteriuria is positive"
    },
    {
      "code" : "HIV.E.DE257",
      "display" : "Negative",
      "definition" : "Result of test for asymptomatic bacteriuria is negative"
    },
    {
      "code" : "HIV.E.DE258",
      "display" : "Unknown",
      "definition" : "Result of test for asymptomatic bacteriuria is unknown"
    },
    {
      "code" : "HIV.E.DE259",
      "display" : "Urine protein test result",
      "definition" : "Results of urine protein test of mother during ANC visit"
    },
    {
      "code" : "HIV.E.DE260",
      "display" : "0",
      "definition" : "Result of urine protein test of mother during ANC visit is '0'"
    },
    {
      "code" : "HIV.E.DE261",
      "display" : "+",
      "definition" : "Result of urine protein test of mother during ANC visit is '+'"
    },
    {
      "code" : "HIV.E.DE262",
      "display" : "++",
      "definition" : "Result of urine protein test of mother during ANC visit is '++'"
    },
    {
      "code" : "HIV.E.DE263",
      "display" : "+++",
      "definition" : "Result of urine protein test of mother during ANC visit is '+++'"
    },
    {
      "code" : "HIV.E.DE264",
      "display" : "Type of hypertensive disorder",
      "definition" : "Type of hypertensive disorder of the mother"
    },
    {
      "code" : "HIV.E.DE265",
      "display" : "Chronic hypertension",
      "definition" : "Hypertension detected pre-pregnancy or before 20 weeks' gestation"
    },
    {
      "code" : "HIV.E.DE266",
      "display" : "Essential",
      "definition" : "Hypertension without a known secondary cause (pre-pregnancy or at less than 20 weeks)"
    },
    {
      "code" : "HIV.E.DE267",
      "display" : "Secondary",
      "definition" : "Hypertension with a known secondary cause (e.g. renal disease; detected pre-pregnancy or at less than 20 weeks)"
    },
    {
      "code" : "HIV.E.DE268",
      "display" : "White-coat hypertension",
      "definition" : "sBP greater than or equal to 140 and/or dBP greater than or equal to 90 mmHg when measured in the office or clinic, and BP less than 135/85 mmHg using HBPM or ABPM readings (pre-pregnancy or at less than 20 weeks)"
    },
    {
      "code" : "HIV.E.DE269",
      "display" : "Masked hypertension",
      "definition" : "BP that is less than 140/90 mmHg at a clinic/office visit, but greater then or equal to 135/85 mmHg at other times outside the clinic/ office (pre-pregnancy or at less than 20 weeks)"
    },
    {
      "code" : "HIV.E.DE270",
      "display" : "Gestational hypertension",
      "definition" : "Hypertension arising de novo at greater than or equal to 20 weeks' gestation in the absence of proteinuria or other findings suggestive of pre-eclampsia"
    },
    {
      "code" : "HIV.E.DE271",
      "display" : "Transient gestational hypertension",
      "definition" : "Hypertension arising at greater than or equal to 20 weeks' gestation in the clinic, which resolves with repeated BP readings"
    },
    {
      "code" : "HIV.E.DE272",
      "display" : "Pre-eclampsia",
      "definition" : "Pre-eclampsia"
    },
    {
      "code" : "HIV.E.DE273",
      "display" : "Superimposed on chronic hypertension",
      "definition" : "Among women with chronic hypertension, development of new proteinuria, another maternal organ dysfunction(s), or evidence of uteroplacental dysfunction."
    },
    {
      "code" : "HIV.G.DE1",
      "display" : "CD4 count",
      "definition" : "CD4 cell count in cells/mm^3"
    },
    {
      "code" : "HIV.G.DE2",
      "display" : "CD4 cell percentage",
      "definition" : "CD4 cell percentage"
    },
    {
      "code" : "HIV.G.DE3",
      "display" : "Baseline CD4 count",
      "definition" : "CD4 count performed at HIV diagnosis"
    },
    {
      "code" : "HIV.G.DE4",
      "display" : "Date of baseline CD4 count sample collection",
      "definition" : "Date and time when baseline CD4 count test sample was collected"
    },
    {
      "code" : "HIV.G.DE5",
      "display" : "Late ART initiation",
      "definition" : "The client's first CD4 count from baseline CD4 test performed (such as at HIV diagnosis) was a count of <200 cells/mm3"
    },
    {
      "code" : "HIV.G.DE6",
      "display" : "Date of CD4 sample collection",
      "definition" : "Date sample to be used for CD4 count was collected"
    },
    {
      "code" : "HIV.G.DE7",
      "display" : "Viral load test conducted",
      "definition" : "A viral load test was performed"
    },
    {
      "code" : "HIV.G.DE8",
      "display" : "Date of viral load sample collection",
      "definition" : "Date and time when the sample was collected to test the client's HIV viral load"
    },
    {
      "code" : "HIV.G.DE9",
      "display" : "Date of first viral load sample collection",
      "definition" : "Date and time when the sample was collected to test the client's HIV viral load for the first time"
    },
    {
      "code" : "HIV.G.DE10",
      "display" : "Date viral load sample sent",
      "definition" : "Date viral load sample sent to the lab"
    },
    {
      "code" : "HIV.G.DE11",
      "display" : "First viral load test result",
      "definition" : "Result from the initial viral load test in number of copies/mL"
    },
    {
      "code" : "HIV.G.DE12",
      "display" : "Viral load test result",
      "definition" : "Result from the viral load test in number of copies/mL"
    },
    {
      "code" : "HIV.G.DE13",
      "display" : "HIV viral load specimen type",
      "definition" : "The type of specimen to be used to test viral load"
    },
    {
      "code" : "HIV.G.DE14",
      "display" : "Liquid plasma specimen for viral load testing",
      "definition" : "Liquid plasma and using ethylenediaminetetraacetic acid (EDTA) or plasma preparation tubes for viral load test"
    },
    {
      "code" : "HIV.G.DE15",
      "display" : "Dried blood spot specimen",
      "definition" : "Dried blood spot specimen (DBS) for viral load test"
    },
    {
      "code" : "HIV.G.DE16",
      "display" : "Dried plasma spot from a plasma separation card",
      "definition" : "Dried plasma spot from a plasma separation card for viral load test"
    },
    {
      "code" : "HIV.G.DE17",
      "display" : "HBsAg test date",
      "definition" : "Date client was tested for hepatitis B virus (HBV)"
    },
    {
      "code" : "HIV.G.DE18",
      "display" : "HBsAg test result",
      "definition" : "Hepatitis B virus test result (HBsAg)"
    },
    {
      "code" : "HIV.G.DE19",
      "display" : "Positive",
      "definition" : "HBsAg test result was positive"
    },
    {
      "code" : "HIV.G.DE20",
      "display" : "Negative",
      "definition" : "HBsAg test result was negative"
    },
    {
      "code" : "HIV.G.DE21",
      "display" : "Indeterminate",
      "definition" : "HBsAg test result was indeterminate"
    },
    {
      "code" : "HIV.G.DE22",
      "display" : "Reason Hepatitis B test not conducted",
      "definition" : "Reason why a hepatitis B test was not done"
    },
    {
      "code" : "HIV.G.DE23",
      "display" : "Test delayed to next contact or referred",
      "definition" : "Test has been delayed to the next contact or client was referred to another provider/facility"
    },
    {
      "code" : "HIV.G.DE24",
      "display" : "Stock-out or expired",
      "definition" : "Test out of stock or stock present but expired"
    },
    {
      "code" : "HIV.G.DE25",
      "display" : "Machine or technician not available or machine not functioning",
      "definition" : "Test machine or technician is unavailable, or machine is not functioning"
    },
    {
      "code" : "HIV.G.DE26",
      "display" : "Client declined / refused test",
      "definition" : "Client declined or refused test being undertaken"
    },
    {
      "code" : "HIV.G.DE27",
      "display" : "Other",
      "definition" : "Other reason test not performed"
    },
    {
      "code" : "HIV.G.DE28",
      "display" : "Other (specify)",
      "definition" : "Other reason test not performed (specify)"
    },
    {
      "code" : "HIV.G.DE29",
      "display" : "Hepatitis B diagnosis",
      "definition" : "Client's hepatitis B diagnosis"
    },
    {
      "code" : "HIV.G.DE30",
      "display" : "Hepatitis B positive",
      "definition" : "Client is positive for Hepatitis B"
    },
    {
      "code" : "HIV.G.DE31",
      "display" : "Hepatitis B negative",
      "definition" : "Client is negative for Hepatitis B"
    },
    {
      "code" : "HIV.G.DE32",
      "display" : "Hepatitis C screening date",
      "definition" : "Date when client was screened for HCV"
    },
    {
      "code" : "HIV.G.DE33",
      "display" : "Hepatitis C test ordered",
      "definition" : "Hepatitis C test has been ordered"
    },
    {
      "code" : "HIV.G.DE34",
      "display" : "Hepatitis C test conducted",
      "definition" : "Whether a hepatitis C test was conducted"
    },
    {
      "code" : "HIV.G.DE35",
      "display" : "Reason Hepatitis C test not done",
      "definition" : "Reason why a hepatitis C test was not done"
    },
    {
      "code" : "HIV.G.DE36",
      "display" : "Test delayed to next contact or referred",
      "definition" : "Test has been delayed to the next contact or client was referred to another provider/facility"
    },
    {
      "code" : "HIV.G.DE37",
      "display" : "Stock-out or expired",
      "definition" : "Test out of stock or stock present but expired"
    },
    {
      "code" : "HIV.G.DE38",
      "display" : "Machine or technician not available or machine not functioning",
      "definition" : "Test machine or technician is unavailable, or machine is not functioning"
    },
    {
      "code" : "HIV.G.DE39",
      "display" : "Client declined / refused test",
      "definition" : "Client declined or refused test being undertaken"
    },
    {
      "code" : "HIV.G.DE40",
      "display" : "Other",
      "definition" : "Other reason test not performed"
    },
    {
      "code" : "HIV.G.DE41",
      "display" : "Other (specify)",
      "definition" : "Other reason test not performed (specify)"
    },
    {
      "code" : "HIV.G.DE42",
      "display" : "HCV test date",
      "definition" : "Date client was tested for hepatitis C virus (HCV antibody, HCV RNA or HCV core antigen)"
    },
    {
      "code" : "HIV.G.DE43",
      "display" : "HCV test result",
      "definition" : "Hepatitis C virus test result (HCV antibody, HCV RNA or HCV core antigen)"
    },
    {
      "code" : "HIV.G.DE44",
      "display" : "Positive",
      "definition" : "HCV test result was positive"
    },
    {
      "code" : "HIV.G.DE45",
      "display" : "Negative",
      "definition" : "HCV test result was negative"
    },
    {
      "code" : "HIV.G.DE46",
      "display" : "Indeterminate",
      "definition" : "HCV test result was indeterminate"
    },
    {
      "code" : "HIV.G.DE47",
      "display" : "HCV viral load test date",
      "definition" : "Hepatitis C viral load test date"
    },
    {
      "code" : "HIV.G.DE48",
      "display" : "HCV viral load test result",
      "definition" : "Hepatitis C viral load test result (qualitative)"
    },
    {
      "code" : "HIV.G.DE49",
      "display" : "Detected",
      "definition" : "HCV was detected"
    },
    {
      "code" : "HIV.G.DE50",
      "display" : "Not detected",
      "definition" : "HCV was not detected"
    },
    {
      "code" : "HIV.G.DE51",
      "display" : "Hepatitis C diagnosis",
      "definition" : "Client's hepatitis C diagnosis"
    },
    {
      "code" : "HIV.G.DE52",
      "display" : "Hepatitis C positive",
      "definition" : "Client is positive for hepatitis C"
    },
    {
      "code" : "HIV.G.DE53",
      "display" : "Hepatitis C negative",
      "definition" : "Client is negative for hepatitis C"
    },
    {
      "code" : "HIV.G.DE54",
      "display" : "Syphilis test required",
      "definition" : "Syphilis test is required"
    },
    {
      "code" : "HIV.G.DE55",
      "display" : "Syphilis test type",
      "definition" : "Type of diagnostic test used for syphilis (treponema pallidum)"
    },
    {
      "code" : "HIV.G.DE56",
      "display" : "Treponemal",
      "definition" : "Treponemal test used"
    },
    {
      "code" : "HIV.G.DE57",
      "display" : "Non-treponemal",
      "definition" : "Non-treponemal test used"
    },
    {
      "code" : "HIV.G.DE58",
      "display" : "POC Test",
      "definition" : "Point-of-care (POC) test used"
    },
    {
      "code" : "HIV.G.DE59",
      "display" : "NAAT",
      "definition" : "Nucleic Acid Amplification Test (NAAT) used"
    },
    {
      "code" : "HIV.G.DE60",
      "display" : "Other",
      "definition" : "Other test used"
    },
    {
      "code" : "HIV.G.DE61",
      "display" : "Other syphilis test type (specify)",
      "definition" : "Other test used (specify)"
    },
    {
      "code" : "HIV.G.DE62",
      "display" : "Reason syphilis test not done",
      "definition" : "Reason why a syphilis test was not done"
    },
    {
      "code" : "HIV.G.DE63",
      "display" : "Test delayed to next contact or referred",
      "definition" : "Test has been delayed to the next contact or client was referred to another provider/facility"
    },
    {
      "code" : "HIV.G.DE64",
      "display" : "Stock-out or expired",
      "definition" : "Test out of stock or stock present but expired"
    },
    {
      "code" : "HIV.G.DE65",
      "display" : "Machine or technician not available or machine not functioning",
      "definition" : "Test machine or technician is unavailable, or machine is not functioning"
    },
    {
      "code" : "HIV.G.DE66",
      "display" : "Client declined / refused test",
      "definition" : "Client declined or refused test being undertaken"
    },
    {
      "code" : "HIV.G.DE67",
      "display" : "Other",
      "definition" : "Other reason test not performed"
    },
    {
      "code" : "HIV.G.DE68",
      "display" : "Other (specify)",
      "definition" : "Other reason test not performed (specify)"
    },
    {
      "code" : "HIV.G.DE69",
      "display" : "Syphilis test date",
      "definition" : "Date of syphilis test"
    },
    {
      "code" : "HIV.G.DE70",
      "display" : "Syphilis test result",
      "definition" : "Result from syphilis test"
    },
    {
      "code" : "HIV.G.DE71",
      "display" : "Positive",
      "definition" : "Test result is positive for syphilis"
    },
    {
      "code" : "HIV.G.DE72",
      "display" : "Negative",
      "definition" : "Test result is negative for syphilis"
    },
    {
      "code" : "HIV.G.DE73",
      "display" : "Inconclusive",
      "definition" : "Test result is inconclusive"
    },
    {
      "code" : "HIV.G.DE74",
      "display" : "Syphilis diagnosis",
      "definition" : "Client's syphilis diagnosis"
    },
    {
      "code" : "HIV.G.DE75",
      "display" : "Syphilis positive",
      "definition" : "Client is positive for syphilis"
    },
    {
      "code" : "HIV.G.DE76",
      "display" : "Syphilis negative",
      "definition" : "Client is negative for syphilis"
    },
    {
      "code" : "HIV.G.DE77",
      "display" : "Other tests conducted",
      "definition" : "If the health worker performed other tests on the woman that are not explicitly listed in the application, select 'yes' here and fill in the details below."
    },
    {
      "code" : "HIV.G.DE78",
      "display" : "Other test(s) name",
      "definition" : "Input the name of other test(s) that were done."
    },
    {
      "code" : "HIV.G.DE79",
      "display" : "Other test(s) date",
      "definition" : "Input the date of other test(s) that were done."
    },
    {
      "code" : "HIV.G.DE80",
      "display" : "Other test(s) result(s)",
      "definition" : "Input the result from the test(s)."
    },
    {
      "code" : "HIV.H.DE1",
      "display" : "Reason for follow-up",
      "definition" : "The reason why the client is being followed up"
    },
    {
      "code" : "HIV.H.DE2",
      "display" : "Missed care visit",
      "definition" : "Client did not present for a care appointment as scheduled / as expected"
    },
    {
      "code" : "HIV.H.DE3",
      "display" : "Missed medication pickup",
      "definition" : "Client did not pick up medication as scheduled from pharmacy or other drug distribution point"
    },
    {
      "code" : "HIV.H.DE4",
      "display" : "Did not initiate ART",
      "definition" : "Client did not initiate ART at the same time as diagnosis (e.g., because they required additional counselling) and required follow-up for ART initiation"
    },
    {
      "code" : "HIV.H.DE5",
      "display" : "Incomplete visit",
      "definition" : "Client presented for care, but left before services were completed, e.g., due to long wait times or not staying to have labs taken"
    },
    {
      "code" : "HIV.H.DE6",
      "display" : "Inconclusive HIV status",
      "definition" : "Client has not returned for a follow-up test after an inconclusive test result"
    },
    {
      "code" : "HIV.H.DE7",
      "display" : "Test results received",
      "definition" : "Client needs to be informed of test results (e.g., viral load)"
    },
    {
      "code" : "HIV.H.DE8",
      "display" : "Other follow-up reason",
      "definition" : "Client was followed up for another reason"
    },
    {
      "code" : "HIV.H.DE9",
      "display" : "Other follow-up reason (specify)",
      "definition" : "Client was followed up for another reason (specify)"
    },
    {
      "code" : "HIV.H.DE10",
      "display" : "Client contact attempted",
      "definition" : "An attempt to locate the client was made"
    },
    {
      "code" : "HIV.H.DE11",
      "display" : "Date of contact attempt",
      "definition" : "Date of attempt to contact client"
    },
    {
      "code" : "HIV.H.DE12",
      "display" : "Contact attempted by",
      "definition" : "Who attempted to reach out to the client"
    },
    {
      "code" : "HIV.H.DE13",
      "display" : "Contact method",
      "definition" : "Method used to try to reach out to the client"
    },
    {
      "code" : "HIV.H.DE14",
      "display" : "Home visit",
      "definition" : "Contacted client at home"
    },
    {
      "code" : "HIV.H.DE15",
      "display" : "Text message",
      "definition" : "Contacted client by short message service (SMS) text"
    },
    {
      "code" : "HIV.H.DE16",
      "display" : "Phone",
      "definition" : "Contacted client by phone call"
    },
    {
      "code" : "HIV.H.DE17",
      "display" : "Source of information",
      "definition" : "Source of information about the client"
    },
    {
      "code" : "HIV.H.DE18",
      "display" : "Client",
      "definition" : "The client was the source of information"
    },
    {
      "code" : "HIV.H.DE19",
      "display" : "Informed by treatment provider",
      "definition" : "Source of information was a treatment provider of the client"
    },
    {
      "code" : "HIV.H.DE20",
      "display" : "Informed by family or partner",
      "definition" : "Source of information was a family member of partner"
    },
    {
      "code" : "HIV.H.DE21",
      "display" : "Other source of information",
      "definition" : "Information about the client's status was provided by someone else"
    },
    {
      "code" : "HIV.H.DE22",
      "display" : "Other source of information (specify)",
      "definition" : "Information about the client's status was provided by someone else (specify)"
    },
    {
      "code" : "HIV.H.DE23",
      "display" : "Outcome from outreach attempt",
      "definition" : "Detailed outcome from the attempt to locate the client"
    },
    {
      "code" : "HIV.H.DE24",
      "display" : "Returning to clinic",
      "definition" : "Client was located and agreed to return to clinic"
    },
    {
      "code" : "HIV.H.DE25",
      "display" : "Self-transferred out",
      "definition" : "Client transferred to another facility for care (client-initiated transfer, not provider-initiated transfer)"
    },
    {
      "code" : "HIV.H.DE26",
      "display" : "Hospitalized",
      "definition" : "Client was hospitalized"
    },
    {
      "code" : "HIV.H.DE27",
      "display" : "Refused to return",
      "definition" : "Client was found but declined to return to treatment"
    },
    {
      "code" : "HIV.H.DE28",
      "display" : "Not located",
      "definition" : "Attempt was made to locate client, but client was not found"
    },
    {
      "code" : "HIV.H.DE29",
      "display" : "Died (reported)",
      "definition" : "The client was reported as having died"
    },
    {
      "code" : "HIV.H.DE30",
      "display" : "Moved from catchment area",
      "definition" : "The client moved from the catchment area (may be reported from the community level)"
    },
    {
      "code" : "HIV.H.DE31",
      "display" : "Date client moved from catchment area",
      "definition" : "The date on which the client moved from the catchment area, if known"
    },
    {
      "code" : "HIV.H.DE32",
      "display" : "New catchment area",
      "definition" : "New catchment area where the client resides"
    },
    {
      "code" : "HIV.H.DE33",
      "display" : "Partner or contact of index case",
      "definition" : "The client was identified by an index case as a partner or contact"
    },
    {
      "code" : "HIV.H.DE34",
      "display" : "HIV status of partner or contact",
      "definition" : "HIV status of the partner or contact given by the index case"
    },
    {
      "code" : "HIV.H.DE35",
      "display" : "Already knew positive",
      "definition" : "The partner or contact of the index case already knew they are HIV-positive"
    },
    {
      "code" : "HIV.H.DE36",
      "display" : "Newly diagnosed",
      "definition" : "The partner or contact of the index case is newly diagnosed as HIV-positive"
    },
    {
      "code" : "HIV.H.DE37",
      "display" : "Negative",
      "definition" : "The partner or contact of the index case is newly diagnosed is HIV-negative"
    },
    {
      "code" : "HIV.H.DE38",
      "display" : "Date of death",
      "definition" : "If deceased, the date that the client died"
    },
    {
      "code" : "HIV.H.DE39",
      "display" : "Cause of death",
      "definition" : "Cause of death, if known"
    },
    {
      "code" : "HIV.H.DE40",
      "display" : "Place of death",
      "definition" : "Where the client died, if known"
    },
    {
      "code" : "HIV.H.DE41",
      "display" : "HIV treatment outcome",
      "definition" : "The outcome for the client which is used for reporting retention/attrition."
    },
    {
      "code" : "HIV.H.DE42",
      "display" : "Lost to follow-up",
      "definition" : "Twenty-eight days or more since last missed appointment"
    },
    {
      "code" : "HIV.H.DE43",
      "display" : "Transferred out",
      "definition" : "The client transferred to another facility"
    },
    {
      "code" : "HIV.H.DE44",
      "display" : "Death (documented)",
      "definition" : "People living with HIV previously on ART who are confirmed to have died from any cause"
    },
    {
      "code" : "HIV.H.DE45",
      "display" : "Refused (stopped) treatment",
      "definition" : "Client was contacted and confirmed to have stopped ART (reasons may include stigma and discrimination, faith healing, etc.)"
    },
    {
      "code" : "HIV.H.DE46",
      "display" : "Date patient lost to follow-up",
      "definition" : "Date patient was lost to follow-up (LTFU)"
    },
    {
      "code" : "HIV.H.DE47",
      "display" : "On ART",
      "definition" : "Client is currently taking ART"
    },
    {
      "code" : "HIV.H.DE48",
      "display" : "Date HIV treatment outcome changed",
      "definition" : "The date on which the client's outcome (lost to follow-up, transferred out, death (documented), or refused (stopped) treatment) changed"
    },
    {
      "code" : "HIV.H.DE49",
      "display" : "Transfer confirmed",
      "definition" : "Select if transfer to another facility is confirmed"
    },
    {
      "code" : "HIV.H.DE50",
      "display" : "Transfer to facility",
      "definition" : "Name of health facility client was transferred to"
    },
    {
      "code" : "HIV.H.DE51",
      "display" : "Date of transfer out",
      "definition" : "The date the client transferred out of the facility to be provided with care at another facility"
    },
    {
      "code" : "HIV.H.DE52",
      "display" : "Adherence assessment",
      "definition" : "Whether client is adherent or not to ART regimen per national guidelines (immunological or virological monitoring)"
    },
    {
      "code" : "HIV.H.DE53",
      "display" : "Reason(s) for adherence problem",
      "definition" : "Reason why client is not adherent"
    },
    {
      "code" : "HIV.H.DE54",
      "display" : "Forgot",
      "definition" : "Client reported not being adherent because they forgot"
    },
    {
      "code" : "HIV.H.DE55",
      "display" : "Toxicity/side effects",
      "definition" : "Client reported not being adherent because of toxicity/side effects"
    },
    {
      "code" : "HIV.H.DE56",
      "display" : "Busy",
      "definition" : "Client reported not being adherent because they were busy"
    },
    {
      "code" : "HIV.H.DE57",
      "display" : "Change of routine",
      "definition" : "Client reported not being adherent because of a change of routine"
    },
    {
      "code" : "HIV.H.DE58",
      "display" : "Travel cost",
      "definition" : "Client reported not being adherent because of travel cost"
    },
    {
      "code" : "HIV.H.DE59",
      "display" : "Distance to clinic",
      "definition" : "Client reported not being adherent because of distance to clinic"
    },
    {
      "code" : "HIV.H.DE60",
      "display" : "Client lost/ran out of pills",
      "definition" : "Client reported not being adherent because of client lost/ran out of pills"
    },
    {
      "code" : "HIV.H.DE61",
      "display" : "Stock-out",
      "definition" : "Client reported not being adherent because of a stock-out"
    },
    {
      "code" : "HIV.H.DE62",
      "display" : "Too ill",
      "definition" : "Client reported not being adherent because of being too ill"
    },
    {
      "code" : "HIV.H.DE63",
      "display" : "Pill burden",
      "definition" : "Client reported not being adherent because of the pill burden"
    },
    {
      "code" : "HIV.H.DE64",
      "display" : "Felt well",
      "definition" : "Client reported not being adherent because they felt well"
    },
    {
      "code" : "HIV.H.DE65",
      "display" : "Depression",
      "definition" : "Client reported not being adherent because of depression"
    },
    {
      "code" : "HIV.H.DE66",
      "display" : "Alcohol use",
      "definition" : "Client reported not being adherent because of alcohol use"
    },
    {
      "code" : "HIV.H.DE67",
      "display" : "Substance use",
      "definition" : "Client reported not being adherent because of substance use (i.e., drugs)"
    },
    {
      "code" : "HIV.H.DE68",
      "display" : "Stigma/disclosure concerns",
      "definition" : "Client reported not being adherent because of stigma/disclosure concerns"
    },
    {
      "code" : "HIV.H.DE69",
      "display" : "Lack of food",
      "definition" : "Client reported not being adherent because of a lack of food"
    },
    {
      "code" : "HIV.H.DE70",
      "display" : "Poor palatability",
      "definition" : "Client reported not being adherent because of poor palatability"
    },
    {
      "code" : "HIV.H.DE71",
      "display" : "Other",
      "definition" : "Client reported not being adherent because of other reason"
    },
    {
      "code" : "HIV.H.DE72",
      "display" : "Other (specify)",
      "definition" : "Client reported not being adherent because of other reason (specify)"
    },
    {
      "code" : "HIV.H.DE73",
      "display" : "Date ART stopped",
      "definition" : "Date on which client stopped ART"
    },
    {
      "code" : "HIV.H.DE74",
      "display" : "Reason ART stopped",
      "definition" : "Reason why client intentionally stopped ART"
    },
    {
      "code" : "HIV.H.DE75",
      "display" : "Toxicity/side effects",
      "definition" : "Client stopped ART because of toxicity/side effects"
    },
    {
      "code" : "HIV.H.DE76",
      "display" : "Severe illness, hospitalization",
      "definition" : "Client stopped ART because of severe illness, hospitalization"
    },
    {
      "code" : "HIV.H.DE77",
      "display" : "Drugs out of stock",
      "definition" : "Client stopped ART because of drugs being out of stock"
    },
    {
      "code" : "HIV.H.DE78",
      "display" : "Client lacks finances",
      "definition" : "Client stopped ART because client lacked finances"
    },
    {
      "code" : "HIV.H.DE79",
      "display" : "Excluded HIV infection in infant",
      "definition" : "Client stopped ART because the infant was determined to not have HIV"
    },
    {
      "code" : "HIV.H.DE80",
      "display" : "Other reason for stopping ART",
      "definition" : "Client stopped ART for other reason"
    },
    {
      "code" : "HIV.H.DE81",
      "display" : "Other reason for stopping ART (specify)",
      "definition" : "Client stopped ART for other reason (specify)"
    },
    {
      "code" : "HIV.I.DE1",
      "display" : "Emergency referral",
      "definition" : "Referral for urgent care"
    },
    {
      "code" : "HIV.I.DE2",
      "display" : "Reason for referral",
      "definition" : "Reason why the client is being referred. If diagnosed, this may include the reason for the diagnosis."
    },
    {
      "code" : "HIV.I.DE3",
      "display" : "Hospital",
      "definition" : "Client's clinical status warrants hospitalization"
    },
    {
      "code" : "HIV.I.DE4",
      "display" : "Referral for screening including diagnostics and lab testing",
      "definition" : "The client is referred because they need a lab test done and/or diagnostics done, but those services are unavailable at the current health facility or providers. This includes referral for TB screening (is symptomatic of TB, has had close contact with confirmed TB case, etc.) and other comorbidities or coinfections."
    },
    {
      "code" : "HIV.I.DE5",
      "display" : "TB referral",
      "definition" : "Referral for TB care"
    },
    {
      "code" : "HIV.I.DE6",
      "display" : "Antenatal care referral",
      "definition" : "Client was referred because the client is pregnant"
    },
    {
      "code" : "HIV.I.DE7",
      "display" : "Referral for other general services",
      "definition" : "If none of the reasons above apply, this should be selected"
    },
    {
      "code" : "HIV.I.DE8",
      "display" : "Referral for other general services (specify)",
      "definition" : "If none of the reasons above apply, specify the reason(s)"
    },
    {
      "code" : "HIV.I.DE9",
      "display" : "Any treatment given before referral?",
      "definition" : "If client was referred, was any treatment provided before referral?"
    },
    {
      "code" : "HIV.I.DE10",
      "display" : "Date of scheduled referral appointment",
      "definition" : "When the referral is scheduled"
    },
    {
      "code" : "HIV.I.DE11",
      "display" : "Location of scheduled referral appointment",
      "definition" : "Where the client is being referred to"
    },
    {
      "code" : "HIV.I.DE12",
      "display" : "Date referral was made",
      "definition" : "The date the referral was made"
    },
    {
      "code" : "HIV.I.DE13",
      "display" : "Provider who made referral",
      "definition" : "The name of the provider who made the referral"
    },
    {
      "code" : "HIV.I.DE14",
      "display" : "Provider's facility",
      "definition" : "Facility client is being referred from"
    },
    {
      "code" : "HIV.I.DE15",
      "display" : "Provider's telephone number",
      "definition" : "The contact details of the provider making the referral"
    },
    {
      "code" : "HIV.I.DE16",
      "display" : "Referral notes",
      "definition" : "Any additional relevant details of clinical significance for the referral facility to provide quality care"
    },
    {
      "code" : "HIV.I.DE17",
      "display" : "Client history summary",
      "definition" : "With interoperable systems, the provider receiving the referral should be able to access the client's health record digitally. However, in the absence of this, the referral provider should receive a summary of the client's health records that includes the client's history, medications, medications prescribed or dispensed, reported issues and concerns, and any other relevant clinical information the health care provider had already obtained."
    },
    {
      "code" : "HIV.PRV.DE1",
      "display" : "At elevated risk for HIV acquisition",
      "definition" : "Client is at elevated risk for HIV acquisition, defined according to country/programme context"
    },
    {
      "code" : "HIV.PRV.DE2",
      "display" : "HIV prevention intervention",
      "definition" : "HIV prevention intervention that client accessed"
    },
    {
      "code" : "HIV.PRV.DE3",
      "display" : "PrEP service",
      "definition" : "Client accessed PrEP services"
    },
    {
      "code" : "HIV.PRV.DE4",
      "display" : "OAMT",
      "definition" : "Client accessed opioid agonist maintenance treatment (OAMT) services"
    },
    {
      "code" : "HIV.PRV.DE5",
      "display" : "NSP",
      "definition" : "Client accessed needle-syringe programme (NSP) services"
    },
    {
      "code" : "HIV.PRV.DE6",
      "display" : "STI services",
      "definition" : "Client accessed sexually transmitted infection (STI) services"
    },
    {
      "code" : "HIV.PRV.DE7",
      "display" : "VMMC",
      "definition" : "Client accessed voluntary medical male circumcision (VMMC) services"
    },
    {
      "code" : "HIV.PRV.DE8",
      "display" : "Other",
      "definition" : "Client accessed other HIV prevention services"
    },
    {
      "code" : "HIV.PRV.DE9",
      "display" : "Other (specify)",
      "definition" : "Client accessed other HIV prevention services (specify)"
    },
    {
      "code" : "HIV.PRV.DE10",
      "display" : "Date accessed HIV prevention intervention",
      "definition" : "Date the client accessed HIV prevention intervention"
    },
    {
      "code" : "HIV.PRV.DE11",
      "display" : "HIV status of contact",
      "definition" : "The HIV status of the client's contact"
    },
    {
      "code" : "HIV.PRV.DE12",
      "display" : "HIV-positive",
      "definition" : "Client's contact is HIV-positive"
    },
    {
      "code" : "HIV.PRV.DE13",
      "display" : "HIV-negative",
      "definition" : "Client's contact is HIV-negative"
    },
    {
      "code" : "HIV.PRV.DE14",
      "display" : "Unknown",
      "definition" : "Client does not know contact's HIV status"
    },
    {
      "code" : "HIV.PRV.DE15",
      "display" : "Date injecting equipment provided",
      "definition" : "Date client was provided with injecting equipment"
    },
    {
      "code" : "HIV.PRV.DE16",
      "display" : "Number of needles-syringes provided",
      "definition" : "Number of needles-syringes provided to client"
    },
    {
      "code" : "HIV.PRV.DE17",
      "display" : "Date OAMT initiated",
      "definition" : "Date client initiated opioid agonist maintenance treatment (OAMT)"
    },
    {
      "code" : "HIV.PRV.DE18",
      "display" : "Date OAMT dose received",
      "definition" : "Date client received opioid agonist maintenance treatment (OAMT) dose"
    },
    {
      "code" : "HIV.PRV.DE19",
      "display" : "Date OAMT take-away dose(s) dispensed",
      "definition" : "Date the client was dispensed opioid agonist maintenance treatment (OAMT) take-away dose(s)"
    },
    {
      "code" : "HIV.PRV.DE20",
      "display" : "Currently on OAMT",
      "definition" : "Client is currently on opioid agonist maintenance treatment (OAMT) at reporting date, defined according to country/program to account for medication dispensed and LTFU criterion"
    },
    {
      "code" : "HIV.PRV.DE21",
      "display" : "Retained on OAMT",
      "definition" : "Client is retained on opioid agonist maintenance treatment (OAMT) at reporting date, defined according to country/program to account for medication dispensed and LTFU criterion"
    },
    {
      "code" : "HIV.PRV.DE22",
      "display" : "Client being inducted on OAMT",
      "definition" : "Client is currently being inducted on opioid agonist maintenance treatment (OAMT), defined according to country/program"
    },
    {
      "code" : "HIV.PRV.DE23",
      "display" : "Client on reducing doses of OAMT",
      "definition" : "Client is current on reducing doses of opioid agonist maintenance treatment (OAMT), defined according to country/program"
    },
    {
      "code" : "HIV.PRV.DE24",
      "display" : "Date first maintenance dose received",
      "definition" : "First date on which client received maintenance dose"
    },
    {
      "code" : "HIV.PRV.DE25",
      "display" : "Date of loss to follow-up or OAMT stopped",
      "definition" : "Date of loss to follow-up or opioid agonist maintenance treatment (OAMT) stopped"
    },
    {
      "code" : "HIV.PRV.DE26",
      "display" : "Date medications dispensed",
      "definition" : "Date the client was dispensed medications"
    },
    {
      "code" : "HIV.PRV.DE27",
      "display" : "Date medications prescribed",
      "definition" : "Date the client was prescribed medications"
    },
    {
      "code" : "HIV.PRV.DE28",
      "display" : "Number of days prescribed",
      "definition" : "Days of medication client has been prescribed"
    },
    {
      "code" : "HIV.Config.DE1",
      "display" : "Population prevalence of TB",
      "definition" : "The tuberculosis prevalence in the general population in number of cases per 100 000 persons or greater."
    },
    {
      "code" : "HIV.Config.DE2",
      "display" : "Population prevalence of soil-transmitted helminth infection",
      "definition" : "The percentage of individuals in the general population infected with at least one species of soil-transmitted helminths"
    },
    {
      "code" : "HIV.Config.DE3",
      "display" : "Population incidence of HIV in the absence of PrEP",
      "definition" : "HIV incidence number of cases per 100 person–years in the absence of PrEP"
    },
    {
      "code" : "HIV.Config.DE4",
      "display" : "Population prevalence of HIV",
      "definition" : "The proportion of the population that are HIV-positive"
    },
    {
      "code" : "HIV.Config.DE5",
      "display" : "Prevalence of pretreatment NNRTI drug resistance",
      "definition" : "Prevalence of pretreatment HIV drug resistance to NNRTIs among people initiating first-line ART"
    },
    {
      "code" : "HIV.Config.DE6",
      "display" : "Malaria-endemic setting",
      "definition" : "Whether the setting is a malaria-endemic setting"
    },
    {
      "code" : "HIV.Config.DE7",
      "display" : "Population prevalence of syphilis",
      "definition" : "The proportion of the population with syphilis"
    },
    {
      "code" : "HIV.Config.DE8",
      "display" : "Population prevalence of hepatitis B",
      "definition" : "The proportion of hepatitis B surface antigen (HBsAg) seroprevalence in the general population"
    },
    {
      "code" : "HIV.Config.DE9",
      "display" : "Population prevalence of hepatitis C",
      "definition" : "The proportion of hepatitis C virus (HCV) antibody seroprevalence in the general population"
    },
    {
      "code" : "HIV.Config.DE10",
      "display" : "Prevalence of HIV in the catchment area",
      "definition" : "The proportion of the population from the health facility's catchment area that are HIV-positive (estimated)"
    },
    {
      "code" : "HIV.Config.DE11",
      "display" : "Ultrasound available at the health facility",
      "definition" : "Whether an ultrasound machine is available and functional in the facility and a trained health worker is available to use it"
    },
    {
      "code" : "HIV.Config.DE12",
      "display" : "HIV burden of the setting",
      "definition" : "HIV burden of the setting (high or low) based on the national HIV prevalence or where the HIV prevalence and/or incidence in a geographical setting is higher than national prevalence and, therefore, needs priority in the HIV response"
    },
    {
      "code" : "HIV.Config.DE13",
      "display" : "High HIV burden setting",
      "definition" : "Settings with >5% national HIV prevalence and subpopulations and geographic settings where HIV prevalence and/or incidence is higher than nationally."
    },
    {
      "code" : "HIV.Config.DE14",
      "display" : "Low HIV burden setting",
      "definition" : "Settings with <5% HIV national prevalence but where certain populations (primarily key populations and their partners) and geographic settings may have higher HIV prevalence and/or incidence than nationally and, therefore, need priority in the HIV response"
    },
    {
      "code" : "HIV.Config.DE15",
      "display" : "HPV DNA testing operational at the health facility",
      "definition" : "Is HPV DNA testing operational at the health facility for cervical cancer screening?"
    },
    {
      "code" : "HIV.Config.DE16",
      "display" : "Routine viral load testing is available",
      "definition" : "Routine viral load testing is available in the facility"
    },
    {
      "code" : "HIV.Config.DE17",
      "display" : "Health facility ID",
      "definition" : "Unique ID of the health facility that recorded the client. This ID could represent a universal health facility ID, if used in the country. Alternatively this ID can also be generated by the national surveillance system and assigned to reporting facility."
    },
    {
      "code" : "HIV.Config.DE18",
      "display" : "TB treating facility ID",
      "definition" : "The facility where the client is receiving tuberculosis (TB) treatment"
    },
    {
      "code" : "HIV.Config.DE19",
      "display" : "Other priority populations",
      "definition" : "Other populations of priority of HIV prevention and care in local context (provided during adaptation)"
    },
    {
      "code" : "HIV.Config.DE20",
      "display" : "Reporting period end date",
      "definition" : "End date of the reporting period"
    },
    {
      "code" : "HIV.Config.DE21",
      "display" : "Reporting period start date",
      "definition" : "Start date of the reporting period"
    },
    {
      "code" : "HIV.Config.DE22",
      "display" : "Reporting date",
      "definition" : "Reporting date, for surveys performed on a specific date"
    }
  ]
}

```
