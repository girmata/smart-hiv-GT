# Reason for PrEP visit ValueSet - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Reason for PrEP visit ValueSet**

## ValueSet: Reason for PrEP visit ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/ValueSet/HIV.C.DE1 | *Version*:0.4.4 |
| Active as of 2025-12-10 | *Computable Name*:HIVCDE1 |

 
Value set of client's reason for the prevention visit 

 **References** 

* [HIV.C PrEP visit](StructureDefinition-HIVCPrEPvisit.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "HIV.C.DE1",
  "meta" : {
    "profile" : [
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablevalueset",
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
      "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"
    ]
  },
  "url" : "http://smart.who.int/hiv/ValueSet/HIV.C.DE1",
  "version" : "0.4.4",
  "name" : "HIVCDE1",
  "title" : "Reason for PrEP visit ValueSet",
  "status" : "active",
  "experimental" : true,
  "date" : "2025-12-10T09:21:32+00:00",
  "publisher" : "WHO",
  "contact" : [
    {
      "name" : "WHO",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://who.int"
        }
      ]
    }
  ],
  "description" : "Value set of client's reason for the prevention visit",
  "compose" : {
    "include" : [
      {
        "system" : "http://smart.who.int/hiv/CodeSystem/HIVConcepts",
        "concept" : [
          {
            "code" : "HIV.C.DE2",
            "display" : "First time counselling on PrEP"
          },
          {
            "code" : "HIV.C.DE3",
            "display" : "Follow-up appointment for PrEP or PEP"
          },
          {
            "code" : "HIV.C.DE4",
            "display" : "Restarting PrEP"
          },
          {
            "code" : "HIV.C.DE5",
            "display" : "Counselling on PEP"
          },
          {
            "code" : "HIV.C.DE6",
            "display" : "Unscheduled visit for side effects"
          }
        ]
      }
    ]
  }
}

```
